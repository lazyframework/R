using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

// Layout generated from coordinates, not pixels. All artwork fields are optional and empty.
[DisallowMultipleComponent]
public class EclipseNativeLobbyBuilder : MonoBehaviour {
    [Header("Optional OWN assets - no reference image used")]
    public Font font;
    public Sprite backgroundArt, portraitArt, agentBannerArt, mapArt, brandArt;
    public RenderTexture characterPreview;
    [Header("Editable profile")]
    public string playerName="FamaLine";
    public int level=12, experience=720, experienceMax=2000, diamonds=1200, coins=15340;
    [Header("Gameplay hookup (optional)")]
    public string deployScene="";
    [Serializable] public class RouteEvent : UnityEvent<string> { }
    public RouteEvent onNavigate=new RouteEvent();
    public UnityEvent onDeploy=new UnityEvent();
    [Header("Theme")]
    public Color panelColor=new Color(.018f,.045f,.10f,.94f);
    public Color borderColor=new Color(.20f,.46f,.8f,.9f);
    public Color accent=new Color(.10f,.58f,1f,1);
    public Color labelColor=new Color(.88f,.93f,1f,1);
    const string Generated="EclipseNativeCanvas";
    RectTransform frame;
    Text playerLabel,levelLabel,xpLabel,diamondLabel,coinLabel;
    Image xpFill;
    static readonly Vector2 Size=new Vector2(1672,941);
    void Start(){
        var existing=transform.Find(Generated);
        if(!existing) Build();
        else foreach(var button in existing.GetComponentsInChildren<Button>(true)) {
            string route=button.gameObject.name;
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(()=>Navigate(route));
        }
    }

    [ContextMenu("Build Native Lobby")]
    public void Build(){
        var old=transform.Find(Generated);if(old){old.gameObject.SetActive(false);if(Application.isPlaying)Destroy(old.gameObject);else DestroyImmediate(old.gameObject);}
        if(!font){
#if UNITY_2022_2_OR_NEWER
            font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font=Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }
        var go=new GameObject(Generated,typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));go.transform.SetParent(transform,false);
        go.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
        var scaler=go.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=Size;scaler.matchWidthOrHeight=.5f;
        frame=Rect("ReferenceFrame_1672x941",go.transform,0,0,1672,941);frame.anchorMin=frame.anchorMax=new Vector2(.5f,.5f);frame.pivot=new Vector2(.5f,.5f);frame.anchoredPosition=Vector2.zero;
        frame.gameObject.AddComponent<EclipseFrameFit>();
        // These layers may be disabled to reveal a real 3D scene behind the UI.
        var bg=Rect("OptionalBackground_DisableForLive3D",frame,0,0,1672,941);
        var image=bg.gameObject.AddComponent<Image>();image.color=new Color(.014f,.026f,.052f,1);image.raycastTarget=false;
        if(backgroundArt){image.sprite=backgroundArt;image.color=Color.white;}
        var preview=Rect("CharacterStage_RenderTextureSlot",frame,445,108,820,686);
        if(characterPreview){var raw=preview.gameObject.AddComponent<RawImage>();raw.texture=characterPreview;raw.raycastTarget=false;}
        Header(); Profile(); LeftCards(); RightCards(); Navigation();
        EnsureEventSystem();Canvas.ForceUpdateCanvases();
    }
    RectTransform Rect(string n,Transform parent,float x,float y,float w,float h){var r=new GameObject(n,typeof(RectTransform)).GetComponent<RectTransform>();r.SetParent(parent,false);r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(w,h);return r;}
    EclipseAngularPanel Panel(Transform parent,string n,float x,float y,float w,float h,float cut=15){var r=Rect(n,parent,x,y,w,h);var p=r.gameObject.AddComponent<EclipseAngularPanel>();p.color=panelColor;p.bottomTint=new Color(.009f,.025f,.065f,.94f);p.borderColor=borderColor;p.corner=cut;return p;}
    Text Label(Transform parent,string n,string value,float x,float y,float w,float h,int size=20,TextAnchor align=TextAnchor.MiddleLeft,bool bold=false){var t=Rect(n,parent,x,y,w,h).gameObject.AddComponent<Text>();t.font=font;t.text=value;t.fontSize=size;t.color=labelColor;t.alignment=align;t.fontStyle=bold?FontStyle.Bold:FontStyle.Normal;t.raycastTarget=false;t.horizontalOverflow=HorizontalWrapMode.Wrap;t.verticalOverflow=VerticalWrapMode.Truncate;return t;}
    Image Solid(Transform parent,string n,float x,float y,float w,float h,Color c){var i=Rect(n,parent,x,y,w,h).gameObject.AddComponent<Image>();i.color=c;i.raycastTarget=false;return i;}
    void Art(Transform parent,string n,Sprite asset,float x,float y,float w,float h){if(!asset)return;var i=Rect(n,parent,x,y,w,h).gameObject.AddComponent<Image>();i.sprite=asset;i.preserveAspect=false;i.raycastTarget=false;}
    EclipseVectorIcon Icon(Transform parent,EclipseVectorIcon.Kind kind,float x,float y,float size,Color? c=null){var g=Rect(kind+"Icon",parent,x,y,size,size).gameObject.AddComponent<EclipseVectorIcon>();g.kind=kind;g.color=c??labelColor;g.raycastTarget=false;return g;}
    void Click(Graphic graphic,string route){var b=graphic.gameObject.AddComponent<Button>();b.targetGraphic=graphic;var c=b.colors;c.normalColor=Color.white;c.highlightedColor=new Color(.65f,.85f,1);c.pressedColor=new Color(.35f,.6f,.95f);c.selectedColor=Color.white;c.fadeDuration=.12f;b.colors=c;b.onClick.AddListener(()=>Navigate(route));}
    void Arrow(Transform t,float x,float y){Icon(t,EclipseVectorIcon.Kind.Arrow,x,y,24);}
    void Header(){
        var brand=Rect("Brand",frame,32,18,390,80);
        if(brandArt)Art(brand,"BrandAsset",brandArt,0,0,390,80);else{Icon(brand,EclipseVectorIcon.Kind.Diamond,4,0,74,accent);Label(brand,"Project","PROJECT",140,0,245,29,23,TextAnchor.MiddleLeft,true);Label(brand,"Title","ECLIPSE",138,23,250,56,43,TextAnchor.MiddleLeft,true);}
        Solid(frame,"HeaderDivider",30,106,1610,1,new Color(.12f,.31f,.57f,.65f));
        var gems=Panel(frame,"DiamondWallet",1045,27,163,44,0);Icon(gems.transform,EclipseVectorIcon.Kind.Diamond,12,6,30,accent);diamondLabel=Label(gems.transform,"Balance",diamonds.ToString("N0"),51,0,78,44,22,TextAnchor.MiddleLeft,true);Label(gems.transform,"Add","+",130,0,30,44,29,TextAnchor.MiddleCenter);Click(gems,"Diamonds");
        var gold=Panel(frame,"CoinWallet",1218,27,172,44,0);Icon(gold.transform,EclipseVectorIcon.Kind.Coin,11,6,30,new Color(1,.72f,.27f));coinLabel=Label(gold.transform,"Balance",coins.ToString("N0"),53,0,87,44,22,TextAnchor.MiddleLeft,true);Label(gold.transform,"Add","+",140,0,30,44,29,TextAnchor.MiddleCenter);Click(gold,"Coins");
        HeaderButton("Notifications",1430,EclipseVectorIcon.Kind.Bell);HeaderButton("Friends",1510,EclipseVectorIcon.Kind.Friends);HeaderButton("SettingsTop",1590,EclipseVectorIcon.Kind.Gear);
        var badge=Solid(frame,"NotificationBadge",1458,20,20,20,new Color(.9f,.12f,.18f));Label(badge.transform,"Count","!",0,0,20,20,16,TextAnchor.MiddleCenter,true);
    }
    void HeaderButton(string id,float x,EclipseVectorIcon.Kind icon){var hit=Solid(frame,id,x-8,20,59,57,new Color(1,1,1,0));hit.raycastTarget=true;Icon(hit.transform,icon,11,9,36);Click(hit,id);}
    void Profile(){
        var p=Panel(frame,"Profile",32,124,406,157,10);p.borderWidth=0;
        var portrait=Panel(p.transform,"Portrait",3,3,113,110,0);portrait.borderColor=accent;
        if(portraitArt)Art(portrait.transform,"PortraitAsset",portraitArt,3,3,107,104);else Icon(portrait.transform,EclipseVectorIcon.Kind.Agent,22,18,70);
        playerLabel=Label(p.transform,"PlayerName",playerName,138,10,254,36,25,TextAnchor.MiddleLeft,true);
        levelLabel=Label(p.transform,"Level","Lv. "+level,138,51,76,35,23,TextAnchor.MiddleLeft,true);
        Solid(p.transform,"ExperienceTrack",213,64,159,7,new Color(.07f,.13f,.25f));
        xpFill=Solid(p.transform,"ExperienceFill",213,64,159*Mathf.Clamp01((float)experience/Mathf.Max(1,experienceMax)),7,accent);
        xpLabel=Label(p.transform,"Experience","EXP "+experience+" / "+experienceMax.ToString("N0"),266,78,130,24,14);
        Icon(p.transform,EclipseVectorIcon.Kind.Shield,138,103,43);
        Label(p.transform,"Rank","Silver III",195,111,145,30,21,TextAnchor.MiddleLeft,true);
        Click(p,"Profile");
    }
    void LeftCards(){
        var promo=Panel(frame,"AgentPromo",30,370,375,151);Art(promo.transform,"OwnAgentBanner",agentBannerArt,2,2,371,147);
        if(!agentBannerArt){Icon(promo.transform,EclipseVectorIcon.Kind.Agent,25,28,92,accent);Solid(promo.transform,"Accent",160,14,2,123,accent);}
        Label(promo.transform,"Heading","NEW AGENT",180,28,190,32,25,TextAnchor.MiddleLeft,true);Label(promo.transform,"AgentName","\"VYRA\"",180,59,190,35,28,TextAnchor.MiddleLeft,true);
        var get=Solid(promo.transform,"GetNowPlate",224,109,138,30,accent);Label(get.transform,"Text","GET NOW  >>",0,0,138,30,18,TextAnchor.MiddleCenter,true);Click(promo,"AgentPromo");
        var notice=Panel(frame,"Notice",30,539,375,109);Icon(notice.transform,EclipseVectorIcon.Kind.Bell,14,11,27);Label(notice.transform,"Heading","NOTICE",56,8,255,29,21,TextAnchor.MiddleLeft,true);
        Label(notice.transform,"Body","Maintenance will be on\nNov 10, 08:00 (UTC+7).",56,43,278,57,18);Arrow(notice.transform,338,43);Click(notice,"Notice");
    }
    void RightCards(){
        var daily=Panel(frame,"DailyMission",1316,179,326,122);Icon(daily.transform,EclipseVectorIcon.Kind.Bag,15,14,27);Label(daily.transform,"Heading","DAILY MISSION",55,9,195,32,19,TextAnchor.MiddleLeft,true);Label(daily.transform,"Count","0 / 3",249,9,62,32,18);Solid(daily.transform,"Divider",15,45,293,1,new Color(.15f,.29f,.48f));
        Label(daily.transform,"Task","Play 3 matches",16,53,220,33,20);Icon(daily.transform,EclipseVectorIcon.Kind.Diamond,203,81,26,accent);Label(daily.transform,"Reward","x100",234,78,60,30,18,TextAnchor.MiddleLeft,true);Arrow(daily.transform,289,78);Click(daily,"DailyMission");
        var rank=Panel(frame,"SeasonRank",1316,320,326,114);Icon(rank.transform,EclipseVectorIcon.Kind.Shield,14,15,67,new Color(.96f,.7f,.34f));Label(rank.transform,"Heading","SEASON RANK",91,11,215,30,18,TextAnchor.MiddleLeft,true);Label(rank.transform,"Rank","Bronze I",108,43,169,30,21,TextAnchor.MiddleLeft,true);Solid(rank.transform,"RankProgress",108,73,154,5,new Color(.12f,.19f,.31f));Label(rank.transform,"Progress","0 / 1000",108,80,160,26,16);Arrow(rank.transform,287,45);Click(rank,"SeasonRank");
        var map=Panel(frame,"MapPromo",1316,452,326,209);Art(map.transform,"OwnMapArtwork",mapArt,2,2,322,205);
        if(!mapArt){for(int i=0;i<5;i++){float h=35+(i%3)*21;Solid(map.transform,"BuildingPlaceholder_"+i,24+i*55,140-h,43,h,new Color(.05f,.12f,.22f));}Solid(map.transform,"Horizon",15,142,294,2,accent);}
        Solid(map.transform,"CaptionBackground",2,149,322,58,new Color(.006f,.02f,.06f,.94f));var caption=Label(map.transform,"Tag","NEW MAP",15,150,260,26,19,TextAnchor.MiddleLeft,true);caption.color=new Color(1,.8f,.22f);Label(map.transform,"MapName","RESEARCH FACILITY  >>",15,175,300,30,20,TextAnchor.MiddleLeft,true);Click(map,"MapPromo");
    }
    void Navigation(){
        Nav("Operations","Play Missions",30,786,218,115,EclipseVectorIcon.Kind.Target,true);
        Nav("Agents","Select Character",254,790,176,108,EclipseVectorIcon.Kind.Agent);
        Nav("Armory","Upgrade Weapons",445,790,176,108,EclipseVectorIcon.Kind.Weapon);
        Nav("Inventory","Manage Items",635,790,184,108,EclipseVectorIcon.Kind.Bag);
        Nav("Store","Buy Items",835,790,181,108,EclipseVectorIcon.Kind.Cart);
        Nav("Settings","Game Settings",1032,790,179,108,EclipseVectorIcon.Kind.Gear);
        var deploy=Panel(frame,"Deploy",1261,760,386,142,27);deploy.color=new Color(.035f,.30f,.83f,.98f);deploy.bottomTint=new Color(.015f,.08f,.32f,.98f);deploy.borderColor=new Color(.25f,.75f,1);deploy.borderWidth=3;
        Label(deploy.transform,"Title","DEPLOY",45,16,285,72,51,TextAnchor.MiddleCenter,true);Label(deploy.transform,"Subtitle","ENTER THE BATTLEFIELD",40,84,302,33,20,TextAnchor.MiddleCenter,true);Arrow(deploy.transform,327,44);Arrow(deploy.transform,345,44);Click(deploy,"Deploy");
        Solid(frame,"BottomDivider",30,908,1600,1,new Color(.17f,.44f,.81f,.75f));
    }
    void Nav(string title,string subtitle,float x,float y,float w,float h,EclipseVectorIcon.Kind kind,bool active=false){
        var p=Panel(frame,title,x,y,w,h,18);if(active){p.borderColor=accent;p.borderWidth=3;p.color=new Color(.018f,.11f,.29f,.98f);}
        Icon(p.transform,kind,(w-37)/2,12,37);Label(p.transform,"Title",title.ToUpperInvariant(),4,51,w-8,29,20,TextAnchor.MiddleCenter,true);Label(p.transform,"Subtitle",subtitle,4,79,w-8,25,15,TextAnchor.MiddleCenter);Click(p,title);
        if(active){var b=Solid(p.transform,"Notification",w-20,-8,22,22,new Color(.9f,.13f,.2f));Label(b.transform,"Text","!",0,0,22,22,17,TextAnchor.MiddleCenter,true);}
    }
    public void Navigate(string route){onNavigate.Invoke(route);if(route=="Deploy"){onDeploy.Invoke();if(!string.IsNullOrEmpty(deployScene)){if(Application.CanStreamedLevelBeLoaded(deployScene))SceneManager.LoadScene(deployScene);else Debug.LogWarning("Add destination scene to build configuration: "+deployScene);}}Debug.Log("Lobby: "+route,this);}
    // Works after domain reload as well; no hierarchy rebuild required to update counters.
    public void RefreshProfile(){
        var root=transform.Find(Generated);if(!root)return;
        foreach(var t in root.GetComponentsInChildren<Text>(true)){
            if(t.name=="PlayerName")t.text=playerName;
            else if(t.name=="Level")t.text="Lv. "+level;
            else if(t.name=="Experience")t.text="EXP "+experience+" / "+experienceMax.ToString("N0");
            else if(t.name=="Balance"&&t.transform.parent.name=="DiamondWallet")t.text=diamonds.ToString("N0");
            else if(t.name=="Balance"&&t.transform.parent.name=="CoinWallet")t.text=coins.ToString("N0");
        }
        foreach(var r in root.GetComponentsInChildren<RectTransform>(true))if(r.name=="ExperienceFill")r.sizeDelta=new Vector2(159*Mathf.Clamp01((float)experience/Mathf.Max(1,experienceMax)),7);
    }
    static void EnsureEventSystem(){if(UnityEngine.Object.FindObjectOfType<EventSystem>())return;var es=new GameObject("EventSystem",typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
        es.AddComponent<InputSystemUIInputModule>();
#else
        es.AddComponent<StandaloneInputModule>();
#endif
    }
}
