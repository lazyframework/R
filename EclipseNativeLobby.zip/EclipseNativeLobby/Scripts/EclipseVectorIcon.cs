using UnityEngine;
using UnityEngine.UI;
[AddComponentMenu("UI/Eclipse Vector Icon")]
public class EclipseVectorIcon : MaskableGraphic {
    public enum Kind { Target, Agent, Weapon, Bag, Cart, Gear, Diamond, Coin, Bell, Friends, Arrow, Shield }
    public Kind kind;
    [Min(.5f)] public float thickness=2;
    VertexHelper mesh;
    void Line(float x,float y,float a,float b) {
        var r=GetPixelAdjustedRect();Vector2 p=new Vector2(r.xMin+x*r.width,r.yMin+y*r.height),q=new Vector2(r.xMin+a*r.width,r.yMin+b*r.height);
        var n=new Vector2(-(q-p).y,(q-p).x).normalized*thickness*.5f;int k=mesh.currentVertCount;
        foreach(var v in new[]{p+n,q+n,q-n,p-n}){var u=UIVertex.simpleVert;u.position=v;u.color=color;mesh.AddVert(u);}mesh.AddTriangle(k,k+1,k+2);mesh.AddTriangle(k,k+2,k+3);
    }
    void Ring(float x,float y,float radius,int count=24) {for(int i=0;i<count;i++){float a=i*Mathf.PI*2/count,b=(i+1)*Mathf.PI*2/count;Line(x+Mathf.Cos(a)*radius,y+Mathf.Sin(a)*radius,x+Mathf.Cos(b)*radius,y+Mathf.Sin(b)*radius);}}
    void Box(float x,float y,float w,float h){Line(x,y,x+w,y);Line(x+w,y,x+w,y+h);Line(x+w,y+h,x,y+h);Line(x,y+h,x,y);}
    protected override void OnPopulateMesh(VertexHelper vh){vh.Clear();mesh=vh;
        switch(kind){
        case Kind.Target: Ring(.5f,.5f,.30f);Ring(.5f,.5f,.16f);Line(.5f,0,.5f,.35f);Line(.5f,.65f,.5f,1);Line(0,.5f,.35f,.5f);Line(.65f,.5f,1,.5f);break;
        case Kind.Agent: Ring(.5f,.69f,.18f);Line(.20f,.1f,.28f,.35f);Line(.28f,.35f,.5f,.46f);Line(.5f,.46f,.72f,.35f);Line(.72f,.35f,.8f,.1f);Line(.2f,.1f,.8f,.1f);break;
        case Kind.Weapon: Box(.15f,.45f,.6f,.2f);Line(.75f,.56f,1,.56f);Line(.17f,.45f,0,.25f);Line(.5f,.45f,.42f,.15f);Line(.57f,.45f,.6f,.23f);break;
        case Kind.Bag: Box(.15f,.12f,.7f,.64f);Box(.35f,.76f,.3f,.17f);Box(.3f,.23f,.4f,.25f);break;
        case Kind.Cart: Line(.05f,.85f,.2f,.85f);Line(.2f,.85f,.35f,.3f);Line(.35f,.3f,.85f,.3f);Line(.26f,.7f,.95f,.7f);Line(.95f,.7f,.85f,.43f);Line(.85f,.43f,.3f,.43f);Ring(.4f,.12f,.06f,12);Ring(.8f,.12f,.06f,12);break;
        case Kind.Gear:Ring(.5f,.5f,.25f);Ring(.5f,.5f,.1f);for(int i=0;i<8;i++){float a=i*Mathf.PI/4;Line(.5f+Mathf.Cos(a)*.27f,.5f+Mathf.Sin(a)*.27f,.5f+Mathf.Cos(a)*.43f,.5f+Mathf.Sin(a)*.43f);}break;
        case Kind.Diamond:Line(.5f,.95f,.15f,.5f);Line(.15f,.5f,.5f,.05f);Line(.5f,.05f,.85f,.5f);Line(.85f,.5f,.5f,.95f);Line(.5f,.95f,.4f,.4f);Line(.4f,.4f,.5f,.05f);Line(.15f,.5f,.4f,.4f);Line(.4f,.4f,.85f,.5f);break;
        case Kind.Coin: Ring(.5f,.5f,.4f);Ring(.5f,.5f,.3f);Line(.58f,.75f,.4f,.6f);Line(.4f,.6f,.6f,.4f);Line(.6f,.4f,.4f,.25f);break;
        case Kind.Bell:Line(.15f,.25f,.25f,.4f);Line(.25f,.4f,.25f,.7f);Line(.25f,.7f,.5f,.9f);Line(.5f,.9f,.75f,.7f);Line(.75f,.7f,.75f,.4f);Line(.75f,.4f,.85f,.25f);Line(.85f,.25f,.15f,.25f);Ring(.5f,.13f,.06f,12);break;
        case Kind.Friends:Ring(.35f,.7f,.15f);Ring(.72f,.7f,.12f);Line(.08f,.15f,.18f,.4f);Line(.18f,.4f,.5f,.4f);Line(.5f,.4f,.6f,.15f);Line(.64f,.4f,.83f,.4f);Line(.83f,.4f,.95f,.15f);break;
        case Kind.Arrow:Line(.3f,.15f,.7f,.5f);Line(.7f,.5f,.3f,.85f);break;
        case Kind.Shield:Line(.1f,.85f,.5f,.95f);Line(.5f,.95f,.9f,.85f);Line(.9f,.85f,.8f,.3f);Line(.8f,.3f,.5f,.05f);Line(.5f,.05f,.2f,.3f);Line(.2f,.3f,.1f,.85f);Line(.2f,.7f,.5f,.4f);Line(.5f,.4f,.8f,.7f);break;
        }
    }
}
