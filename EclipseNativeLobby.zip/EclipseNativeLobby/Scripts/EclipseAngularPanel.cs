using UnityEngine;
using UnityEngine.UI;

// Procedural geometry only. No source-image pixels, textures or sprites.
[AddComponentMenu("UI/Eclipse Angular Panel")]
public class EclipseAngularPanel : MaskableGraphic {
    [Min(0)] public float corner=16;
    [Min(0)] public float borderWidth=1.5f;
    public Color borderColor=new Color(.20f,.49f,.87f,.9f);
    public Color bottomTint=new Color(.015f,.04f,.10f,.95f);
    Vector2[] Points(float inset) {
        Rect r=GetPixelAdjustedRect();float x=r.xMin+inset,y=r.yMin+inset,w=Mathf.Max(0,r.width-2*inset),h=Mathf.Max(0,r.height-2*inset);
        float c=Mathf.Min(Mathf.Max(0,corner-inset),Mathf.Min(w,h)*.4f);
        return new[]{new Vector2(x,y),new Vector2(x+w-c,y),new Vector2(x+w,y+c),new Vector2(x+w,y+h),new Vector2(x+c,y+h),new Vector2(x,y+h-c)};
    }
    void Vertex(VertexHelper vh,Vector2 p,Color tint) { var v=UIVertex.simpleVert;v.position=p;v.color=tint;vh.AddVert(v); }
    protected override void OnPopulateMesh(VertexHelper vh) {
        vh.Clear();var outer=Points(0);var inner=Points(borderWidth);Rect r=GetPixelAdjustedRect();
        for(int i=0;i<6;i++) Vertex(vh,inner[i],Color.Lerp(bottomTint,color,Mathf.InverseLerp(r.yMin,r.yMax,inner[i].y)));
        for(int i=1;i<5;i++)vh.AddTriangle(0,i,i+1);
        if(borderWidth<=0)return;
        for(int i=0;i<6;i++){int j=(i+1)%6,k=vh.currentVertCount;Vertex(vh,outer[i],borderColor);Vertex(vh,outer[j],borderColor);Vertex(vh,inner[j],borderColor);Vertex(vh,inner[i],borderColor);vh.AddTriangle(k,k+1,k+2);vh.AddTriangle(k,k+2,k+3);}
    }
}
