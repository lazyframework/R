using UnityEngine;
[ExecuteAlways]
public class EclipseFrameFit : MonoBehaviour {
    public Vector2 referenceSize=new Vector2(1672,941);
    void LateUpdate(){var r=transform as RectTransform;var p=transform.parent as RectTransform;if(!r||!p)return;float s=Mathf.Min(p.rect.width/referenceSize.x,p.rect.height/referenceSize.y);r.localScale=new Vector3(s,s,1);}
}
