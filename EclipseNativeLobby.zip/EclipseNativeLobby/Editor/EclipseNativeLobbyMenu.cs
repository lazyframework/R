#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
public static class EclipseNativeLobbyMenu {
    [MenuItem("Tools/Project Eclipse/Create Native Lobby (No Screenshot Assets)")]
    static void Create(){var go=new GameObject("Eclipse Native Lobby");Undo.RegisterCreatedObjectUndo(go,"Create native lobby");var b=go.AddComponent<EclipseNativeLobbyBuilder>();b.Build();Selection.activeGameObject=go;EditorSceneManager.MarkSceneDirty(go.scene);}
}
[CustomEditor(typeof(EclipseNativeLobbyBuilder))]
public class EclipseNativeLobbyInspector:Editor {
    public override void OnInspectorGUI(){DrawDefaultInspector();var b=(EclipseNativeLobbyBuilder)target;
        EditorGUILayout.HelpBox("All UI is procedural/native. Artwork slots are optional and empty. Build replaces generated hierarchy; refresh only updates profile/currency labels.",MessageType.Info);
        if(GUILayout.Button("BUILD / REBUILD NATIVE LAYOUT")){b.Build();EditorUtility.SetDirty(b);if(!Application.isPlaying)EditorSceneManager.MarkSceneDirty(b.gameObject.scene);}
        if(GUILayout.Button("REFRESH PROFILE VALUES")){b.RefreshProfile();if(!Application.isPlaying)EditorSceneManager.MarkSceneDirty(b.gameObject.scene);}
    }
}
#endif
