using UnityEngine;
using UnityEngine.UI;

[AddComponentMenu("UI/Reference Chamfer Panel")]
public class ReferenceChamferPanel : MaskableGraphic
{
    public float cut = 18;
    public float border = 1.5f;
    public Color borderColor = new Color(.15f,.55f,1,.85f);
    public Color fillColor = new Color(.015f,.04f,.095f,.93f);
    protected override void OnPopulateMesh(VertexHelper vh)
    {
        vh.Clear(); Rect r=rectTransform.rect;
        float c=Mathf.Clamp(cut,0,Mathf.Min(r.width,r.height)*.45f);
        Vector2[] a=Points(r,c); float inset=Mathf.Clamp(border,0,Mathf.Min(r.width,r.height)*.25f);
        Rect inner=new Rect(r.x+inset,r.y+inset,r.width-2*inset,r.height-2*inset);
        Vector2[] b=Points(inner,Mathf.Max(0,c-inset*.6f));
        Add(vh,r.center,fillColor);
        for(int i=0;i<8;i++)Add(vh,b[i],fillColor);
        for(int i=0;i<8;i++)vh.AddTriangle(0,1+i,1+(i+1)%8);
        for(int i=0;i<8;i++)Add(vh,a[i],borderColor);
        for(int i=0;i<8;i++)Add(vh,b[i],borderColor);
        for(int i=0;i<8;i++){int j=(i+1)%8;vh.AddTriangle(9+i,9+j,17+j);vh.AddTriangle(9+i,17+j,17+i);}
    }
    static Vector2[] Points(Rect r,float c)
    {return new[]{new Vector2(r.xMin+c,r.yMax),new Vector2(r.xMax-c,r.yMax),new Vector2(r.xMax,r.yMax-c),new Vector2(r.xMax,r.yMin+c),new Vector2(r.xMax-c,r.yMin),new Vector2(r.xMin+c,r.yMin),new Vector2(r.xMin,r.yMin+c),new Vector2(r.xMin,r.yMax-c)};}
    static void Add(VertexHelper v,Vector2 p,Color c){v.AddVert(new Vector3(p.x,p.y,0),c,Vector2.zero);}
#if UNITY_EDITOR
    protected override void OnValidate(){base.OnValidate();SetVerticesDirty();}
#endif
}
