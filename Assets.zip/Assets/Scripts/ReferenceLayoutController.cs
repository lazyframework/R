using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
public class ReferenceLayoutController : MonoBehaviour
{
    [System.Serializable] public class Agent
    {
        public string name="Agent 013",role="Assault";
        public Sprite portrait;
        public GameObject prefab;
        [TextArea] public string description="A skilled soldier with exceptional combat skills. Trained to handle any situation on the battlefield.";
        public int level=12,exp=720,maxExp=2000,hp=100,armor=80,attack=95,speed=90;
    }
    public Agent[] agents;
    public Button[] cards;
    public Image[] portraits;
    public GameObject[] selectedTags;
    public Button previous,next,confirm;
    public Transform previewAnchor;
    public Text nameText,roleText,levelText,expText,descriptionText;
    public Text[] values;
    public RectTransform expBar;
    public RectTransform[] statBars;
    public UnityEvent onConfirm=new UnityEvent();
    int index; GameObject model;
    void Start()
    {
        for(int i=0;i<cards.Length;i++){int n=i;cards[i].onClick.AddListener(()=>Select(n));}
        previous.onClick.AddListener(()=>Select((index+agents.Length-1)%agents.Length));
        next.onClick.AddListener(()=>Select((index+1)%agents.Length));
        confirm.onClick.AddListener(()=>{PlayerPrefs.SetInt("SelectedAgentIndex",index);PlayerPrefs.Save();onConfirm.Invoke();});
        Select(Mathf.Clamp(PlayerPrefs.GetInt("SelectedAgentIndex",0),0,agents.Length-1));
    }
    public void Select(int n)
    {
        if(n<0||n>=agents.Length)return;index=n;var a=agents[n];
        nameText.text=a.name;roleText.text=a.role;levelText.text="Lv. "+a.level;expText.text="EXP "+a.exp+" / "+a.maxExp.ToString("N0");descriptionText.text=a.description;
        expBar.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal,204*Mathf.Clamp01(a.exp/(float)Mathf.Max(1,a.maxExp)));
        int[] stats={a.hp,a.armor,a.attack,a.speed};
        for(int i=0;i<4;i++){values[i].text=stats[i].ToString();statBars[i].SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal,186*Mathf.Clamp01(stats[i]/150f));}
        for(int i=0;i<cards.Length;i++)
        {
            selectedTags[i].SetActive(i==n);
            var p=cards[i].GetComponent<ReferenceChamferPanel>();p.borderColor=i==n?new Color(.1f,.8f,1):new Color(.25f,.45f,.7f);p.border=i==n?4:1;p.SetVerticesDirty();
            if(i<agents.Length&&agents[i].portrait!=null){portraits[i].sprite=agents[i].portrait;portraits[i].color=Color.white;}
        }
        if(model!=null)Destroy(model);
        if(a.prefab!=null&&previewAnchor!=null){model=Instantiate(a.prefab,previewAnchor);model.transform.localPosition=Vector3.zero;model.transform.localRotation=Quaternion.identity;}
    }
}
