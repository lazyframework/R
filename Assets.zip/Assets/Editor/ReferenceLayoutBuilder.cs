using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEditor;
using UnityEditor.SceneManagement;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif
public static class ReferenceLayoutBuilder
{
    static Font font;static Color cyan=new Color(.04f,.55f,1);static Color navy=new Color(.01f,.035f,.09f,.94f);
    [MenuItem("Tools/Reference Layout/Build Original Layout")]
    public static void Build()
    {
        if(Application.isPlaying)return;
        if(GameObject.Find("OriginalReferenceLayout")!=null){EditorUtility.DisplayDialog("Layout","Layout already exists. Remove the old root to rebuild.","OK");return;}
        font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        var root=new GameObject("OriginalReferenceLayout");Undo.RegisterCreatedObjectUndo(root,"Build Reference Layout");
        var c=root.AddComponent<ReferenceLayoutController>();
        var canvas=new GameObject("Canvas 1672x941",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));canvas.transform.SetParent(root.transform,false);
        canvas.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
        var scale=canvas.GetComponent<CanvasScaler>();scale.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scale.referenceResolution=new Vector2(1672,941);scale.matchWidthOrHeight=.5f;
        Transform ui=canvas.transform;
        var bg=Image("OPTIONAL Hangar Background - assign sprite",ui,0,0,1672,941,new Color(.01f,.025f,.065f));bg.gameObject.SetActive(false);
        Image("Header shade",ui,0,0,1672,80,navy);Line(ui,0,78,1672,1);
        var back=Btn("BACK",ui,28,17,76,54,navy);Chevron(back.transform,26,14,23,29,false);
        var heading=Text("SELECT CHARACTER",ui,135,24,350,46,32);heading.fontStyle=FontStyle.BoldAndItalic;
        for(int i=0;i<4;i++){var stripe=Image("Title slash",ui,480+i*19,32,11,25,new Color(.3f,.5f,.95f));stripe.rectTransform.localRotation=Quaternion.Euler(0,0,-32);}
        var gem=Btn("Premium Currency",ui,1084,22,170,44,navy);Diamond(gem.transform,17,10,22,25,cyan);Text("1,200",gem.transform,55,6,86,35,24);Text("+",gem.transform,138,1,28,40,32);
        var coin=Btn("Coins",ui,1270,22,176,44,navy);Diamond(coin.transform,17,10,24,24,new Color(1,.65f,.12f));Text("15,340",coin.transform,55,6,99,35,24);Text("+",coin.transform,146,1,28,40,32);
        var notify=Btn("Notifications",ui,1480,20,55,48,new Color(0,0,0,0));Text("!",notify.transform,15,2,30,45,36).alignment=TextAnchor.MiddleCenter;
        Image("Alert badge",ui,1512,18,16,18,new Color(1,.05f,.15f));
        var home=Btn("Home",ui,1575,20,58,48,new Color(0,0,0,0));Text("⌂",home.transform,3,0,52,47,39).alignment=TextAnchor.MiddleCenter;
        c.agents=new ReferenceLayoutController.Agent[5];c.cards=new Button[5];c.portraits=new Image[5];c.selectedTags=new GameObject[5];
        for(int i=0;i<5;i++)
        {
            c.agents[i]=new ReferenceLayoutController.Agent{name="Agent "+(13+i).ToString("000")};
            var card=Btn("Portrait Card "+(i+1),ui,40,112+i*137,234,125,new Color(.02f,.055f,.12f,.78f));c.cards[i]=card;
            var p=Image("Portrait - assign character sprite",card.transform,5,5,224,115,new Color(.065f,.1f,.16f,.55f));p.preserveAspect=true;c.portraits[i]=p;
            var tag=Panel("SELECTED ribbon",card.transform,110,94,122,29,new Color(0,.3f,.9f,.95f),8,1);
            Text("SELECTED",tag.transform,7,2,110,27,18).fontStyle=FontStyle.BoldAndItalic;tag.gameObject.SetActive(i==0);c.selectedTags[i]=tag.gameObject;
        }
        c.previous=Btn("Previous",ui,490,430,78,85,new Color(0,.25f,.65f,.7f));Chevron(c.previous.transform,20,19,32,46,false);
        c.next=Btn("Next",ui,1107,430,78,85,new Color(0,.25f,.65f,.7f));Chevron(c.next.transform,24,19,32,46,true);
        var details=Panel("Right Information Panel",ui,1236,103,408,682,navy,0,1).transform;
        c.nameText=Text("Agent 013",details,30,22,282,50,36);c.nameText.fontStyle=FontStyle.Bold;
        c.roleText=Text("Assault",details,30,72,290,34,24);
        Diamond(details,328,23,42,58,new Color(.65f,.78f,.95f));Diamond(details,340,38,18,28,cyan);
        Line(details,30,120,352,1);
        c.levelText=Text("Lv. 12",details,30,132,175,36,28);c.levelText.fontStyle=FontStyle.Bold;
        Image("EXP track",details,30,171,204,12,new Color(.08f,.14f,.25f));c.expBar=Image("EXP fill",details,30,171,159,12,cyan).rectTransform;
        c.expText=Text("EXP 720 / 2,000",details,240,168,164,25,14);Line(details,30,195,352,1);
        c.descriptionText=Text(c.agents[0].description,details,30,205,350,96,19);Line(details,30,303,352,1);
        Text("SKILL",details,30,311,340,32,23).fontStyle=FontStyle.Bold;
        string[] skillNames={"Tactical\nDash","Combat\nFocus","Energy\nShield","Ultimate\nStrike"};
        for(int i=0;i<4;i++)
        {
            var b=Btn("Skill "+i,details,30+i*95,353,65,65,new Color(0,.08f,.22f,.5f));b.GetComponent<ReferenceChamferPanel>().cut=30;
            Diamond(b.transform,22,14,20,36,cyan);var sl=Text(skillNames[i],details,24+i*95,426,84,55,17);sl.alignment=TextAnchor.UpperCenter;
        }
        Line(details,30,477,352,1);Text("STATS",details,30,489,330,32,23).fontStyle=FontStyle.Bold;
        string[] names={"HP","Armor","Attack","Speed"};int[] stats={100,80,95,90};c.values=new Text[4];c.statBars=new RectTransform[4];
        for(int i=0;i<4;i++)
        {
            Diamond(details,36,532+i*34,14,17,new Color(.75f,.86f,1));Text(names[i],details,68,525+i*34,98,30,19);
            Image("Stat track",details,154,533+i*34,186,11,new Color(.08f,.14f,.25f));c.statBars[i]=Image("Stat fill",details,154,533+i*34,186*stats[i]/150f,11,cyan).rectTransform;
            c.values[i]=Text(stats[i].ToString(),details,350,525+i*34,48,28,19);
        }
        Line(ui,0,819,1672,1);
        var custom=Btn("Customize",ui,40,841,240,70,navy);Text("CUSTOMIZE",custom.transform,88,19,145,36,24).fontStyle=FontStyle.Bold;
        Text("◇",custom.transform,27,10,52,50,38);
        var skin=Btn("Skin",ui,303,841,194,70,navy);Text("SKIN",skin.transform,95,19,88,36,24).fontStyle=FontStyle.Bold;Diamond(skin.transform,41,22,25,30,new Color(.75f,.87f,1));
        c.confirm=Btn("Confirm",ui,1258,826,386,85,new Color(0,.26f,.88f,.97f));c.confirm.GetComponent<ReferenceChamferPanel>().border=3;
        Text("CONFIRM",c.confirm.transform,100,21,210,50,36).fontStyle=FontStyle.BoldAndItalic;Chevron(c.confirm.transform,305,27,22,32,true);Chevron(c.confirm.transform,329,27,22,32,true);
        var preview=new GameObject("PreviewAnchor - assign 3D prefabs on controller");preview.transform.SetParent(root.transform,false);c.previewAnchor=preview.transform;
        if(Object.FindFirstObjectByType<EventSystem>()==null)
        {
            var es=new GameObject("EventSystem",typeof(EventSystem));es.transform.SetParent(root.transform,false);
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }
        EditorSceneManager.MarkSceneDirty(root.scene);Selection.activeGameObject=root;
        EditorUtility.DisplayDialog("Original Reference Layout","Layout created in current scene. View at 16:9 and save scene. Portraits and 3D environment are not included. See README.","OK");
    }
    static RectTransform Rect(string name,Transform p,float x,float y,float w,float h)
    {var o=new GameObject(name,typeof(RectTransform));o.transform.SetParent(p,false);var r=o.GetComponent<RectTransform>();r.anchorMin=r.anchorMax=r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(w,h);return r;}
    static ReferenceChamferPanel Panel(string name,Transform p,float x,float y,float w,float h,Color color,float cut,float border)
    {var a=Rect(name,p,x,y,w,h).gameObject.AddComponent<ReferenceChamferPanel>();a.fillColor=color;a.borderColor=new Color(.25f,.5f,.8f,.9f);a.cut=cut;a.border=border;a.raycastTarget=false;return a;}
    static Image Image(string name,Transform p,float x,float y,float w,float h,Color color)
    {var a=Rect(name,p,x,y,w,h).gameObject.AddComponent<Image>();a.color=color;a.raycastTarget=false;return a;}
    static Text Text(string text,Transform p,float x,float y,float w,float h,int size)
    {var t=Rect(text,p,x,y,w,h).gameObject.AddComponent<Text>();t.text=text;t.font=font;t.fontSize=size;t.color=new Color(.9f,.95f,1);t.raycastTarget=false;return t;}
    static Button Btn(string name,Transform p,float x,float y,float w,float h,Color color)
    {var panel=Panel(name,p,x,y,w,h,color,16,1);panel.raycastTarget=true;var b=panel.gameObject.AddComponent<Button>();b.targetGraphic=panel;return b;}
    static void Line(Transform p,float x,float y,float w,float h){Image("Divider",p,x,y,w,h,new Color(.17f,.4f,.7f,.6f));}
    static void Diamond(Transform p,float x,float y,float w,float h,Color color)
    {var d=Panel("Vector Diamond",p,x,y,w,h,color,Mathf.Min(w,h)*.44f,1);d.borderColor=color;}
    static void Chevron(Transform p,float x,float y,float w,float h,bool right)
    {
        for(int i=0;i<2;i++){var a=Image("Chevron",p,x,y+i*h*.5f,w*.65f,h*.17f,new Color(.6f,.9f,1));a.rectTransform.pivot=new Vector2(.5f,.5f);a.rectTransform.anchoredPosition=new Vector2(x+w*.5f,-y-h*.25f-i*h*.5f);a.rectTransform.localRotation=Quaternion.Euler(0,0,(right?1:-1)*(i==0?45:-45));}
    }
}
