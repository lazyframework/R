#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class EclipseStyledLobbyMenu
{
    [MenuItem("Tools/Project Eclipse/Create Styled Lobby")]
    static void Create()
    {
        var go = new GameObject("Eclipse Styled Lobby");
        Undo.RegisterCreatedObjectUndo(go, "Create Styled Lobby");
        go.AddComponent<EclipseStyledLobbyBuilder>().Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }

    [MenuItem("Tools/Project Eclipse/Reimport Lobby Textures")]
    static void Reimport()
    {
        foreach (var guid in AssetDatabase.FindAssets("t:Texture2D", new[] { "Assets" }))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (path.Replace('\\', '/').Contains("/Resources/EclipseLobby/"))
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
        }
        AssetDatabase.Refresh();
        Debug.Log("Eclipse lobby textures reimported as Sprites.");
    }
}

// Semua PNG di Resources/EclipseLobby otomatis jadi Sprite (tanpa kompresi, tanpa mipmap).
public class EclipseLobbyTextureImporter : AssetPostprocessor
{
    void OnPreprocessTexture()
    {
        if (!assetPath.Replace('\\', '/').Contains("/Resources/EclipseLobby/")) return;
        var ti = (TextureImporter)assetImporter;
        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 100;
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.filterMode = FilterMode.Bilinear;
        ti.maxTextureSize = 2048;
        ti.textureCompression = TextureImporterCompression.Uncompressed;
    }
}

[CustomEditor(typeof(EclipseStyledLobbyBuilder))]
public class EclipseStyledLobbyInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Lobby dibangun ulang otomatis setiap Play. Tombol di bawah hanya untuk pratinjau di editor " +
            "(pratinjau tidak ikut tersimpan ke scene). Gambar dimuat dari Resources/EclipseLobby.",
            MessageType.Info);
        if (GUILayout.Button("PREVIEW STYLED LOBBY"))
        {
            var b = (EclipseStyledLobbyBuilder)target;
            b.Build();
        }
        if (GUILayout.Button("REIMPORT LOBBY TEXTURES"))
        {
            EditorApplication.ExecuteMenuItem("Tools/Project Eclipse/Reimport Lobby Textures");
        }
    }
}
#endif
