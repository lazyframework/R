#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class EclipseStyledLobbyMenu
{
    [MenuItem("Tools/Project Eclipse/Create Character Select")]
    static void CreateCharacterSelect()
    {
        var go = new GameObject("Eclipse Character Select");
        Undo.RegisterCreatedObjectUndo(go, "Create Character Select");
        var bld = go.AddComponent<EclipseCharacterSelectBuilder>();
        if (go.transform.Find("EclipseCharacterCanvas_v1") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }

    [MenuItem("Tools/Project Eclipse/Create Styled Lobby")]
    static void Create()
    {
        var go = new GameObject("Eclipse Styled Lobby");
        Undo.RegisterCreatedObjectUndo(go, "Create Styled Lobby");
        var bld = go.AddComponent<EclipseStyledLobbyBuilder>(); if (go.transform.Find("EclipseLobbyCanvas_v2") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }
}

[CustomEditor(typeof(EclipseStyledLobbyBuilder))]
public class EclipseStyledLobbyInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Lobby dibangun ulang otomatis setiap Play. Tombol di bawah hanya untuk pratinjau di editor " +
            "(pratinjau tidak ikut tersimpan ke scene).",
            MessageType.Info);
        if (GUILayout.Button("BUILD STYLED LOBBY"))
        {
            var b = (EclipseStyledLobbyBuilder)target;
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Styled Lobby");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
    }
}

[CustomEditor(typeof(EclipseCharacterSelectBuilder))]
public class EclipseCharacterSelectInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Layar dibangun langsung di editor. Isi sprite / daftar agen, lalu klik BUILD untuk membangun ulang " +
            "(hasil edit manual di hierarki akan diganti). Mengubah data agen saat Play langsung terlihat lewat tombol REFRESH.",
            MessageType.Info);
        var b = (EclipseCharacterSelectBuilder)target;
        if (GUILayout.Button("BUILD CHARACTER SELECT"))
        {
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Character Select");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
        if (GUILayout.Button("REFRESH DATA"))
        {
            b.Refresh();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
    }
}
#endif
