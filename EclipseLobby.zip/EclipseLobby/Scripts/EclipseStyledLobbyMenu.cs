#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class EclipseStyledLobbyMenu
{
    [MenuItem("Tools/Project Eclipse/Create Styled Lobby")]
    static void Create()
    {
        var go = new GameObject("Eclipse Styled Lobby");
        Undo.RegisterCreatedObjectUndo(go, "Create Styled Lobby");
        var bld = go.AddComponent<EclipseStyledLobbyBuilder>(); if (go.transform.Find("EclipseLobbyCanvas_v2") == null) bld.Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }
}

[CustomEditor(typeof(EclipseStyledLobbyBuilder))]
public class EclipseStyledLobbyInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Lobby dibangun ulang otomatis setiap Play. Tombol di bawah hanya untuk pratinjau di editor " +
            "(pratinjau tidak ikut tersimpan ke scene).",
            MessageType.Info);
        if (GUILayout.Button("BUILD STYLED LOBBY"))
        {
            var b = (EclipseStyledLobbyBuilder)target;
            Undo.RegisterFullObjectHierarchyUndo(b.gameObject, "Build Styled Lobby");
            b.Build();
            if (!Application.isPlaying) EditorSceneManager.MarkSceneDirty(b.gameObject.scene);
        }
    }
}
#endif
