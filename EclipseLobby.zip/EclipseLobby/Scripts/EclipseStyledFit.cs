using UnityEngine;
[ExecuteAlways] public class EclipseStyledFit:MonoBehaviour {void LateUpdate(){var r=transform as RectTransform;var p=transform.parent as RectTransform;if(r&&p){float s=Mathf.Min(p.rect.width/1672f,p.rect.height/941f);r.localScale=new Vector3(s,s,1);}}}
