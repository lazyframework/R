using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

// Lobby "Project Eclipse" v2.
// - Tidak memakai mesh kustom (MaskableGraphic). Semua pakai Image biasa, jadi tampil di renderer apa pun.
// - Frame panel dibuat dari sprite 9-slice yang dihasilkan lewat kode.
// - Seni (latar, ikon, potret, banner, peta) dimuat dari Resources/EclipseLobby/.
// - Dibangun ulang setiap Play, jadi tidak ada hierarki lama yang basi.
public class EclipseStyledLobbyBuilder : MonoBehaviour
{
    [Header("Opsional: isi untuk menimpa gambar bawaan dari Resources/EclipseLobby")]
    public Font font;
    public Sprite background, portrait, agentBanner, mapArtwork;
    public RenderTexture characterPreview;

    [Header("Profile")]
    public string playerName = "FamaLine";
    public int level = 12, diamonds = 1200, coins = 15340;

    [Serializable] public class RouteEvent : UnityEvent<string> { }
    public RouteEvent onNavigate = new RouteEvent();
    public UnityEvent onDeploy = new UnityEvent();
    public Color cyan = new Color(.15f, .65f, 1, 1);

    const string Root = "EclipseLobbyCanvas_v2";
    const string Legacy = "StyledLobbyCanvas";

    RectTransform frame;
    readonly Dictionary<Transform, Vector2> origin = new Dictionary<Transform, Vector2>();
    readonly Dictionary<string, Sprite> cache = new Dictionary<string, Sprite>();

    static Sprite sFill, sLine, sGlow, sRing, sDisc;

    // Warna
    static readonly Color Txt = new Color(.92f, .96f, 1f);
    static readonly Color Dim = new Color(.62f, .74f, .9f);
    static readonly Color PanelFill = new Color(.02f, .06f, .14f, .86f);
    static readonly Color PanelLine = new Color(.24f, .48f, .82f, .95f);
    static readonly Color BrightFill = new Color(.03f, .30f, .88f, .96f);
    static readonly Color BrightLine = new Color(.40f, .78f, 1f, 1f);

    void Start()
    {
        Build();
    }

    public void Route(string id)
    {
        onNavigate.Invoke(id);
        if (id == "Deploy") onDeploy.Invoke();
        Debug.Log("Lobby: " + id, this);
    }

    // ---------------------------------------------------------------- helpers

    RectTransform R(Transform p, string n, float x, float y, float w, float h)
    {
        var go = new GameObject(n, typeof(RectTransform));
        var r = go.GetComponent<RectTransform>();
        r.SetParent(p, false);
        Vector2 o;
        origin.TryGetValue(p, out o);
        r.anchorMin = r.anchorMax = new Vector2(0, 1);
        r.pivot = new Vector2(0, 1);
        r.anchoredPosition = new Vector2(x - o.x, -(y - o.y));
        r.sizeDelta = new Vector2(w, h);
        origin[r] = new Vector2(x, y);
        return r;
    }

    Image Img(Transform p, string n, float x, float y, float w, float h, Sprite s, Color c, bool sliced = false, bool ray = false)
    {
        var i = R(p, n, x, y, w, h).gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = c;
        i.raycastTarget = ray;
        if (s != null)
        {
            if (sliced) i.type = Image.Type.Sliced;
            else i.preserveAspect = true;
        }
        return i;
    }

    Text T(Transform p, string n, string s, float x, float cy, float w, int size, bool bold = false,
           TextAnchor a = TextAnchor.MiddleLeft, bool italic = false, Color? col = null)
    {
        float h = size * 1.6f;
        var t = R(p, n, x, cy - h / 2f, w, h).gameObject.AddComponent<Text>();
        t.font = font;
        t.text = s;
        t.fontSize = size;
        t.fontStyle = bold ? (italic ? FontStyle.BoldAndItalic : FontStyle.Bold) : (italic ? FontStyle.Italic : FontStyle.Normal);
        t.color = col ?? Txt;
        t.alignment = a;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    Image S(Transform p, string n, float x, float y, float w, float h, Color c)
    {
        return Img(p, n, x, y, w, h, null, c);
    }

    Sprite Load(string n, Sprite over = null)
    {
        if (over != null) return over;
        Sprite s;
        if (cache.TryGetValue(n, out s)) return s;
        s = Resources.Load<Sprite>("EclipseLobby/" + n);
        if (s == null)
        {
            var t = Resources.Load<Texture2D>("EclipseLobby/" + n);
            if (t != null) s = Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(.5f, .5f), 100f);
        }
        cache[n] = s;
        return s;
    }

    Image Icon(Transform p, string n, string sprite, float x, float y, float w, float h)
    {
        var s = Load(sprite);
        if (s == null) return null;
        return Img(p, n, x, y, w, h, s, Color.white);
    }

    // Panel = akar + Glow(opsional) + Fill + Outline
    RectTransform Panel(Transform p, string n, float x, float y, float w, float h, Color fill, Color line, float glow = 0, bool art = false)
    {
        var r = R(p, n, x, y, w, h);
        if (glow > 0)
        {
            var g = Img(r, "Glow", x - 20, y - 20, w + 40, h + 40, GlowSprite(), new Color(.1f, .5f, 1f, glow), true);
        }
        if (!art) Img(r, "Fill", x, y, w, h, FillSprite(), fill, true);
        Img(r, "Outline", x, y, w, h, LineSprite(), line, true);
        return r;
    }

    void Detail(Transform p, float x, float y, float w, float h)
    {
        S(p, "TopAccent", x + 22, y + 1, Mathf.Min(64, w * .24f), 2, cyan);
        S(p, "LowerTrace", x + 14, y + h - 7, w - 52, 1, new Color(.10f, .35f, .61f, .55f));
        for (int i = 0; i < 3; i++)
        {
            var t = S(p, "Slash" + i, x + w - 30 + i * 7, y + h - 13, 3, 9, new Color(.17f, .55f, .89f, .75f));
            t.rectTransform.localEulerAngles = new Vector3(0, 0, -30);
        }
    }

    void Click(RectTransform root)
    {
        var fill = root.Find("Fill");
        Graphic target = null;
        var outline = root.Find("Outline");
        if (outline != null) target = outline.GetComponent<Graphic>();
        if (target == null)
        {
            var ic = root.Find("Icon");
            if (ic != null) target = ic.GetComponent<Graphic>();
        }
        if (fill != null) fill.GetComponent<Graphic>().raycastTarget = true;
        else
        {
            // panel tanpa fill / ikon: pakai gambar transparan sebagai area klik
            var hit = Img(root, "Hit", origin[root].x, origin[root].y, root.sizeDelta.x, root.sizeDelta.y, null, new Color(0, 0, 0, 0), false, true);
            if (target == null) target = hit;
        }
        if (target == null) target = root.GetComponentInChildren<Graphic>();
        var b = root.gameObject.AddComponent<Button>();
        b.targetGraphic = target;
        var c = b.colors;
        c.normalColor = new Color(.88f, .92f, 1f, 1f);
        c.highlightedColor = Color.white;
        c.pressedColor = new Color(.6f, .78f, 1f, 1f);
        c.selectedColor = Color.white;
        c.fadeDuration = .1f;
        b.colors = c;
        string id = root.name;
        b.onClick.AddListener(() => Route(id));
    }

    // ---------------------------------------------------------------- sprite generator

    static float Sd(float x, float y, float x0, float y0, float x1, float y1, float c)
    {
        float d = Mathf.Min(Mathf.Min(x - x0, x1 - x), Mathf.Min(y - y0, y1 - y));
        float tl = ((x - x0) + (y1 - y) - c) * 0.70710678f; // pojok kiri-atas terpotong
        float br = ((x1 - x) + (y - y0) - c) * 0.70710678f; // pojok kanan-bawah terpotong
        return Mathf.Min(d, Mathf.Min(tl, br));
    }

    static Sprite Make(string name, int w, int h, int border, Func<float, float, Color> px)
    {
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.name = name;
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        t.hideFlags = HideFlags.HideAndDontSave;
        var cols = new Color32[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                cols[y * w + x] = px(x + .5f, y + .5f);
        t.SetPixels32(cols);
        t.Apply();
        var s = Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect,
                              new Vector4(border, border, border, border));
        s.name = name;
        s.hideFlags = HideFlags.HideAndDontSave;
        return s;
    }

    static Sprite FillSprite()
    {
        if (sFill == null)
            sFill = Make("EclipseFill", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f);
                float g = Mathf.Lerp(.72f, 1f, y / 64f);
                return new Color(g, g, g, a);
            });
        return sFill;
    }

    static Sprite LineSprite()
    {
        if (sLine == null)
            sLine = Make("EclipseLine", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f) * Mathf.Clamp01(2.1f - d);
                return new Color(1, 1, 1, a);
            });
        return sLine;
    }

    static Sprite GlowSprite()
    {
        if (sGlow == null)
            sGlow = Make("EclipseGlow", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 20, 20, 44, 44, 12);
                float a = d >= 0 ? 1f : Mathf.Pow(Mathf.Clamp01(1f + d / 20f), 2.2f);
                return new Color(1, 1, 1, a);
            });
        return sGlow;
    }

    static Sprite RingSprite()
    {
        if (sRing == null)
            sRing = Make("EclipseRing", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(1.6f - Mathf.Abs(r - 13.5f) + .5f));
            });
        return sRing;
    }

    static Sprite DiscSprite()
    {
        if (sDisc == null)
            sDisc = Make("EclipseDisc", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(15f - r));
            });
        return sDisc;
    }

    // ---------------------------------------------------------------- build

    [ContextMenu("Build Styled Lobby")]
    public void Build()
    {
        foreach (var name in new[] { Root, Legacy })
        {
            Transform old;
            while ((old = transform.Find(name)) != null)
            {
                old.gameObject.SetActive(false);
                old.SetParent(null);
                if (Application.isPlaying) Destroy(old.gameObject);
                else DestroyImmediate(old.gameObject);
            }
        }

        origin.Clear();
        cache.Clear();

        if (font == null)
        {
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        var go = new GameObject(Root, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.transform.SetParent(transform, false);
        var canvas = go.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scale = go.GetComponent<CanvasScaler>();
        scale.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scale.referenceResolution = new Vector2(1672, 941);
        scale.matchWidthOrHeight = .5f;

        // latar penuh layar (untuk area letterbox)
        var lb = new GameObject("Letterbox", typeof(RectTransform), typeof(Image));
        lb.transform.SetParent(go.transform, false);
        var lbr = lb.GetComponent<RectTransform>();
        lbr.anchorMin = Vector2.zero; lbr.anchorMax = Vector2.one; lbr.offsetMin = lbr.offsetMax = Vector2.zero;
        var lbi = lb.GetComponent<Image>();
        lbi.color = new Color(.01f, .02f, .05f, 1);
        lbi.raycastTarget = false;

        frame = new GameObject("ReferenceFrame", typeof(RectTransform)).GetComponent<RectTransform>();
        frame.SetParent(go.transform, false);
        frame.anchorMin = frame.anchorMax = frame.pivot = new Vector2(.5f, .5f);
        frame.sizeDelta = new Vector2(1672, 941);
        frame.anchoredPosition = Vector2.zero;
        origin[frame] = Vector2.zero;
        frame.gameObject.AddComponent<EclipseStyledFit>();

        Background();
        Header();
        Profile();
        Left();
        Right();
        Bottom();

#if UNITY_2023_1_OR_NEWER
        bool noES = UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null;
#else
        bool noES = UnityEngine.Object.FindObjectOfType<EventSystem>() == null;
#endif
        if (noES)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        if (!Application.isPlaying)
        {
            // pratinjau di editor: jangan ikut tersimpan ke scene (sprite buatan kode tidak bisa diserialisasi)
            foreach (var t in go.GetComponentsInChildren<Transform>(true)) t.gameObject.hideFlags = HideFlags.DontSave;
        }
    }

    void Background()
    {
        var bgSprite = Load("bg_clean", background);
        if (bgSprite != null)
        {
            var bg = Img(frame, "Backdrop", 0, 0, 1672, 941, bgSprite, Color.white);
            bg.preserveAspect = false;
        }
        else
        {
            S(frame, "Backdrop", 0, 0, 1672, 941, new Color(.015f, .048f, .105f));
        }

        if (characterPreview != null)
        {
            var raw = R(frame, "CharacterStage_OwnRenderTexture", 530, 112, 700, 675).gameObject.AddComponent<RawImage>();
            raw.texture = characterPreview;
            raw.raycastTarget = false;
        }
    }

    void Header()
    {
        Icon(frame, "Logo", "ic_logo", 30, 12, 125, 90);
        T(frame, "Project", "PROJECT", 176, 38, 260, 21, true, TextAnchor.MiddleLeft, true);
        T(frame, "Brand", "ECLIPSE", 172, 70, 300, 46, true, TextAnchor.MiddleLeft, true);

        // dompet berlian
        var d = Panel(frame, "Diamonds", 1047, 27, 160, 44, new Color(.01f, .04f, .10f, .85f), new Color(.2f, .42f, .74f, .9f));
        Icon(d, "Gem", "ic_gem", 1054, 28, 34, 42);
        T(d, "Balance", diamonds.ToString("N0"), 1098, 49, 80, 23, true);
        S(d, "PlusDivider", 1166, 31, 1, 36, new Color(.2f, .4f, .7f, .5f));
        T(d, "Plus", "+", 1166, 48, 41, 32, false, TextAnchor.MiddleCenter);
        Click(d);

        // dompet koin
        var c = Panel(frame, "Coins", 1222, 27, 168, 44, new Color(.01f, .04f, .10f, .85f), new Color(.2f, .42f, .74f, .9f));
        Icon(c, "Coin", "ic_coin", 1226, 29, 38, 40);
        T(c, "Balance", coins.ToString("N0"), 1272, 49, 90, 23, true);
        S(c, "PlusDivider", 1350, 31, 1, 36, new Color(.2f, .4f, .7f, .5f));
        T(c, "Plus", "+", 1350, 48, 40, 32, false, TextAnchor.MiddleCenter);
        Click(c);

        Top("Notifications", "ic_bell", 1425, 22, 55, 50);
        Top("Friends", "ic_friends", 1505, 28, 51, 42);
        Top("SettingsTop", "ic_gear", 1586, 26, 52, 44);

        S(frame, "HeaderRule", 30, 106, 1610, 1, new Color(.15f, .36f, .65f, .35f));
    }

    void Top(string id, string sprite, float x, float y, float w, float h)
    {
        var r = R(frame, id, x, y, w, h);
        Icon(r, "Icon", sprite, x, y, w, h);
        Click(r);
    }

    void Profile()
    {
        var r = R(frame, "ProfileGroup", 32, 125, 406, 158);

        var p = Panel(r, "Portrait", 36, 126, 114, 110, Color.clear, BrightLine, 0, true);
        var ps = Load("portrait", portrait);
        if (ps != null)
        {
            var pi = Img(p, "OwnPortrait", 38, 128, 110, 106, ps, Color.white);
            pi.preserveAspect = false;
            pi.transform.SetAsFirstSibling();
        }
        Click(p);

        T(r, "PlayerName", playerName, 171, 157, 255, 24, true);
        T(r, "Level", "Lv. " + level, 171, 199, 88, 26, true, TextAnchor.MiddleLeft, true);
        S(r, "XPTrack", 245, 187, 160, 6, new Color(.06f, .14f, .30f, 1));
        S(r, "XPFill", 245, 187, 58, 6, cyan);
        S(r, "XPLine", 245, 207, 58, 2, new Color(.3f, .7f, 1f, .9f));
        T(r, "Experience", "EXP 720 / 2,000", 300, 212, 130, 14);

        Icon(r, "RankIcon", "ic_shield_rank", 168, 222, 52, 54);
        T(r, "Rank", "Silver III", 228, 252, 125, 20, true);
        Img(r, "InfoRing", 307, 241, 22, 22, RingSprite(), Dim);
        T(r, "Info", "i", 307, 252, 22, 14, false, TextAnchor.MiddleCenter, true, Dim);
    }

    void Left()
    {
        // NEW AGENT
        var p = Panel(frame, "AgentPromo", 30, 372, 375, 148, new Color(.02f, .1f, .3f, .95f), BrightLine, 0, true);
        var bs = Load("agent_banner", agentBanner);
        if (bs != null)
        {
            var bi = Img(p, "OwnBanner", 32, 372, 372, 148, bs, Color.white);
            bi.preserveAspect = false;
            bi.transform.SetAsFirstSibling();
        }
        T(p, "Heading", "NEW AGENT", 211, 419, 190, 26, true, TextAnchor.MiddleLeft, true);
        T(p, "AgentName", "\u201CVYRA\u201D", 211, 452, 190, 32, true, TextAnchor.MiddleLeft, true);
        var get = Panel(p, "GetNow", 253, 481, 142, 28, new Color(.18f, .52f, .95f, .96f), new Color(.55f, .83f, 1f, 1f));
        T(get, "Label", "GET NOW  \u00BB", 253, 495, 142, 17, true, TextAnchor.MiddleCenter, true);
        Click(p);

        // NOTICE
        var n = Panel(frame, "Notice", 30, 538, 375, 108, PanelFill, PanelLine);
        Detail(n, 30, 538, 375, 108);
        Icon(n, "Speaker", "ic_spk", 44, 548, 36, 28);
        T(n, "Title", "NOTICE", 88, 561, 255, 19, true);
        T(n, "Message", "Maintenance will be on\nNov 10, 08:00 (UTC+7).", 88, 608, 280, 17);
        T(n, "Arrow", ">", 366, 594, 30, 28, false, TextAnchor.MiddleCenter);
        Click(n);
    }

    void Right()
    {
        // DAILY MISSION
        var d = Panel(frame, "DailyMission", 1316, 180, 326, 120, PanelFill, PanelLine);
        Detail(d, 1316, 180, 326, 120);
        Icon(d, "Calendar", "ic_cal", 1331, 193, 34, 30);
        T(d, "Title", "DAILY MISSION", 1373, 205, 190, 19, true);
        T(d, "Count", "0 / 3", 1565, 205, 60, 18);
        T(d, "ChevronsTop", "\u00BB", 1608, 205, 24, 18, false, TextAnchor.MiddleCenter, false, Dim);
        S(d, "Divider", 1330, 224, 298, 1, new Color(.15f, .3f, .5f, .8f));
        T(d, "Task", "Play 3 matches", 1333, 246, 265, 19);
        Icon(d, "RewardGem", "ic_gem2", 1516, 257, 28, 32);
        T(d, "Reward", "x100", 1551, 272, 60, 19, true);
        T(d, "Arrow", ">", 1603, 272, 30, 26, false, TextAnchor.MiddleCenter);
        Click(d);

        // SEASON RANK
        var r = Panel(frame, "SeasonRank", 1316, 322, 326, 110, PanelFill, PanelLine);
        Detail(r, 1316, 322, 326, 110);
        Icon(r, "SeasonShield", "ic_shield_season", 1326, 328, 72, 78);
        T(r, "Heading", "SEASON RANK", 1407, 345, 216, 16, true);
        T(r, "Rank", "Bronze I", 1424, 377, 170, 20, true);
        S(r, "Track", 1424, 391, 154, 5, new Color(.12f, .19f, .3f));
        S(r, "Fill", 1424, 391, 12, 5, new Color(.8f, .71f, .51f));
        T(r, "Progress", "0 / 1000", 1424, 410, 162, 16);
        T(r, "Arrow", ">", 1600, 377, 30, 26, false, TextAnchor.MiddleCenter);
        Click(r);

        // NEW MAP
        var m = Panel(frame, "MapPromo", 1316, 453, 326, 208, new Color(.02f, .1f, .3f, .95f), BrightLine, 0, true);
        var ms = Load("map", mapArtwork);
        if (ms != null)
        {
            var mi = Img(m, "OwnMap", 1318, 455, 322, 150, ms, Color.white);
            mi.preserveAspect = false;
            mi.transform.SetAsFirstSibling();
        }
        Img(m, "CaptionBack", 1318, 596, 322, 63, FillSprite(), new Color(.005f, .02f, .06f, .92f), true);
        T(m, "Tag", "NEW MAP", 1333, 613, 270, 18, true, TextAnchor.MiddleLeft, false, new Color(1f, .8f, .25f));
        T(m, "Name", "RESEARCH FACILITY  \u00BB", 1333, 638, 300, 20, true);
        Detail(m, 1316, 453, 326, 208);
        Click(m);
    }

    void Bottom()
    {
        var bar = Panel(frame, "NavigationBacking", 18, 778, 1213, 134, new Color(.01f, .03f, .07f, .62f), new Color(.15f, .3f, .55f, .4f));
        foreach (var g in bar.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        Nav("Operations", "Play Missions", 32, 788, 214, 112, "ic_n_target", true);
        Nav("Agents", "Select Character", 255, 790, 173, 108, "ic_n_agent");
        Nav("Armory", "Upgrade Weapons", 445, 790, 173, 108, "ic_n_gun");
        Nav("Inventory", "Manage Items", 636, 790, 182, 108, "ic_n_bag");
        Nav("Store", "Buy Items", 836, 790, 178, 108, "ic_n_cart");
        Nav("Settings", "Game Settings", 1032, 790, 178, 108, "ic_n_gear");

        // DEPLOY
        var d = Panel(frame, "Deploy", 1262, 760, 386, 142, BrightFill, BrightLine, .7f);
        Img(d, "InnerFrame", 1269, 767, 372, 128, LineSprite(), new Color(.35f, .75f, 1f, .5f), true);
        S(d, "TopSpecular", 1300, 765, 280, 2, new Color(.5f, .85f, 1f));
        T(d, "Title", "DEPLOY", 1298, 817, 292, 52, true, TextAnchor.MiddleCenter, true);
        T(d, "Chevrons", "\u00BB", 1566, 817, 70, 60, true, TextAnchor.MiddleCenter, true, new Color(.55f, .85f, 1f));
        T(d, "Subtitle", "ENTER THE BATTLEFIELD", 1298, 863, 300, 19, true, TextAnchor.MiddleCenter, true, new Color(.7f, .9f, 1f));
        Detail(d, 1262, 760, 386, 142);
        Click(d);

        S(frame, "FooterTrace", 30, 908, 1606, 1, new Color(.15f, .43f, .78f, .8f));
    }

    void Nav(string id, string subtitle, float x, float y, float w, float h, string icon, bool active = false)
    {
        var p = Panel(frame, id, x, y, w, h, active ? BrightFill : PanelFill, active ? BrightLine : PanelLine, active ? .6f : 0);
        Img(p, "InsetFrame", x + 5, y + 5, w - 10, h - 10, LineSprite(), new Color(.15f, .4f, .75f, active ? .6f : .18f), true);
        Detail(p, x, y, w, h);
        float iw = icon == "ic_n_gun" ? 80 : 44;
        Icon(p, "Icon", icon, x + (w - iw) / 2f, y + 12, iw, 44);
        T(p, "Title", id.ToUpperInvariant(), x + 4, y + 65, w - 8, 19, true, TextAnchor.MiddleCenter);
        T(p, "Subtitle", subtitle, x + 4, y + 88, w - 8, 14, false, TextAnchor.MiddleCenter, false, Dim);
        if (active)
        {
            Img(p, "AlertBadge", x + w - 24, y - 10, 24, 24, DiscSprite(), new Color(.86f, .08f, .12f));
            T(p, "Alert", "!", x + w - 24, y + 2, 24, 16, true, TextAnchor.MiddleCenter);
        }
        Click(p);
    }
}
