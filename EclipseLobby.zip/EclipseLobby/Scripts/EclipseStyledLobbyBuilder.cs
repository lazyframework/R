using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

// Lobby "Project Eclipse" v2.
// - Tidak memakai mesh kustom (MaskableGraphic). Semua pakai Image biasa, jadi tampil di renderer apa pun.
// - Frame panel dibuat dari sprite 9-slice yang dihasilkan lewat kode.
// - Semua gambar (latar, ikon, potret, banner, peta) diisi sendiri lewat Inspector; kosong = placeholder polos.
// - Dibangun ulang setiap Play, jadi tidak ada hierarki lama yang basi.
public class EclipseStyledLobbyBuilder : MonoBehaviour
{
    [Header("Opsional: isi gambar sendiri (kosong = placeholder polos)")]
    public Font font;
    public Sprite background, portrait, agentBanner, mapArtwork;
    public RenderTexture characterPreview;

    [Header("Opsional: ikon (kosong = tidak ditampilkan)")]
    public Sprite gem, coin, bell, friends, gearTop, calendar, speaker, smallGem;
    public Sprite rankShield, seasonShield;
    public Sprite navOperations, navAgents, navArmory, navInventory, navStore, navSettings;

    [Header("Deploy")]
    public bool loadSceneOnDeploy = true;
    public string gameSceneName = "GameScene";

    [Header("Profile")]
    public string playerName = "FamaLine";
    public int level = 12, diamonds = 1200, coins = 15340;

    [Serializable] public class RouteEvent : UnityEvent<string> { }
    public RouteEvent onNavigate = new RouteEvent();
    public UnityEvent onDeploy = new UnityEvent();
    public Color cyan = new Color(.15f, .65f, 1, 1);

    const string Root = "EclipseLobbyCanvas_v2";
    const string Legacy = "StyledLobbyCanvas";

    RectTransform frame;
    // ---- anchor responsif: elemen level-atas menempel ke sisi kiri/kanan/atas/bawah layar ----
    enum HA { Left, Center, Right }
    enum VA { Top, Center, Bottom }
    HA ha = HA.Left;
    VA va = VA.Top;

    public enum BackdropMode { Stretch, Cover }
    [Header("Latar layar penuh")]
    [Tooltip("Stretch = memenuhi layar di semua rasio tanpa kosong dan tanpa terpotong (gambar agak melebar/menyempit). Cover = rasio terjaga, tapi sisi gambar bisa terpotong.")]
    public BackdropMode backdropMode = BackdropMode.Stretch;

    void BackdropStretch()
    {
        var parent = frame.parent;
        var cont = new GameObject("BackdropRoot", typeof(RectTransform), typeof(RectMask2D));
        cont.transform.SetParent(parent, false);
        cont.transform.SetAsFirstSibling();
        var cr = cont.GetComponent<RectTransform>();
        cr.anchorMin = Vector2.zero; cr.anchorMax = Vector2.one; cr.offsetMin = cr.offsetMax = Vector2.zero;

        var solid = new GameObject("BackdropSolid", typeof(RectTransform), typeof(Image));
        solid.transform.SetParent(cont.transform, false);
        var sr = solid.GetComponent<RectTransform>();
        sr.anchorMin = Vector2.zero; sr.anchorMax = Vector2.one; sr.offsetMin = sr.offsetMax = Vector2.zero;
        var si = solid.GetComponent<Image>();
        si.color = new Color(.015f, .048f, .105f);
        si.raycastTarget = false;

        var bg = new GameObject("Backdrop", typeof(RectTransform), typeof(Image), typeof(EclipseIconSlot));
        bg.transform.SetParent(cont.transform, false);
        var img = bg.GetComponent<Image>();
        img.sprite = background;
        img.color = Color.white;
        img.raycastTarget = false;
        img.preserveAspect = false;
        var br = bg.GetComponent<RectTransform>();
        if (backdropMode == BackdropMode.Cover)
        {
            var fit = bg.AddComponent<AspectRatioFitter>();
            fit.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            fit.aspectRatio = 1672f / 941f;
        }
        else
        {
            br.anchorMin = Vector2.zero; br.anchorMax = Vector2.one; br.offsetMin = br.offsetMax = Vector2.zero;
        }
    }

    // garis selebar layar (margin kiri-kanan), menempel ke atas atau bawah
    void HLine(string n, float y, float h, float margin, Color c, bool bottom)
    {
        var go = new GameObject(n, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(frame, false);
        var r = go.GetComponent<RectTransform>();
        float ay = bottom ? 0 : 1;
        r.anchorMin = new Vector2(0, ay);
        r.anchorMax = new Vector2(1, ay);
        r.pivot = new Vector2(.5f, ay);
        if (bottom) { r.offsetMin = new Vector2(margin, 941 - (y + h)); r.offsetMax = new Vector2(-margin, 941 - y); }
        else { r.offsetMin = new Vector2(margin, -(y + h)); r.offsetMax = new Vector2(-margin, -y); }
        var im = go.GetComponent<Image>();
        im.color = c;
        im.raycastTarget = false;
    }

    readonly Dictionary<Transform, Vector2> origin = new Dictionary<Transform, Vector2>();

    static Sprite sFill, sLine, sGlow, sRing, sDisc;

    // Warna
    static readonly Color Txt = new Color(.92f, .96f, 1f);
    static readonly Color Dim = new Color(.62f, .74f, .9f);
    static readonly Color PanelFill = new Color(.02f, .06f, .14f, .86f);
    static readonly Color PanelLine = new Color(.24f, .48f, .82f, .95f);
    static readonly Color BrightFill = new Color(.03f, .30f, .88f, .96f);
    static readonly Color BrightLine = new Color(.40f, .78f, 1f, 1f);

    void Start()
    {
        var root = transform.Find(Root);
        if (root == null) { Build(); return; }
        // Hierarki sudah dibuat di editor: cukup pasang ulang listener tombol (listener runtime tidak tersimpan di scene)
        foreach (var b in root.GetComponentsInChildren<Button>(true))
        {
            string id = b.gameObject.name;
            b.onClick.RemoveAllListeners();
            b.onClick.AddListener(() => Route(id));
        }
    }

#if UNITY_EDITOR
    // Langsung dibangun di editor begitu komponen ditambahkan
    void Reset()
    {
        UnityEditor.EditorApplication.delayCall += () => { if (this != null && transform.Find(Root) == null) Build(); };
    }
#endif

    public void Route(string id)
    {
        onNavigate.Invoke(id);
        if (id == "Deploy")
        {
            onDeploy.Invoke();
            if (loadSceneOnDeploy && !string.IsNullOrEmpty(gameSceneName))
            {
                if (Application.CanStreamedLevelBeLoaded(gameSceneName)) SceneManager.LoadScene(gameSceneName);
                else Debug.LogError("Scene '" + gameSceneName + "' belum ada di File > Build Profiles > Scene List.", this);
            }
        }
        Debug.Log("Lobby: " + id, this);
    }

    // ---------------------------------------------------------------- helpers

    RectTransform R(Transform p, string n, float x, float y, float w, float h)
    {
        var go = new GameObject(n, typeof(RectTransform));
        var r = go.GetComponent<RectTransform>();
        r.SetParent(p, false);
        Vector2 o;
        origin.TryGetValue(p, out o);
        r.pivot = new Vector2(0, 1);
        if (p == frame)
        {
            float ax = ha == HA.Left ? 0 : (ha == HA.Right ? 1672 : 836);
            float ay = va == VA.Top ? 0 : (va == VA.Bottom ? 941 : 470.5f);
            r.anchorMin = r.anchorMax = new Vector2(ha == HA.Left ? 0 : (ha == HA.Right ? 1 : .5f),
                                                    va == VA.Top ? 1 : (va == VA.Bottom ? 0 : .5f));
            r.anchoredPosition = new Vector2(x - ax, -(y - ay));
        }
        else
        {
            r.anchorMin = r.anchorMax = new Vector2(0, 1);
            r.anchoredPosition = new Vector2(x - o.x, -(y - o.y));
        }
        r.sizeDelta = new Vector2(w, h);
        origin[r] = new Vector2(x, y);
        return r;
    }

    Image Img(Transform p, string n, float x, float y, float w, float h, Sprite s, Color c, bool sliced = false, bool ray = false)
    {
        var i = R(p, n, x, y, w, h).gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = c;
        i.raycastTarget = ray;
        if (s != null)
        {
            if (sliced) i.type = Image.Type.Sliced;
            else i.preserveAspect = true;
        }
        return i;
    }

    Text T(Transform p, string n, string s, float x, float cy, float w, int size, bool bold = false,
           TextAnchor a = TextAnchor.MiddleLeft, bool italic = false, Color? col = null)
    {
        float h = size * 1.6f;
        var t = R(p, n, x, cy - h / 2f, w, h).gameObject.AddComponent<Text>();
        t.font = font;
        t.text = s;
        t.fontSize = size;
        t.fontStyle = bold ? (italic ? FontStyle.BoldAndItalic : FontStyle.Bold) : (italic ? FontStyle.Italic : FontStyle.Normal);
        t.color = col ?? Txt;
        t.alignment = a;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    Image S(Transform p, string n, float x, float y, float w, float h, Color c)
    {
        return Img(p, n, x, y, w, h, null, c);
    }

    // Slot ikon selalu dibuat (walau sprite kosong) supaya bisa diisi lewat Source Image di Hierarchy.
    Image Icon(Transform p, string n, Sprite sprite, float x, float y, float w, float h)
    {
        var i = Img(p, n, x, y, w, h, sprite, Color.white);
        i.preserveAspect = true;
        i.gameObject.AddComponent<EclipseIconSlot>();
        return i;
    }

    // Slot gambar besar (potret, banner, peta): ditaruh paling belakang di dalam panelnya.
    Image Art(Transform p, string n, float x, float y, float w, float h, Sprite sprite)
    {
        var i = Img(p, n, x, y, w, h, sprite, Color.white);
        i.preserveAspect = false;
        i.gameObject.AddComponent<EclipseIconSlot>();
        i.transform.SetAsFirstSibling();
        return i;
    }

    // Panel = akar + Glow(opsional) + Fill + Outline
    RectTransform Panel(Transform p, string n, float x, float y, float w, float h, Color fill, Color line, float glow = 0, bool art = false)
    {
        var r = R(p, n, x, y, w, h);
        if (glow > 0)
        {
            var g = Img(r, "Glow", x - 20, y - 20, w + 40, h + 40, GlowSprite(), new Color(.1f, .5f, 1f, glow), true);
        }
        if (!art) Img(r, "Fill", x, y, w, h, FillSprite(), fill, true);
        Img(r, "Outline", x, y, w, h, LineSprite(), line, true);
        return r;
    }

    void Detail(Transform p, float x, float y, float w, float h)
    {
        S(p, "TopAccent", x + 22, y + 1, Mathf.Min(64, w * .24f), 2, cyan);
        S(p, "LowerTrace", x + 14, y + h - 7, w - 52, 1, new Color(.10f, .35f, .61f, .55f));
        for (int i = 0; i < 3; i++)
        {
            var t = S(p, "Slash" + i, x + w - 30 + i * 7, y + h - 13, 3, 9, new Color(.17f, .55f, .89f, .75f));
            t.rectTransform.localEulerAngles = new Vector3(0, 0, -30);
        }
    }

    void Click(RectTransform root)
    {
        var fill = root.Find("Fill");
        Graphic target = null;
        var outline = root.Find("Outline");
        if (outline != null) target = outline.GetComponent<Graphic>();
        if (target == null)
        {
            var ic = root.Find("Icon");
            if (ic != null) target = ic.GetComponent<Graphic>();
        }
        if (fill != null) fill.GetComponent<Graphic>().raycastTarget = true;
        else
        {
            // panel tanpa fill / ikon: pakai gambar transparan sebagai area klik
            var hit = Img(root, "Hit", origin[root].x, origin[root].y, root.sizeDelta.x, root.sizeDelta.y, null, new Color(0, 0, 0, 0), false, true);
            if (target == null) target = hit;
        }
        if (target == null) target = root.GetComponentInChildren<Graphic>();
        var b = root.gameObject.AddComponent<Button>();
        b.targetGraphic = target;
        var c = b.colors;
        c.normalColor = new Color(.88f, .92f, 1f, 1f);
        c.highlightedColor = Color.white;
        c.pressedColor = new Color(.6f, .78f, 1f, 1f);
        c.selectedColor = Color.white;
        c.fadeDuration = .1f;
        b.colors = c;
        string id = root.name;
        b.onClick.AddListener(() => Route(id));
    }

    // ---------------------------------------------------------------- sprite generator

    static float Sd(float x, float y, float x0, float y0, float x1, float y1, float c)
    {
        float d = Mathf.Min(Mathf.Min(x - x0, x1 - x), Mathf.Min(y - y0, y1 - y));
        float tl = ((x - x0) + (y1 - y) - c) * 0.70710678f; // pojok kiri-atas terpotong
        float br = ((x1 - x) + (y - y0) - c) * 0.70710678f; // pojok kanan-bawah terpotong
        return Mathf.Min(d, Mathf.Min(tl, br));
    }

    static Sprite Make(string name, int w, int h, int border, Func<float, float, Color> px)
    {
#if UNITY_EDITOR
        // Di editor sprite disimpan sebagai PNG nyata di Assets/EclipseLobby/Generated,
        // supaya hierarki yang dibangun bisa tersimpan di scene.
        const string dir = "Assets/EclipseLobby/Generated";
        string path = dir + "/" + name + ".png";
        var existing = UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (existing != null) return existing;
#endif
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.name = name;
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        var cols = new Color32[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                cols[y * w + x] = px(x + .5f, y + .5f);
        t.SetPixels32(cols);
        t.Apply();
#if UNITY_EDITOR
        System.IO.Directory.CreateDirectory(dir);
        System.IO.File.WriteAllBytes(path, t.EncodeToPNG());
        UnityEngine.Object.DestroyImmediate(t);
        UnityEditor.AssetDatabase.ImportAsset(path, UnityEditor.ImportAssetOptions.ForceSynchronousImport);
        var ti = (UnityEditor.TextureImporter)UnityEditor.AssetImporter.GetAtPath(path);
        ti.textureType = UnityEditor.TextureImporterType.Sprite;
        ti.spriteImportMode = UnityEditor.SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 100;
        ti.spriteBorder = new Vector4(border, border, border, border);
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.filterMode = FilterMode.Bilinear;
        ti.textureCompression = UnityEditor.TextureImporterCompression.Uncompressed;
        ti.SaveAndReimport();
        return UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
#else
        var s = Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect,
                              new Vector4(border, border, border, border));
        s.name = name;
        return s;
#endif
    }

    static Sprite FillSprite()
    {
        if (sFill == null)
            sFill = Make("EclipseFill", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f);
                float g = Mathf.Lerp(.72f, 1f, y / 64f);
                return new Color(g, g, g, a);
            });
        return sFill;
    }

    static Sprite LineSprite()
    {
        if (sLine == null)
            sLine = Make("EclipseLine", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f) * Mathf.Clamp01(2.1f - d);
                return new Color(1, 1, 1, a);
            });
        return sLine;
    }

    static Sprite GlowSprite()
    {
        if (sGlow == null)
            sGlow = Make("EclipseGlow", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 20, 20, 44, 44, 12);
                float a = d >= 0 ? 1f : Mathf.Pow(Mathf.Clamp01(1f + d / 20f), 2.2f);
                return new Color(1, 1, 1, a);
            });
        return sGlow;
    }

    static Sprite RingSprite()
    {
        if (sRing == null)
            sRing = Make("EclipseRing", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(1.6f - Mathf.Abs(r - 13.5f) + .5f));
            });
        return sRing;
    }

    static Sprite DiscSprite()
    {
        if (sDisc == null)
            sDisc = Make("EclipseDisc", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(15f - r));
            });
        return sDisc;
    }

    // ---------------------------------------------------------------- build

    [ContextMenu("Build Styled Lobby")]
    public void Build()
    {
        foreach (var name in new[] { Root, Legacy })
        {
            Transform old;
            while ((old = transform.Find(name)) != null)
            {
                old.gameObject.SetActive(false);
                old.SetParent(null);
                if (Application.isPlaying) Destroy(old.gameObject);
                else DestroyImmediate(old.gameObject);
            }
        }

        origin.Clear();

        if (font == null)
        {
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        var go = new GameObject(Root, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.transform.SetParent(transform, false);
        var canvas = go.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scale = go.GetComponent<CanvasScaler>();
        scale.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scale.referenceResolution = new Vector2(1672, 941);
        scale.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;

        // frame memenuhi seluruh layar; isi menempel ke sisi layar lewat anchor (lihat R())
        frame = new GameObject("ReferenceFrame", typeof(RectTransform)).GetComponent<RectTransform>();
        frame.SetParent(go.transform, false);
        frame.anchorMin = Vector2.zero;
        frame.anchorMax = Vector2.one;
        frame.offsetMin = frame.offsetMax = Vector2.zero;
        frame.gameObject.AddComponent<EclipseSafeArea>(); // UI tidak tertutup notch / sudut layar
        origin[frame] = Vector2.zero;

        Background();
        Header();
        Profile();
        Left();
        Right();
        Bottom();

#if UNITY_2023_1_OR_NEWER
        bool noES = UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null;
#else
        bool noES = UnityEngine.Object.FindObjectOfType<EventSystem>() == null;
#endif
        if (noES)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }
    }

    void Background()
    {
        BackdropStretch();
        ha = HA.Center; va = VA.Center;
        if (characterPreview != null)
        {
            var raw = R(frame, "CharacterStage_OwnRenderTexture", 530, 112, 700, 675).gameObject.AddComponent<RawImage>();
            raw.texture = characterPreview;
            raw.raycastTarget = false;
        }
    }

    void Header()
    {
        ha = HA.Right; va = VA.Top;
        Wallet("Diamonds", 990, 205, gem, diamonds.ToString("N0"), 40);
        Wallet("Coins", 1210, 198, coin, coins.ToString("N0"), 42);

        Top("Notifications", bell, 1425, 20, 62, 56);
        Top("Friends", friends, 1503, 24, 64, 52);
        Top("SettingsTop", gearTop, 1580, 22, 62, 54);

        HLine("HeaderRule", 106, 1, 30, new Color(.15f, .36f, .65f, .35f), false);
    }

    void Wallet(string id, float x, float w, Sprite icon, string value, float iw)
    {
        var p = Panel(frame, id, x, 26, w, 48, new Color(.01f, .04f, .10f, .85f), new Color(.2f, .42f, .74f, .9f));
        Icon(p, "Icon", icon, x + 8, 28, iw, 44);
        T(p, "Balance", value, x + 58, 50, w - 105, 24, true);
        S(p, "PlusDivider", x + w - 42, 31, 1, 38, new Color(.2f, .4f, .7f, .5f));
        T(p, "Plus", "+", x + w - 42, 50, 42, 32, false, TextAnchor.MiddleCenter);
        Click(p);
    }

    void Top(string id, Sprite sprite, float x, float y, float w, float h)
    {
        var r = R(frame, id, x, y, w, h);
        Icon(r, "Icon", sprite, x, y, w, h);
        Click(r);
    }

    void Profile()
    {
        ha = HA.Left; va = VA.Top;
        // satu card latar di belakang seluruh profil (potret tidak punya latar sendiri, jadi tidak dobel)
        var card = Panel(frame, "ProfileCard", 28, 118, 450, 176, PanelFill, PanelLine);
        Detail(card, 28, 118, 450, 176);
        foreach (var g in card.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        var r = R(frame, "ProfileGroup", 32, 125, 430, 158);

        var p = Panel(r, "Portrait", 36, 126, 128, 118, Color.clear, BrightLine, 0, true);
        Art(p, "OwnPortrait", 38, 128, 124, 114, portrait);
        Click(p);

        T(r, "PlayerName", playerName, 185, 160, 255, 24, true);
        T(r, "Level", "Lv. " + level, 185, 203, 88, 26, true, TextAnchor.MiddleLeft, true);
        S(r, "XPTrack", 259, 191, 190, 6, new Color(.06f, .14f, .30f, 1));
        S(r, "XPFill", 259, 191, 68, 6, cyan);
        S(r, "XPLine", 259, 211, 68, 2, new Color(.3f, .7f, 1f, .9f));
        T(r, "Experience", "EXP 720 / 2,000", 345, 216, 130, 14);

        Icon(r, "RankIcon", rankShield, 182, 230, 52, 54);
        T(r, "Rank", "Silver III", 242, 258, 125, 20, true);
        Img(r, "InfoRing", 325, 247, 22, 22, RingSprite(), Dim);
        T(r, "Info", "i", 325, 258, 22, 14, false, TextAnchor.MiddleCenter, true, Dim);
    }

    void Left()
    {
        ha = HA.Left; va = VA.Top;
        // NEW AGENT
        var p = Panel(frame, "AgentPromo", 30, 372, 375, 148, new Color(.02f, .1f, .3f, .95f), BrightLine, 0, true);
        Art(p, "OwnBanner", 32, 372, 372, 148, agentBanner);
        T(p, "Heading", "NEW AGENT", 211, 419, 190, 26, true, TextAnchor.MiddleLeft, true);
        T(p, "AgentName", "\u201CVYRA\u201D", 211, 452, 190, 32, true, TextAnchor.MiddleLeft, true);
        var get = Panel(p, "GetNow", 253, 481, 142, 28, new Color(.18f, .52f, .95f, .96f), new Color(.55f, .83f, 1f, 1f));
        T(get, "Label", "GET NOW  \u00BB", 253, 495, 142, 17, true, TextAnchor.MiddleCenter, true);
        Click(p);

        // NOTICE
        var n = Panel(frame, "Notice", 30, 538, 375, 108, PanelFill, PanelLine);
        Detail(n, 30, 538, 375, 108);
        Icon(n, "Speaker", speaker, 44, 548, 36, 28);
        T(n, "Title", "NOTICE", 88, 561, 255, 19, true);
        T(n, "Message", "Maintenance will be on\nNov 10, 08:00 (UTC+7).", 88, 608, 280, 17);
        T(n, "Arrow", ">", 366, 594, 30, 28, false, TextAnchor.MiddleCenter);
        Click(n);
    }

    void Right()
    {
        ha = HA.Right; va = VA.Top;
        const float X = 1250, W = 392, L = -66; // panel kanan dilebarkan ke kiri
        // DAILY MISSION
        var d = Panel(frame, "DailyMission", X, 180, W, 120, PanelFill, PanelLine);
        Detail(d, X, 180, W, 120);
        Icon(d, "Calendar", calendar, 1331 + L, 193, 34, 30);
        T(d, "Title", "DAILY MISSION", 1373 + L, 205, 190, 19, true);
        T(d, "Count", "0 / 3", 1565, 205, 60, 18);
        T(d, "ChevronsTop", "\u00BB", 1608, 205, 24, 18, false, TextAnchor.MiddleCenter, false, Dim);
        S(d, "Divider", 1330 + L, 224, 298 - L, 1, new Color(.15f, .3f, .5f, .8f));
        T(d, "Task", "Play 3 matches", 1333 + L, 246, 265, 19);
        Icon(d, "RewardGem", smallGem, 1516, 257, 28, 32);
        T(d, "Reward", "x100", 1551, 272, 60, 19, true);
        T(d, "Arrow", ">", 1603, 272, 30, 26, false, TextAnchor.MiddleCenter);
        Click(d);

        // SEASON RANK
        var r = Panel(frame, "SeasonRank", X, 322, W, 110, PanelFill, PanelLine);
        Detail(r, X, 322, W, 110);
        Icon(r, "SeasonShield", seasonShield, 1326 + L, 328, 72, 78);
        T(r, "Heading", "SEASON RANK", 1407 + L, 345, 216, 16, true);
        T(r, "Rank", "Bronze I", 1424 + L, 377, 170, 20, true);
        S(r, "Track", 1424 + L, 391, 154 - L, 5, new Color(.12f, .19f, .3f));
        S(r, "Fill", 1424 + L, 391, 12, 5, new Color(.8f, .71f, .51f));
        T(r, "Progress", "0 / 1000", 1424 + L, 410, 162, 16);
        T(r, "Arrow", ">", 1600, 377, 30, 26, false, TextAnchor.MiddleCenter);
        Click(r);

        // NEW MAP
        var m = Panel(frame, "MapPromo", X, 453, W, 208, new Color(.02f, .1f, .3f, .95f), BrightLine, 0, true);
        Art(m, "OwnMap", X + 2, 455, W - 4, 150, mapArtwork);
        Img(m, "CaptionBack", X + 2, 596, W - 4, 63, FillSprite(), new Color(.005f, .02f, .06f, .92f), true);
        T(m, "Tag", "NEW MAP", 1333 + L, 613, 270, 18, true, TextAnchor.MiddleLeft, false, new Color(1f, .8f, .25f));
        T(m, "Name", "RESEARCH FACILITY  \u00BB", 1333 + L, 638, 300, 20, true);
        Detail(m, X, 453, W, 208);
        Click(m);
    }

    void Bottom()
    {
        ha = HA.Left; va = VA.Bottom;
        var bar = Panel(frame, "NavigationBacking", 18, 786, 1213, 114, new Color(.01f, .03f, .07f, .62f), new Color(.15f, .3f, .55f, .4f));
        foreach (var g in bar.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

        Nav("Operations", "Play Missions", 32, 794, 214, 100, navOperations, true);
        Nav("Agents", "Select Character", 255, 800, 173, 88, navAgents);
        Nav("Armory", "Upgrade Weapons", 445, 800, 173, 88, navArmory);
        Nav("Inventory", "Manage Items", 636, 800, 182, 88, navInventory);
        Nav("Store", "Buy Items", 836, 800, 178, 88, navStore);
        Nav("Settings", "Game Settings", 1032, 800, 178, 88, navSettings);

        // DEPLOY
        ha = HA.Right;
        var d = Panel(frame, "Deploy", 1262, 760, 386, 142, BrightFill, BrightLine, .7f);
        Img(d, "InnerFrame", 1269, 767, 372, 128, LineSprite(), new Color(.35f, .75f, 1f, .5f), true);
        S(d, "TopSpecular", 1300, 765, 280, 2, new Color(.5f, .85f, 1f));
        T(d, "Title", "DEPLOY", 1298, 817, 292, 52, true, TextAnchor.MiddleCenter, true);
        T(d, "Chevrons", "\u00BB", 1566, 817, 70, 60, true, TextAnchor.MiddleCenter, true, new Color(.55f, .85f, 1f));
        T(d, "Subtitle", "ENTER THE BATTLEFIELD", 1298, 863, 300, 19, true, TextAnchor.MiddleCenter, true, new Color(.7f, .9f, 1f));
        Detail(d, 1262, 760, 386, 142);
        Click(d);

        HLine("FooterTrace", 908, 1, 30, new Color(.15f, .43f, .78f, .8f), true);
    }

    void Nav(string id, string subtitle, float x, float y, float w, float h, Sprite icon, bool active = false)
    {
        var p = Panel(frame, id, x, y, w, h, active ? BrightFill : PanelFill, active ? BrightLine : PanelLine, active ? .6f : 0);
        Img(p, "InsetFrame", x + 5, y + 5, w - 10, h - 10, LineSprite(), new Color(.15f, .4f, .75f, active ? .6f : .18f), true);
        Detail(p, x, y, w, h);
        float iw = icon != null && icon.rect.width > icon.rect.height * 1.5f ? 72 : 38;
        Icon(p, "Icon", icon, x + (w - iw) / 2f, y + 9, iw, 38);
        T(p, "Title", id.ToUpperInvariant(), x + 4, y + h * 0.60f, w - 8, 18, true, TextAnchor.MiddleCenter);
        T(p, "Subtitle", subtitle, x + 4, y + h * 0.80f, w - 8, 13, false, TextAnchor.MiddleCenter, false, Dim);
        if (active)
        {
            Img(p, "AlertBadge", x + w - 24, y - 10, 24, 24, DiscSprite(), new Color(.86f, .08f, .12f));
            T(p, "Alert", "!", x + w - 24, y + 2, 24, 16, true, TextAnchor.MiddleCenter);
        }
        Click(p);
    }
}
