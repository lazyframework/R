using UnityEngine;
using UnityEngine.UI;

// Slot gambar: Image ini otomatis tampil begitu kamu mengisi "Source Image",
// dan disembunyikan selama masih kosong.
[ExecuteAlways]
[RequireComponent(typeof(Image))]
public class EclipseIconSlot : MonoBehaviour
{
    void OnEnable() { Apply(); }
    void OnValidate() { Apply(); }
    void Update() { Apply(); }

    void Apply()
    {
        var i = GetComponent<Image>();
        if (i != null && i.enabled != (i.sprite != null)) i.enabled = i.sprite != null;
    }
}
