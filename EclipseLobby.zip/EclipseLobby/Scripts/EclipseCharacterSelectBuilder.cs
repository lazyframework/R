using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

[Serializable]
public class EclipseAgentData
{
    public string agentName = "Agent 013";
    public string role = "Assault";
    public int level = 12, exp = 720, expMax = 2000;
    [TextArea(2, 4)]
    public string description = "A skilled soldier with exceptional\ncombat skills. Trained to handle\nany situation on the battlefield.";
    public Sprite thumbnail, emblem, characterArt;
    public Sprite[] skillIcons = new Sprite[4];
    public string[] skillNames = { "Tactical\nDash", "Combat\nFocus", "Energy\nShield", "Ultimate\nStrike" };
    public int hp = 100, armor = 80, attack = 95, speed = 90;

    public EclipseAgentData() { }
    public EclipseAgentData(string n, string r, int lv)
    {
        agentName = n; role = r; level = lv;
    }
}

// Layar "Select Character" Project Eclipse.
// Dibangun langsung di editor (hierarki tersimpan di scene dan bisa kamu edit),
// memakai Image biasa + sprite frame yang dibuat otomatis. Semua gambar diisi sendiri.
public class EclipseCharacterSelectBuilder : MonoBehaviour
{
    [Header("Navigasi")]
    public string lobbySceneName = "EclipseLobby";
    public bool returnToLobbyOnConfirm = true;
    public string selectedAgentPrefsKey = "EclipseSelectedAgent";

    [Header("Opsional: gambar sendiri (kosong = placeholder)")]
    public Font font;
    public Sprite background;
    public RenderTexture characterPreview;
    public Sprite gem, coin, bell, home, hanger, skinIcon;
    public Sprite statHp, statArmor, statAttack, statSpeed;

    [Header("Dompet")]
    public int diamonds = 1200, coins = 15340;
    public int maxStat = 200;

    [Header("Daftar agen (maks 5 kartu di kiri)")]
    public List<EclipseAgentData> agents = new List<EclipseAgentData>();
    public int selectedIndex = 0;

    [Serializable] public class RouteEvent : UnityEvent<string> { }
    public RouteEvent onNavigate = new RouteEvent();
    [Serializable] public class IntEvent : UnityEvent<int> { }
    public IntEvent onConfirm = new IntEvent();

    public Color cyan = new Color(.15f, .65f, 1, 1);

    const string Root = "EclipseCharacterCanvas_v1";
    const int Cards = 5;

    RectTransform frame;
    // ---- anchor responsif: elemen level-atas menempel ke sisi kiri/kanan/atas/bawah layar ----
    enum HA { Left, Center, Right }
    enum VA { Top, Center, Bottom }
    HA ha = HA.Left;
    VA va = VA.Top;

    public enum BackdropMode { Stretch, Cover }
    [Header("Latar layar penuh")]
    [Tooltip("Stretch = memenuhi layar di semua rasio tanpa kosong dan tanpa terpotong (gambar agak melebar/menyempit). Cover = rasio terjaga, tapi sisi gambar bisa terpotong.")]
    public BackdropMode backdropMode = BackdropMode.Stretch;

    void BackdropStretch()
    {
        var parent = frame.parent;
        var cont = new GameObject("BackdropRoot", typeof(RectTransform), typeof(RectMask2D));
        cont.transform.SetParent(parent, false);
        cont.transform.SetAsFirstSibling();
        var cr = cont.GetComponent<RectTransform>();
        cr.anchorMin = Vector2.zero; cr.anchorMax = Vector2.one; cr.offsetMin = cr.offsetMax = Vector2.zero;

        var solid = new GameObject("BackdropSolid", typeof(RectTransform), typeof(Image));
        solid.transform.SetParent(cont.transform, false);
        var sr = solid.GetComponent<RectTransform>();
        sr.anchorMin = Vector2.zero; sr.anchorMax = Vector2.one; sr.offsetMin = sr.offsetMax = Vector2.zero;
        var si = solid.GetComponent<Image>();
        si.color = new Color(.015f, .048f, .105f);
        si.raycastTarget = false;

        var bg = new GameObject("Backdrop", typeof(RectTransform), typeof(Image), typeof(EclipseIconSlot));
        bg.transform.SetParent(cont.transform, false);
        var img = bg.GetComponent<Image>();
        img.sprite = background;
        img.color = Color.white;
        img.raycastTarget = false;
        img.preserveAspect = false;
        var br = bg.GetComponent<RectTransform>();
        if (backdropMode == BackdropMode.Cover)
        {
            var fit = bg.AddComponent<AspectRatioFitter>();
            fit.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            fit.aspectRatio = 1672f / 941f;
        }
        else
        {
            br.anchorMin = Vector2.zero; br.anchorMax = Vector2.one; br.offsetMin = br.offsetMax = Vector2.zero;
        }
    }

    // garis selebar layar (margin kiri-kanan), menempel ke atas atau bawah
    void HLine(string n, float y, float h, float margin, Color c, bool bottom)
    {
        var go = new GameObject(n, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(frame, false);
        var r = go.GetComponent<RectTransform>();
        float ay = bottom ? 0 : 1;
        r.anchorMin = new Vector2(0, ay);
        r.anchorMax = new Vector2(1, ay);
        r.pivot = new Vector2(.5f, ay);
        if (bottom) { r.offsetMin = new Vector2(margin, 941 - (y + h)); r.offsetMax = new Vector2(-margin, 941 - y); }
        else { r.offsetMin = new Vector2(margin, -(y + h)); r.offsetMax = new Vector2(-margin, -y); }
        var im = go.GetComponent<Image>();
        im.color = c;
        im.raycastTarget = false;
    }

    readonly Dictionary<Transform, Vector2> origin = new Dictionary<Transform, Vector2>();

    static Sprite sFill, sLine, sGlow, sRing, sDisc;

    static readonly Color Txt = new Color(.92f, .96f, 1f);
    static readonly Color Dim = new Color(.62f, .74f, .9f);
    static readonly Color PanelFill = new Color(.02f, .06f, .14f, .86f);
    static readonly Color PanelLine = new Color(.24f, .48f, .82f, .95f);
    static readonly Color BrightFill = new Color(.03f, .30f, .88f, .96f);
    static readonly Color BrightLine = new Color(.40f, .78f, 1f, 1f);
    static readonly Color Track = new Color(.07f, .14f, .28f, 1f);

    // ---------------------------------------------------------------- lifecycle

    void Start()
    {
        EnsureDefaults();
        var root = transform.Find(Root);
        if (root == null) { Build(); }
        else
        {
            foreach (var b in root.GetComponentsInChildren<Button>(true))
            {
                string id = b.gameObject.name;
                b.onClick.RemoveAllListeners();
                b.onClick.AddListener(() => Route(id));
            }
        }
        if (Application.isPlaying && !string.IsNullOrEmpty(selectedAgentPrefsKey))
            selectedIndex = PlayerPrefs.GetInt(selectedAgentPrefsKey, selectedIndex);
        Refresh();
    }

#if UNITY_EDITOR
    void Reset()
    {
        UnityEditor.EditorApplication.delayCall += () => { if (this != null && transform.Find(Root) == null) Build(); };
    }
#endif

    void EnsureDefaults()
    {
        if (agents == null) agents = new List<EclipseAgentData>();
        if (agents.Count > 0) return;
        agents.Add(new EclipseAgentData("Agent 013", "Assault", 12));
        agents.Add(new EclipseAgentData("Agent 021", "Recon", 9) { hp = 85, armor = 60, attack = 80, speed = 110 });
        agents.Add(new EclipseAgentData("Agent 034", "Support", 8) { hp = 95, armor = 75, attack = 60, speed = 90 });
        agents.Add(new EclipseAgentData("Agent 047", "Engineer", 7) { hp = 90, armor = 85, attack = 70, speed = 80 });
        agents.Add(new EclipseAgentData("Agent 052", "Stealth", 5) { hp = 80, armor = 55, attack = 100, speed = 120 });
    }

    // ---------------------------------------------------------------- routing

    public void Route(string id)
    {
        onNavigate.Invoke(id);
        if (id.StartsWith("Card"))
        {
            int i;
            if (int.TryParse(id.Substring(4), out i)) Select(i);
        }
        else if (id == "ArrowLeft") Select(selectedIndex - 1);
        else if (id == "ArrowRight") Select(selectedIndex + 1);
        else if (id == "Confirm")
        {
            if (!string.IsNullOrEmpty(selectedAgentPrefsKey)) PlayerPrefs.SetInt(selectedAgentPrefsKey, selectedIndex);
            onConfirm.Invoke(selectedIndex);
            if (returnToLobbyOnConfirm) LoadLobby();
        }
        else if (id == "Back" || id == "Home") LoadLobby();
        Debug.Log("CharacterSelect: " + id, this);
    }

    void LoadLobby()
    {
        if (string.IsNullOrEmpty(lobbySceneName)) return;
        if (Application.CanStreamedLevelBeLoaded(lobbySceneName)) SceneManager.LoadScene(lobbySceneName);
        else Debug.LogError("Scene '" + lobbySceneName + "' belum ada di File > Build Profiles > Scene List.", this);
    }

    public void Select(int i)
    {
        EnsureDefaults();
        int n = Mathf.Min(agents.Count, Cards);
        if (n == 0) return;
        selectedIndex = ((i % n) + n) % n;
        Refresh();
    }

    // ---------------------------------------------------------------- refresh (isi data ke UI)

    Transform FindDeep(string n)
    {
        var root = transform.Find(Root);
        if (root == null) return null;
        foreach (var t in root.GetComponentsInChildren<Transform>(true))
            if (t.name == n) return t;
        return null;
    }

    void SetText(string n, string v)
    {
        var t = FindDeep(n);
        if (t == null) return;
        var tx = t.GetComponent<Text>();
        if (tx != null) tx.text = v;
    }

    void SetSprite(string n, Sprite s)
    {
        var t = FindDeep(n);
        if (t == null) return;
        var im = t.GetComponent<Image>();
        if (im != null) { im.sprite = s; im.enabled = s != null; }
    }

    void SetWidth(string n, float w)
    {
        var t = FindDeep(n);
        if (t == null) return;
        var rt = t as RectTransform;
        if (rt != null) rt.sizeDelta = new Vector2(w, rt.sizeDelta.y);
    }

    public void Refresh()
    {
        if (transform.Find(Root) == null) return;
        EnsureDefaults();
        int count = Mathf.Min(agents.Count, Cards);
        selectedIndex = Mathf.Clamp(selectedIndex, 0, Mathf.Max(0, count - 1));
        var a = agents[selectedIndex];

        SetText("AgentName", a.agentName);
        SetText("AgentRole", a.role);
        SetSprite("Emblem", a.emblem);
        SetText("LevelText", "Lv. " + a.level);
        SetText("ExpText", "EXP " + a.exp.ToString("N0") + " / " + a.expMax.ToString("N0"));
        SetWidth("XPFill", 202f * Mathf.Clamp01(a.expMax > 0 ? (float)a.exp / a.expMax : 0));
        SetText("DescText", a.description);
        SetSprite("CharacterArt", a.characterArt);

        for (int i = 0; i < 4; i++)
        {
            SetSprite("Skill" + i + "Icon", a.skillIcons != null && i < a.skillIcons.Length ? a.skillIcons[i] : null);
            SetText("Skill" + i + "Name", a.skillNames != null && i < a.skillNames.Length ? a.skillNames[i] : "");
        }

        SetStat("HP", a.hp);
        SetStat("Armor", a.armor);
        SetStat("Attack", a.attack);
        SetStat("Speed", a.speed);

        for (int i = 0; i < Cards; i++)
        {
            var card = FindDeep("Card" + i);
            if (card == null) continue;
            card.gameObject.SetActive(i < count);
            if (i >= count) continue;
            SetSprite("Card" + i + "Art", agents[i].thumbnail);
            bool sel = i == selectedIndex;
            var o = card.Find("Outline");
            if (o != null) o.GetComponent<Image>().color = sel ? BrightLine : PanelLine;
            var g = card.Find("Glow");
            if (g != null) g.GetComponent<Image>().enabled = sel;
            var tag = FindDeep("Card" + i + "Tag");
            if (tag != null) tag.gameObject.SetActive(sel);
        }
    }

    void SetStat(string key, int value)
    {
        SetWidth("Stat" + key + "Fill", 188f * Mathf.Clamp01(maxStat > 0 ? (float)value / maxStat : 0));
        SetText("Stat" + key + "Value", value.ToString());
    }

    // ---------------------------------------------------------------- helpers

    RectTransform R(Transform p, string n, float x, float y, float w, float h)
    {
        var go = new GameObject(n, typeof(RectTransform));
        var r = go.GetComponent<RectTransform>();
        r.SetParent(p, false);
        Vector2 o;
        origin.TryGetValue(p, out o);
        r.pivot = new Vector2(0, 1);
        if (p == frame)
        {
            float ax = ha == HA.Left ? 0 : (ha == HA.Right ? 1672 : 836);
            float ay = va == VA.Top ? 0 : (va == VA.Bottom ? 941 : 470.5f);
            r.anchorMin = r.anchorMax = new Vector2(ha == HA.Left ? 0 : (ha == HA.Right ? 1 : .5f),
                                                    va == VA.Top ? 1 : (va == VA.Bottom ? 0 : .5f));
            r.anchoredPosition = new Vector2(x - ax, -(y - ay));
        }
        else
        {
            r.anchorMin = r.anchorMax = new Vector2(0, 1);
            r.anchoredPosition = new Vector2(x - o.x, -(y - o.y));
        }
        r.sizeDelta = new Vector2(w, h);
        origin[r] = new Vector2(x, y);
        return r;
    }

    Image Img(Transform p, string n, float x, float y, float w, float h, Sprite s, Color c, bool sliced = false, bool ray = false)
    {
        var i = R(p, n, x, y, w, h).gameObject.AddComponent<Image>();
        i.sprite = s;
        i.color = c;
        i.raycastTarget = ray;
        if (s != null)
        {
            if (sliced) i.type = Image.Type.Sliced;
            else i.preserveAspect = true;
        }
        return i;
    }

    Image S(Transform p, string n, float x, float y, float w, float h, Color c)
    {
        return Img(p, n, x, y, w, h, null, c);
    }

    Text T(Transform p, string n, string s, float x, float cy, float w, int size, bool bold = false,
           TextAnchor a = TextAnchor.MiddleLeft, bool italic = false, Color? col = null)
    {
        float h = size * 1.6f;
        var t = R(p, n, x, cy - h / 2f, w, h).gameObject.AddComponent<Text>();
        t.font = font;
        t.text = s;
        t.fontSize = size;
        t.fontStyle = bold ? (italic ? FontStyle.BoldAndItalic : FontStyle.Bold) : (italic ? FontStyle.Italic : FontStyle.Normal);
        t.color = col ?? Txt;
        t.alignment = a;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        return t;
    }

    Image Icon(Transform p, string n, Sprite sprite, float x, float y, float w, float h)
    {
        var i = Img(p, n, x, y, w, h, sprite, Color.white);
        i.preserveAspect = true;
        i.gameObject.AddComponent<EclipseIconSlot>();
        return i;
    }

    // gambar besar di dalam panel: di atas Fill, di bawah Outline
    Image ArtAbove(RectTransform panel, string n, float x, float y, float w, float h, Sprite s)
    {
        var i = Img(panel, n, x, y, w, h, s, Color.white);
        i.preserveAspect = false;
        i.gameObject.AddComponent<EclipseIconSlot>();
        var o = panel.Find("Outline");
        if (o != null) i.transform.SetSiblingIndex(o.GetSiblingIndex());
        return i;
    }

    RectTransform Panel(Transform p, string n, float x, float y, float w, float h, Color fill, Color line, float glow = 0)
    {
        var r = R(p, n, x, y, w, h);
        if (glow > 0) Img(r, "Glow", x - 20, y - 20, w + 40, h + 40, GlowSprite(), new Color(.1f, .5f, 1f, glow), true);
        Img(r, "Fill", x, y, w, h, FillSprite(), fill, true);
        Img(r, "Outline", x, y, w, h, LineSprite(), line, true);
        return r;
    }

    // Chevron "<" atau ">" dari dua batang yang diputar
    void Chevron(Transform p, string n, float cx, float cy, float w, float s, float th, Color c, bool left)
    {
        float L = Mathf.Sqrt(4 * w * w + s * s) + th * .5f;
        float ang = Mathf.Atan2(s, 2 * w) * Mathf.Rad2Deg;
        for (int k = 0; k < 2; k++)
        {
            bool upper = k == 0;
            float centerY = upper ? cy - s / 2f : cy + s / 2f;
            float phi = (upper == left) ? ang : -ang;
            var b = S(p, n + (upper ? "Up" : "Down"), cx - L / 2f, centerY - th / 2f, L, th, c);
            var rt = b.rectTransform;
            rt.pivot = new Vector2(.5f, .5f);
            rt.anchoredPosition += new Vector2(L / 2f, -th / 2f);
            rt.localEulerAngles = new Vector3(0, 0, phi);
        }
    }

    void Click(RectTransform root)
    {
        var fill = root.Find("Fill");
        Graphic target = null;
        var outline = root.Find("Outline");
        if (outline != null) target = outline.GetComponent<Graphic>();
        if (target == null)
        {
            var ic = root.Find("Icon");
            if (ic != null) target = ic.GetComponent<Graphic>();
        }
        if (fill != null) fill.GetComponent<Graphic>().raycastTarget = true;
        else
        {
            var hit = Img(root, "Hit", origin[root].x, origin[root].y, root.sizeDelta.x, root.sizeDelta.y, null, new Color(0, 0, 0, 0), false, true);
            if (target == null) target = hit;
        }
        if (target == null) target = root.GetComponentInChildren<Graphic>();
        var b = root.gameObject.AddComponent<Button>();
        b.targetGraphic = target;
        var c = b.colors;
        c.normalColor = new Color(.88f, .92f, 1f, 1f);
        c.highlightedColor = Color.white;
        c.pressedColor = new Color(.6f, .78f, 1f, 1f);
        c.selectedColor = Color.white;
        c.fadeDuration = .1f;
        b.colors = c;
        string id = root.name;
        b.onClick.AddListener(() => Route(id));
    }

    // ---------------------------------------------------------------- sprite generator (PNG nyata di editor)

    static float Sd(float x, float y, float x0, float y0, float x1, float y1, float c)
    {
        float d = Mathf.Min(Mathf.Min(x - x0, x1 - x), Mathf.Min(y - y0, y1 - y));
        float tl = ((x - x0) + (y1 - y) - c) * 0.70710678f;
        float br = ((x1 - x) + (y - y0) - c) * 0.70710678f;
        return Mathf.Min(d, Mathf.Min(tl, br));
    }

    static Sprite Make(string name, int w, int h, int border, Func<float, float, Color> px)
    {
#if UNITY_EDITOR
        const string dir = "Assets/EclipseLobby/Generated";
        string path = dir + "/" + name + ".png";
        var existing = UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (existing != null) return existing;
#endif
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.name = name;
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        var cols = new Color32[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                cols[y * w + x] = px(x + .5f, y + .5f);
        t.SetPixels32(cols);
        t.Apply();
#if UNITY_EDITOR
        System.IO.Directory.CreateDirectory(dir);
        System.IO.File.WriteAllBytes(path, t.EncodeToPNG());
        UnityEngine.Object.DestroyImmediate(t);
        UnityEditor.AssetDatabase.ImportAsset(path, UnityEditor.ImportAssetOptions.ForceSynchronousImport);
        var ti = (UnityEditor.TextureImporter)UnityEditor.AssetImporter.GetAtPath(path);
        ti.textureType = UnityEditor.TextureImporterType.Sprite;
        ti.spriteImportMode = UnityEditor.SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 100;
        ti.spriteBorder = new Vector4(border, border, border, border);
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.filterMode = FilterMode.Bilinear;
        ti.textureCompression = UnityEditor.TextureImporterCompression.Uncompressed;
        ti.SaveAndReimport();
        return UnityEditor.AssetDatabase.LoadAssetAtPath<Sprite>(path);
#else
        var s = Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(.5f, .5f), 100f, 0, SpriteMeshType.FullRect,
                              new Vector4(border, border, border, border));
        s.name = name;
        return s;
#endif
    }

    static Sprite FillSprite()
    {
        if (sFill == null)
            sFill = Make("EclipseFill", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f);
                float g = Mathf.Lerp(.72f, 1f, y / 64f);
                return new Color(g, g, g, a);
            });
        return sFill;
    }

    static Sprite LineSprite()
    {
        if (sLine == null)
            sLine = Make("EclipseLine", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 0, 0, 64, 64, 12);
                float a = Mathf.Clamp01(d + .5f) * Mathf.Clamp01(2.1f - d);
                return new Color(1, 1, 1, a);
            });
        return sLine;
    }

    static Sprite GlowSprite()
    {
        if (sGlow == null)
            sGlow = Make("EclipseGlow", 64, 64, 20, (x, y) =>
            {
                float d = Sd(x, y, 20, 20, 44, 44, 12);
                float a = d >= 0 ? 1f : Mathf.Pow(Mathf.Clamp01(1f + d / 20f), 2.2f);
                return new Color(1, 1, 1, a);
            });
        return sGlow;
    }

    static Sprite RingSprite()
    {
        if (sRing == null)
            sRing = Make("EclipseRing", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(1.6f - Mathf.Abs(r - 13.5f) + .5f));
            });
        return sRing;
    }

    static Sprite DiscSprite()
    {
        if (sDisc == null)
            sDisc = Make("EclipseDisc", 32, 32, 0, (x, y) =>
            {
                float r = Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f));
                return new Color(1, 1, 1, Mathf.Clamp01(15f - r));
            });
        return sDisc;
    }

    // ---------------------------------------------------------------- build

    [ContextMenu("Build Character Select")]
    public void Build()
    {
        EnsureDefaults();
        Transform old;
        while ((old = transform.Find(Root)) != null)
        {
            old.gameObject.SetActive(false);
            old.SetParent(null);
            if (Application.isPlaying) Destroy(old.gameObject);
            else DestroyImmediate(old.gameObject);
        }
        origin.Clear();

        if (font == null)
        {
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        var go = new GameObject(Root, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.transform.SetParent(transform, false);
        go.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scale = go.GetComponent<CanvasScaler>();
        scale.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scale.referenceResolution = new Vector2(1672, 941);
        scale.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;

        // frame memenuhi seluruh layar; isi menempel ke sisi layar lewat anchor (lihat R())
        frame = new GameObject("ReferenceFrame", typeof(RectTransform)).GetComponent<RectTransform>();
        frame.SetParent(go.transform, false);
        frame.anchorMin = Vector2.zero;
        frame.anchorMax = Vector2.one;
        frame.offsetMin = frame.offsetMax = Vector2.zero;
        frame.gameObject.AddComponent<EclipseSafeArea>(); // UI tidak tertutup notch / sudut layar
        origin[frame] = Vector2.zero;

        Background();
        Header();
        CardList();
        Arrows();
        InfoPanel();
        Bottom();

#if UNITY_2023_1_OR_NEWER
        bool noES = UnityEngine.Object.FindFirstObjectByType<EventSystem>() == null;
#else
        bool noES = UnityEngine.Object.FindObjectOfType<EventSystem>() == null;
#endif
        if (noES)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        Refresh();
    }

    void Background()
    {
        BackdropStretch();
        ha = HA.Center; va = VA.Center;

        var art = Img(frame, "CharacterArt", 500, 70, 560, 800, null, Color.white);
        art.preserveAspect = true;
        art.gameObject.AddComponent<EclipseIconSlot>();

        if (characterPreview != null)
        {
            var raw = R(frame, "CharacterStage_OwnRenderTexture", 500, 70, 560, 800).gameObject.AddComponent<RawImage>();
            raw.texture = characterPreview;
            raw.raycastTarget = false;
        }
    }

    void Header()
    {
        ha = HA.Left; va = VA.Top;
        // tombol kembali
        var back = Panel(frame, "Back", 28, 16, 74, 56, new Color(.02f, .08f, .2f, .9f), PanelLine);
        Chevron(back, "BackChevron", 65, 44, 9, 24, 4, Color.white, true);
        Click(back);

        T(frame, "Title", "SELECT CHARACTER", 136, 44, 420, 32, true, TextAnchor.MiddleLeft, true);
        for (int i = 0; i < 4; i++)
        {
            var sl = S(frame, "TitleSlash" + i, 480 + i * 17, 33, 6, 24, new Color(.25f, .6f, 1f, .6f + i * .1f));
            sl.rectTransform.localEulerAngles = new Vector3(0, 0, -25);
        }

        ha = HA.Right;
        Wallet("Diamonds", 1085, 168, gem, diamonds.ToString("N0"));
        Wallet("Coins", 1272, 172, coin, coins.ToString("N0"));

        var b = R(frame, "Notifications", 1486, 22, 44, 46);
        Icon(b, "Icon", bell, 1488, 24, 38, 42);
        Img(b, "AlertBadge", 1512, 16, 20, 20, DiscSprite(), new Color(.86f, .08f, .12f));
        T(b, "Alert", "!", 1512, 26, 20, 13, true, TextAnchor.MiddleCenter);
        Click(b);

        S(frame, "HeaderDivider", 1556, 26, 1, 36, new Color(.2f, .4f, .7f, .5f));

        var h = R(frame, "Home", 1580, 22, 54, 46);
        Icon(h, "Icon", home, 1584, 24, 46, 40);
        Click(h);

        HLine("HeaderRule", 77, 1, 0, new Color(.15f, .36f, .65f, .5f), false);
    }

    void Wallet(string id, float x, float w, Sprite icon, string value)
    {
        var p = Panel(frame, id, x, 22, w, 44, new Color(.01f, .04f, .10f, .85f), new Color(.2f, .42f, .74f, .9f));
        Icon(p, "Icon", icon, x + 8, 23, 36, 42);
        T(p, "Balance", value, x + 56, 44, w - 100, 23, true);
        S(p, "PlusDivider", x + w - 40, 27, 1, 34, new Color(.2f, .4f, .7f, .5f));
        T(p, "Plus", "+", x + w - 40, 44, 40, 32, false, TextAnchor.MiddleCenter);
        Click(p);
    }

    void CardList()
    {
        ha = HA.Left; va = VA.Top;
        for (int i = 0; i < Cards; i++)
        {
            float y = 113 + i * 136f;
            var c = Panel(frame, "Card" + i, 40, y, 232, 126, new Color(.02f, .08f, .22f, .92f), PanelLine, .7f);
            ArtAbove(c, "Card" + i + "Art", 42, y + 2, 228, 122, null);

            var tag = Panel(c, "Card" + i + "Tag", 160, y + 92, 112, 34, new Color(.02f, .12f, .4f, .95f), BrightLine);
            T(tag, "Card" + i + "TagText", "SELECTED", 160, y + 109, 112, 17, true, TextAnchor.MiddleCenter, true);
            foreach (var g in tag.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;

            Click(c);
        }
    }

    void Arrows()
    {
        ha = HA.Center; va = VA.Center;
        var l = Panel(frame, "ArrowLeft", 491, 430, 76, 84, new Color(.03f, .14f, .4f, .9f), BrightLine);
        Chevron(l, "LeftChevron", 530, 472, 13, 40, 8, new Color(.4f, .75f, 1f), true);
        Click(l);

        var r = Panel(frame, "ArrowRight", 1108, 430, 76, 84, new Color(.03f, .14f, .4f, .9f), BrightLine);
        Chevron(r, "RightChevron", 1146, 472, 13, 40, 8, new Color(.9f, .97f, 1f), false);
        Click(r);
    }

    void InfoPanel()
    {
        ha = HA.Right; va = VA.Top;
        var p = Panel(frame, "InfoPanel", 1237, 104, 407, 680, new Color(.015f, .05f, .12f, .92f), PanelLine);
        foreach (var g in p.GetComponentsInChildren<Graphic>()) g.raycastTarget = false;
        S(p, "NameAccent", 1236, 128, 3, 46, cyan);

        T(p, "AgentName", "Agent 013", 1266, 148, 280, 34, true);
        T(p, "AgentRole", "Assault", 1266, 187, 200, 22);
        Icon(p, "Emblem", null, 1553, 118, 74, 82);
        S(p, "Divider1", 1266, 224, 352, 1, new Color(.15f, .3f, .5f, .8f));

        T(p, "LevelText", "Lv. 12", 1266, 254, 150, 30, true);
        S(p, "XPTrack", 1266, 274, 202, 9, Track);
        S(p, "XPFill", 1266, 274, 158, 9, cyan);
        T(p, "ExpText", "EXP 720 / 2,000", 1476, 279, 150, 14);
        S(p, "Divider2", 1266, 304, 352, 1, new Color(.15f, .3f, .5f, .8f));

        T(p, "DescText", "", 1266, 347, 360, 18);
        S(p, "Divider3", 1266, 404, 352, 1, new Color(.15f, .3f, .5f, .8f));

        T(p, "SkillHeading", "SKILL", 1266, 430, 120, 22, true);
        S(p, "SkillAccent", 1340, 432, 120, 2, new Color(.2f, .5f, .9f, .35f));

        float[] cx = { 1299, 1394, 1490, 1585 };
        for (int i = 0; i < 4; i++)
        {
            Img(p, "Skill" + i + "Back", cx[i] - 34, 453, 68, 68, DiscSprite(), new Color(.02f, .08f, .22f, .95f));
            Icon(p, "Skill" + i + "Icon", null, cx[i] - 27, 460, 54, 54);
            Img(p, "Skill" + i + "Ring", cx[i] - 34, 453, 68, 68, RingSprite(), new Color(.3f, .65f, 1f));
            var tn = T(p, "Skill" + i + "Name", "", cx[i] - 50, 548, 100, 16, false, TextAnchor.MiddleCenter);
            tn.lineSpacing = 1.0f;
        }

        T(p, "StatsHeading", "STATS", 1266, 604, 120, 22, true);
        S(p, "StatsAccent", 1345, 606, 120, 2, new Color(.2f, .5f, .9f, .35f));

        string[] names = { "HP", "Armor", "Attack", "Speed" };
        Sprite[] icons = { statHp, statArmor, statAttack, statSpeed };
        for (int i = 0; i < 4; i++)
        {
            float cy = 641 + i * 34f;
            Icon(p, "Stat" + names[i] + "Icon", icons[i], 1266, cy - 13, 26, 26);
            T(p, "Stat" + names[i] + "Label", names[i], 1304, cy, 80, 18);
            S(p, "Stat" + names[i] + "Track", 1389, cy - 4, 188, 9, Track);
            S(p, "Stat" + names[i] + "Fill", 1389, cy - 4, 94, 9, cyan);
            T(p, "Stat" + names[i] + "Value", "0", 1540, cy, 77, 19, false, TextAnchor.MiddleRight);
        }
    }

    void Bottom()
    {
        ha = HA.Left; va = VA.Bottom;
        var cu = Panel(frame, "Customize", 40, 841, 240, 70, new Color(.02f, .07f, .17f, .9f), PanelLine);
        Icon(cu, "Icon", hanger, 66, 852, 48, 48);
        T(cu, "CustomizeLabel", "CUSTOMIZE", 130, 876, 140, 22, true);
        Click(cu);

        var sk = Panel(frame, "Skin", 303, 841, 194, 70, new Color(.02f, .07f, .17f, .9f), PanelLine);
        Icon(sk, "Icon", skinIcon, 328, 852, 48, 48);
        T(sk, "SkinLabel", "SKIN", 403, 876, 90, 22, true);
        Click(sk);

        ha = HA.Right;
        var d = Panel(frame, "Confirm", 1260, 826, 384, 86, BrightFill, BrightLine, .7f);
        Img(d, "InnerFrame", 1267, 833, 370, 72, LineSprite(), new Color(.35f, .75f, 1f, .5f), true);
        S(d, "TopSpecular", 1290, 830, 280, 2, new Color(.5f, .85f, 1f));
        T(d, "ConfirmLabel", "CONFIRM", 1270, 869, 290, 40, true, TextAnchor.MiddleCenter, true);
        T(d, "ConfirmChevrons", "\u00BB", 1550, 867, 70, 56, true, TextAnchor.MiddleCenter, true, new Color(.55f, .85f, 1f));
        Click(d);
    }
}
