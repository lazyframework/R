#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class EclipseStyledLobbyMenu
{
    [MenuItem("Tools/Project Eclipse/Create Styled Lobby")]
    static void Create()
    {
        var go = new GameObject("Eclipse Styled Lobby");
        Undo.RegisterCreatedObjectUndo(go, "Create Styled Lobby");
        go.AddComponent<EclipseStyledLobbyBuilder>().Build();
        Selection.activeGameObject = go;
        EditorSceneManager.MarkSceneDirty(go.scene);
    }
}

[CustomEditor(typeof(EclipseStyledLobbyBuilder))]
public class EclipseStyledLobbyInspector : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        EditorGUILayout.HelpBox(
            "Lobby dibangun ulang otomatis setiap Play. Tombol di bawah hanya untuk pratinjau di editor " +
            "(pratinjau tidak ikut tersimpan ke scene).",
            MessageType.Info);
        if (GUILayout.Button("PREVIEW STYLED LOBBY"))
        {
            var b = (EclipseStyledLobbyBuilder)target;
            b.Build();
        }
    }
}
#endif
