1. Copy folder Assets/EclipseLobby/Scripts ke Assets/ proyekmu (timpa file lama).
2. Hapus EclipseStyledPanel.cs dan EclipseStyledVector.cs.
3. Play pada objek "Eclipse Styled Lobby". Isi sprite sendiri lewat Inspector (latar, potret, banner, peta, ikon).
