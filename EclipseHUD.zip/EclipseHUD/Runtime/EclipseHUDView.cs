using UnityEngine;
using UnityEngine.UI;
namespace EclipseHUD {
public class EclipseHUDView : MonoBehaviour {
    public Text healthText,armorText,ammoText,timerText,headingText;
    public Image healthFill,armorFill;
    public RawImage minimap;
    public Image avatar;
    public HUDJoystick joystick;
    public void SetHealth(float value,float maximum=100){float t=maximum>0?Mathf.Clamp01(value/maximum):0;healthFill.fillAmount=t;healthText.text="HP  "+Mathf.RoundToInt(value);}
    public void SetArmor(float value,float maximum=100){float t=maximum>0?Mathf.Clamp01(value/maximum):0;armorFill.fillAmount=t;armorText.text="Armor  "+Mathf.RoundToInt(value);}
    public void SetAmmo(int loaded,int reserve){ammoText.text=loaded+" / "+reserve;}
    public void SetTimer(float seconds){int t=Mathf.Max(0,Mathf.FloorToInt(seconds));timerText.text=(t/60).ToString("00")+":"+(t%60).ToString("00");}
    public void SetHeading(float degrees){headingText.text=Mathf.RoundToInt(Mathf.Repeat(degrees,360)).ToString("000");}
}}
