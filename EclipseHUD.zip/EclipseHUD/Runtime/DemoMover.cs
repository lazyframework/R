using UnityEngine;
namespace EclipseReady {
public class DemoMover : MonoBehaviour {
 public ReadyHUD hud; public Transform player; public Camera viewCamera; Vector3 startScale;
 void Start(){startScale=player.localScale;}
 void Update(){if(!hud||!hud.demoMode||!player)return;Vector2 v=hud.joystick?hud.joystick.Value:Vector2.zero;
#if ENABLE_LEGACY_INPUT_MANAGER
  v+=new Vector2(Input.GetAxisRaw("Horizontal"),Input.GetAxisRaw("Vertical"));
#endif
 v=Vector2.ClampMagnitude(v,1);Vector3 delta=new Vector3(v.x,0,v.y)*4*Time.deltaTime;Vector3 p=player.position+delta;
 p.x=Mathf.Clamp(p.x,-14,14);p.z=Mathf.Clamp(p.z,-3,28);player.position=p;
 player.localScale=new Vector3(startScale.x,hud.Pose==0?startScale.y:(hud.Pose==1?startScale.y*.65f:startScale.y*.3f),startScale.z);
 if(viewCamera){viewCamera.transform.position=Vector3.Lerp(viewCamera.transform.position,p+new Vector3(2,3,-6),Time.deltaTime*6);viewCamera.transform.LookAt(p+new Vector3(0,1.4f,8));viewCamera.fieldOfView=Mathf.Lerp(viewCamera.fieldOfView,hud.IsAiming?42:62,Time.deltaTime*8);}
 }
}}
