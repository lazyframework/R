using UnityEngine;
using UnityEngine.UI;

namespace EclipseHUD {
public class HUDGlyph : MaskableGraphic {
    public enum Shape { Ring, Crosshair, Bullet, Rifle, Pistol, Person, Cross, Diamond, Shield, Gear, Grenade, Arrow, Bolt }
    public Shape shape;
    [Range(1,8)] public float thickness=2;
    void Line(VertexHelper vh, Vector2 a, Vector2 b, float w) {
        Vector2 n=(b-a).normalized; n=new Vector2(-n.y,n.x)*w*.5f;
        int i=vh.currentVertCount;
        vh.AddVert(a-n,color,Vector2.zero); vh.AddVert(a+n,color,Vector2.zero);
        vh.AddVert(b+n,color,Vector2.zero); vh.AddVert(b-n,color,Vector2.zero);
        vh.AddTriangle(i,i+1,i+2); vh.AddTriangle(i,i+2,i+3);
    }
    protected override void OnPopulateMesh(VertexHelper vh) {
        vh.Clear(); Rect r=rectTransform.rect;
        float s=Mathf.Min(r.width,r.height); Vector2 c=r.center;
        System.Action<float,float,float,float,float> L=(x,y,u,v,w)=>Line(vh,c+new Vector2(x,y)*s,c+new Vector2(u,v)*s,w*s);
        System.Action<float,float,float> Circle=(x,y,rad)=>{
            for(int k=0;k<80;k++) {float a=k*Mathf.PI*2/80,b=(k+1)*Mathf.PI*2/80;
                L(x+Mathf.Cos(a)*rad,y+Mathf.Sin(a)*rad,x+Mathf.Cos(b)*rad,y+Mathf.Sin(b)*rad,thickness/s);}
        };
        switch(shape) {
        case Shape.Ring: Circle(0,0,.47f); break;
        case Shape.Crosshair:
            Circle(0,0,.30f);Circle(0,0,.12f);
            L(-.47f,0,-.25f,0,.025f);L(.25f,0,.47f,0,.025f);L(0,-.47f,0,-.25f,.025f);L(0,.25f,0,.47f,.025f);break;
        case Shape.Cross: L(-.32f,0,.32f,0,.19f);L(0,-.32f,0,.32f,.19f);break;
        case Shape.Diamond:
            L(0,.42f,.30f,0,.04f);L(.30f,0,0,-.42f,.04f);L(0,-.42f,-.30f,0,.04f);L(-.30f,0,0,.42f,.04f);break;
        case Shape.Bullet:
            L(-.23f,-.24f,.20f,.19f,.20f);L(.20f,.19f,.34f,.34f,.11f);L(-.32f,-.33f,-.25f,-.26f,.20f);break;
        case Shape.Rifle:
            L(-.39f,.10f,.25f,.10f,.105f);L(.25f,.12f,.48f,.12f,.035f);
            L(-.39f,.10f,-.48f,-.04f,.09f);L(-.05f,.03f,-.12f,-.23f,.075f);
            L(.08f,.03f,.18f,-.18f,.10f);L(.04f,.15f,.04f,.24f,.04f);break;
        case Shape.Pistol:
            L(-.35f,.15f,.33f,.15f,.15f);L(.16f,.08f,.26f,-.30f,.17f);break;
        case Shape.Person:
            Circle(.06f,.31f,.085f);L(.02f,.17f,-.07f,-.07f,.12f);
            L(-.02f,.13f,-.22f,.02f,.065f);L(-.22f,.02f,-.31f,.18f,.06f);
            L(0,.12f,.20f,.03f,.065f);L(.20f,.03f,.30f,.18f,.06f);
            L(-.07f,-.07f,-.26f,-.34f,.09f);L(-.04f,-.07f,.18f,-.19f,.09f);L(.18f,-.19f,.29f,-.37f,.08f);break;
        case Shape.Shield:
            L(-.28f,.31f,0,.20f,.05f);L(0,.20f,.28f,.31f,.05f);L(.28f,.31f,.22f,-.13f,.05f);
            L(.22f,-.13f,0,-.39f,.05f);L(0,-.39f,-.22f,-.13f,.05f);L(-.22f,-.13f,-.28f,.31f,.05f);break;
        case Shape.Gear:
            Circle(0,0,.27f);Circle(0,0,.12f);
            for(int k=0;k<8;k++){float a=k*Mathf.PI/4;L(Mathf.Cos(a)*.25f,Mathf.Sin(a)*.25f,Mathf.Cos(a)*.40f,Mathf.Sin(a)*.40f,.10f);}break;
        case Shape.Grenade:
            Circle(0,-.05f,.25f);L(.02f,.19f,.13f,.36f,.10f);L(.13f,.36f,.30f,.22f,.05f);break;
        case Shape.Arrow:
            L(-.25f,-.25f,0,.35f,.06f);L(0,.35f,.25f,-.25f,.06f);L(-.25f,-.25f,0,-.12f,.06f);L(0,-.12f,.25f,-.25f,.06f);break;
        case Shape.Bolt:
            L(.22f,.40f,-.12f,0,.08f);L(-.12f,0,.15f,0,.08f);L(.15f,0,-.22f,-.40f,.08f);break;
        }
    }
}}
