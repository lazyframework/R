using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
namespace EclipseReady {
public class ReadyHUD : MonoBehaviour {
 [System.Serializable] public class ActionEvent : UnityEvent<string>{}
 public ActionEvent onAction=new ActionEvent();
 public Text ammoLabel,healthLabel,armorLabel,timerLabel,headingLabel,statusLabel;
 public Image healthFill,armorFill; public ReadyJoystick joystick; public ReadyHoldButton fire;
 public bool demoMode=true; public float health=100,armor=100; public int magazine=30,reserve=120;
 public float remainingTime=872; float nextShot; bool aiming; int pose;
 public void SetHealth(float v){health=Mathf.Clamp(v,0,100);healthFill.fillAmount=health/100;healthLabel.text="HP  "+Mathf.RoundToInt(health);}
 public void SetArmor(float v){armor=Mathf.Clamp(v,0,100);armorFill.fillAmount=armor/100;armorLabel.text="Armor  "+Mathf.RoundToInt(armor);}
 public void SetAmmo(int a,int b){magazine=a;reserve=b;ammoLabel.text=a+" / "+b;}
 public void SetHeading(float a){headingLabel.text=Mathf.RoundToInt(Mathf.Repeat(a,360)).ToString("000");}
 public void SetTimer(float t){remainingTime=Mathf.Max(0,t);int n=Mathf.FloorToInt(remainingTime);timerLabel.text=(n/60).ToString("00")+":"+(n%60).ToString("00");}
 public void Action(string action){onAction.Invoke(action);if(!demoMode)return;
  switch(action){
   case "Fire": Shoot();break;
   case "Reload":int take=Mathf.Min(30-magazine,reserve);SetAmmo(magazine+take,reserve-take);break;
   case "Heal":SetHealth(100);break;
   case "Aim":aiming=!aiming;break;
   case "Crouch":pose=pose==1?0:1;break;
   case "Prone":pose=pose==2?0:2;break;
  }
  if(statusLabel){statusLabel.text="DEMO / "+action;CancelInvoke("ClearStatus");Invoke("ClearStatus",1.5f);}
 }
 void ClearStatus(){if(statusLabel)statusLabel.text="";}
 void Shoot(){if(Time.time<nextShot||magazine<=0)return;nextShot=Time.time+.12f;SetAmmo(magazine-1,reserve);}
 void Update(){if(!demoMode)return;SetTimer(remainingTime-Time.deltaTime);if(fire&&fire.Held)Shoot();
#if ENABLE_LEGACY_INPUT_MANAGER
  if(Input.GetKeyDown(KeyCode.Q))Action("Ability");if(Input.GetKeyDown(KeyCode.E))Action("Heal");if(Input.GetKeyDown(KeyCode.R))Action("Reload");
#endif
 }
 public bool IsAiming{get{return aiming;}} public int Pose{get{return pose;}}
}}
