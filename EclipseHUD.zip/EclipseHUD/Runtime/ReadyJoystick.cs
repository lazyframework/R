using UnityEngine;
using UnityEngine.EventSystems;
namespace EclipseReady {
public class ReadyJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler {
 public RectTransform handle; public float radius=70; public Vector2 Value {get;private set;}
 Vector2 origin; int finger=int.MinValue;
 void Awake(){if(handle)origin=handle.anchoredPosition;}
 public void OnPointerDown(PointerEventData e){if(finger!=int.MinValue)return;finger=e.pointerId;OnDrag(e);}
 public void OnDrag(PointerEventData e){if(e.pointerId!=finger)return;Vector2 p;var r=(RectTransform)transform;RectTransformUtility.ScreenPointToLocalPointInRectangle(r,e.position,e.pressEventCamera,out p);p-=r.rect.center;Value=Vector2.ClampMagnitude(p/radius,1);if(handle)handle.anchoredPosition=origin+Value*radius;}
 public void OnPointerUp(PointerEventData e){if(e.pointerId==finger)ResetValue();}
 void OnDisable(){ResetValue();}
 void ResetValue(){finger=int.MinValue;Value=Vector2.zero;if(handle)handle.anchoredPosition=origin;}
}}
