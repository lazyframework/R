using UnityEngine;
using UnityEngine.EventSystems;
namespace EclipseReady {
public class ReadyHoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler {
 public bool Held {get;private set;}
 public void OnPointerDown(PointerEventData e){Held=true;}
 public void OnPointerUp(PointerEventData e){Held=false;}
 void OnDisable(){Held=false;}
}}
