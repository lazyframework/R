using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
namespace EclipseHUD {
public class HUDJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler {
    public RectTransform handle;
    public float radius=70;
    public Vector2 Value {get; private set;}
    public UnityEvent<Vector2> onValueChanged=new UnityEvent<Vector2>();
    int pointer=int.MinValue;
    public void OnPointerDown(PointerEventData e) {if(pointer!=int.MinValue)return;pointer=e.pointerId;OnDrag(e);}
    public void OnDrag(PointerEventData e) {
        if(e.pointerId!=pointer)return;
        Vector2 p;RectTransformUtility.ScreenPointToLocalPointInRectangle((RectTransform)transform,e.position,e.pressEventCamera,out p);
        Value=Vector2.ClampMagnitude(p/radius,1);handle.anchoredPosition=Value*radius;onValueChanged.Invoke(Value);
    }
    public void OnPointerUp(PointerEventData e){if(e.pointerId!=pointer)return;ResetStick();}
    void OnDisable(){ResetStick();}
    void ResetStick(){pointer=int.MinValue;Value=Vector2.zero;if(handle)handle.anchoredPosition=Vector2.zero;onValueChanged.Invoke(Value);}
}}
