using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEditor;
using EclipseHUD;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

public static class EclipseHUDBuilder {
    static Color Blue=new Color(.15f,.65f,1,1), Pale=new Color(.73f,.85f,1,1), Dark=new Color(.025f,.055f,.12f,.72f);
    static Font font;
    static Transform root;
    static RectTransform Rect(string name,Transform parent,float x,float y,float w,float h) {
        var g=new GameObject(name,typeof(RectTransform));var r=g.GetComponent<RectTransform>();r.SetParent(parent,false);
        r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(w,h);return r;
    }
    static Image Box(string name,Transform p,float x,float y,float w,float h,Color c,bool border=false) {
        var r=Rect(name,p,x,y,w,h);var i=r.gameObject.AddComponent<Image>();i.color=c;i.raycastTarget=false;
        if(border){var o=r.gameObject.AddComponent<Outline>();o.effectColor=new Color(.55f,.73f,1,.65f);o.effectDistance=new Vector2(1,-1);}return i;
    }
    static Text Label(string text,Transform p,float x,float y,float w,float h,int size,Color? color=null,TextAnchor align=TextAnchor.MiddleLeft) {
        var r=Rect(text,p,x,y,w,h);var t=r.gameObject.AddComponent<Text>();t.font=font;t.text=text;t.fontSize=size;t.color=color??Color.white;t.alignment=align;t.raycastTarget=false;return t;
    }
    static HUDGlyph Glyph(HUDGlyph.Shape s,Transform p,float x,float y,float w,float h,Color? color=null) {
        var r=Rect(s.ToString(),p,x,y,w,h);var g=r.gameObject.AddComponent<HUDGlyph>();g.shape=s;g.color=color??Color.white;g.raycastTarget=false;return g;
    }
    static Button Round(string name,float x,float y,float size,HUDGlyph.Shape shape,string key="",bool blue=false) {
        var r=Rect(name,root,x,y,size,size);var hit=r.gameObject.AddComponent<Image>();hit.color=new Color(0,0,0,0);
        var b=r.gameObject.AddComponent<Button>();b.targetGraphic=hit;
        Glyph(HUDGlyph.Shape.Ring,r,0,0,size,size,blue?Blue:Pale);
        Glyph(shape,r,size*.24f,size*.24f,size*.52f,size*.52f,blue?Blue:Color.white);
        if(key!="")Label(key,r,size*.65f,size*.70f,30,25,20);
        var cb=b.colors;cb.highlightedColor=new Color(.2f,.65f,1,.18f);cb.pressedColor=new Color(.2f,.65f,1,.35f);b.colors=cb;
        return b;
    }
    static Image Bar(Transform p,string name,float x,float y,float w,Color color) {
        Box(name+" Track",p,x,y,w,12,new Color(.03f,.07f,.15f,.9f));
        var i=Box(name,p,x,y,w,12,color);i.sprite=AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");i.type=Image.Type.Filled;i.fillMethod=Image.FillMethod.Horizontal;i.fillAmount=1;return i;
    }
    [MenuItem("Tools/Eclipse HUD/Build HUD")]
    public static void Build() {
#if UNITY_2022_2_OR_NEWER
        font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        font=Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        var go=new GameObject("Eclipse HUD",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
        Undo.RegisterCreatedObjectUndo(go,"Build Eclipse HUD");go.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
        var sc=go.GetComponent<CanvasScaler>();sc.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;sc.referenceResolution=new Vector2(1672,941);sc.screenMatchMode=CanvasScaler.ScreenMatchMode.Expand;
        var frame=Rect("Reference Frame 1672x941",go.transform,0,0,1672,941);frame.anchorMin=frame.anchorMax=new Vector2(.5f,.5f);frame.pivot=new Vector2(.5f,.5f);frame.anchoredPosition=Vector2.zero;root=frame;
        var view=go.AddComponent<EclipseHUDView>();
        var profile=Box("Profile",root,25,24,312,126,Dark);
        view.avatar=Box("Avatar - assign sprite",profile.transform,0,0,112,108,new Color(.07f,.14f,.26f),true);
        Glyph(HUDGlyph.Shape.Person,view.avatar.transform,23,14,68,86,Pale);
        Label("FamaLine",profile.transform,132,2,170,35,25);Label("Lv. 12",profile.transform,132,39,90,30,24);
        Box("XP Track",profile.transform,207,51,75,8,new Color(.2f,.3f,.4f));Box("XP Fill",profile.transform,207,51,28,8,Blue);
        Label("720 / 2,000",profile.transform,285,38,100,30,17);Glyph(HUDGlyph.Shape.Shield,profile.transform,132,75,45,48);Label("Silver III",profile.transform,188,82,110,30,21);
        var mission=Box("Mission",root,25,159,330,120,Dark,true);
        Glyph(HUDGlyph.Shape.Diamond,mission.transform,8,7,30,30,Color.yellow);Label("Main Mission",mission.transform,46,5,265,35,24,Blue);
        Label("Infiltrate the Research Facility",mission.transform,46,42,280,30,20);
        Glyph(HUDGlyph.Shape.Diamond,mission.transform,44,75,22,22,Color.yellow);Label("Reach the Control Room (0/1)",mission.transform,73,72,255,29,19);
        var compass=Box("Compass",root,553,25,565,40,new Color(.03f,.08f,.18f,.16f));
        Label("W    285   300    NW    330           N     15     30    NE",compass.transform,0,0,565,40,20,Pale,TextAnchor.MiddleCenter);
        var heading=Box("Heading",root,802,26,69,39,new Color(.04f,.22f,.48f,.8f),true);view.headingText=Label("330",heading.transform,0,0,69,39,27,null,TextAnchor.MiddleCenter);
        Glyph(HUDGlyph.Shape.Diamond,root,825,63,20,13,Blue);
        var gem=Box("Premium Currency",root,1163,25,143,39,Dark);Glyph(HUDGlyph.Shape.Diamond,gem.transform,7,3,30,32,Blue);Label("1,200  +",gem.transform,48,0,94,39,23);
        var coin=Box("Coins",root,1321,25,150,39,Dark);Glyph(HUDGlyph.Shape.Ring,coin.transform,7,4,31,31,new Color(1,.73f,.18f));Label("15,340 +",coin.transform,46,0,104,39,23);
        Round("Notifications",1491,20,55,HUDGlyph.Shape.Grenade);Round("Settings",1583,20,55,HUDGlyph.Shape.Gear);
        var map=Box("Minimap Frame",root,1434,82,214,194,Dark,true);
        var raw=Rect("Minimap - assign RenderTexture",map.transform,2,2,210,190).gameObject.AddComponent<RawImage>();raw.color=new Color(.32f,.42f,.57f,.8f);raw.raycastTarget=false;view.minimap=raw;
        for(int i=0;i<6;i++){var block=Box("Map building "+i,map.transform,18+(i%3)*63,33+(i/3)*83,37,50,new Color(.44f,.55f,.68f,.32f),true);block.rectTransform.localRotation=Quaternion.Euler(0,0,-25);}
        Label("N",map.transform,96,0,30,28,20);Glyph(HUDGlyph.Shape.Arrow,map.transform,91,78,35,35,Blue);Glyph(HUDGlyph.Shape.Diamond,map.transform,136,28,29,29,Color.yellow);
        Box("Timer Plate",root,1438,279,121,34,Dark);view.timerText=Label("14:32",root,1470,279,100,34,24);
        Glyph(HUDGlyph.Shape.Ring,root,1443,285,23,23);
        Round("Reload",60,405,114,HUDGlyph.Shape.Bullet);Round("Sprint",200,474,92,HUDGlyph.Shape.Person);
        var joy=Rect("Movement Joystick",root,110,584,232,232);var hitJoy=joy.gameObject.AddComponent<Image>();hitJoy.color=Color.clear;
        Glyph(HUDGlyph.Shape.Ring,joy,0,0,232,232,new Color(.63f,.76f,1,.7f));
        var h=Rect("Handle",joy,71,71,90,90);h.anchorMin=h.anchorMax=new Vector2(.5f,.5f);h.pivot=new Vector2(.5f,.5f);h.anchoredPosition=Vector2.zero;
        Glyph(HUDGlyph.Shape.Ring,h,0,0,90,90,Pale);var stick=joy.gameObject.AddComponent<HUDJoystick>();stick.handle=h;stick.radius=70;view.joystick=stick;
        Round("Ability Q",1570,333,85,HUDGlyph.Shape.Bolt,"Q",true);Round("Heal E",1570,419,85,HUDGlyph.Shape.Cross,"E");Round("Dash R",1570,502,85,HUDGlyph.Shape.Person,"R",true);
        Round("Aim",1461,533,98,HUDGlyph.Shape.Crosshair);Round("Fire",1311,624,173,HUDGlyph.Shape.Bullet);
        Round("Crouch",1378,805,107,HUDGlyph.Shape.Person);var prone=Round("Prone",1518,793,110,HUDGlyph.Shape.Person);prone.transform.GetChild(1).localRotation=Quaternion.Euler(0,0,90);
        var gun=Box("Primary Weapon",root,588,773,243,79,Dark,true);Box("Selected Accent",gun.transform,0,0,3,79,Blue);Glyph(HUDGlyph.Shape.Rifle,gun.transform,68,0,136,50);view.ammoText=Label("30 / 120",gun.transform,25,41,160,36,27);
        var pistol=Box("Secondary Weapon",root,842,779,167,73,Dark,true);Glyph(HUDGlyph.Shape.Pistol,pistol.transform,42,4,82,43,Pale);Label("15 / 45",pistol.transform,12,40,135,30,23);
        var grenade=Box("Grenades",root,1020,785,90,67,Dark,true);Glyph(HUDGlyph.Shape.Grenade,grenade.transform,17,10,43,43);Label("2",grenade.transform,66,33,22,30,22);
        var med=Box("Medkits",root,1122,785,92,67,Dark,true);Glyph(HUDGlyph.Shape.Cross,med.transform,24,17,34,34);Label("1",med.transform,69,33,22,30,22);
        var vitals=Box("Vitals",root,490,854,440,67,Dark);
        Glyph(HUDGlyph.Shape.Cross,vitals.transform,15,9,27,25);view.healthText=Label("HP  100",vitals.transform,50,0,92,35,23);
        view.healthFill=Bar(vitals.transform,"Health Fill",141,13,289,new Color(.73f,.85f,1));
        Glyph(HUDGlyph.Shape.Shield,vitals.transform,16,36,26,25,Pale);view.armorText=Label("Armor  100",vitals.transform,50,32,94,30,18);
        view.armorFill=Bar(vitals.transform,"Armor Fill",141,41,289,Blue);
        Glyph(HUDGlyph.Shape.Crosshair,root,815,452,42,42,new Color(1,.35f,.25f,.9f));
        if(Object.FindObjectOfType<EventSystem>()==null) {
            var es=new GameObject("EventSystem",typeof(EventSystem));Undo.RegisterCreatedObjectUndo(es,"Create EventSystem");
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }
        Selection.activeGameObject=go;UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(go.scene);
        Debug.Log("Eclipse HUD created. Assign artwork, button events, and gameplay references in the Inspector.",go);
    }
}
