using System;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.Events;
using EclipseReady;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif
[InitializeOnLoad]
public static class ReadyProjectSetup {
 const string Folder="Assets/EclipseHUD";
 [Serializable] public class Element {public string name,kind,text,asset,color,align,action;public float x,y,w,h;public int size;}
 [Serializable] public class Layout {public Element[] elements;}
 static ReadyProjectSetup(){EditorApplication.delayCall+=AutoSetup;}
 static void AutoSetup(){if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling||EditorApplication.isUpdating){EditorApplication.delayCall+=AutoSetup;return;}if(!File.Exists(Folder+"/Generated/HUDDemo.unity"))Build(false);}
 [MenuItem("Tools/Eclipse Ready/Rebuild Demo")]
 public static void Rebuild(){if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;Build(true);}
 static Font GetFont(){
#if UNITY_2022_2_OR_NEWER
 return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
 return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
 }
 static RectTransform R(string name,Transform parent,float x,float y,float w,float h){var g=new GameObject(name,typeof(RectTransform));var r=(RectTransform)g.transform;r.SetParent(parent,false);r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(w,h);return r;}
 static Color C(string hex){Color c;ColorUtility.TryParseHtmlString(hex,out c);return c;}
 static void Build(bool replace){
  // Do not replace an existing unsaved user scene during automatic setup.
  var current=EditorSceneManager.GetActiveScene();if(!replace&&current.isDirty){Debug.LogWarning("Eclipse Ready: save your scene, then use Tools/Eclipse Ready/Rebuild Demo.");return;}
  Directory.CreateDirectory(Folder+"/Generated");AssetDatabase.Refresh();
  foreach(string path in Directory.GetFiles(Folder+"/Art","*.png")){
   var ti=(TextureImporter)AssetImporter.GetAtPath(path);if(ti==null)continue;
   if(ti.textureType!=TextureImporterType.Sprite||ti.mipmapEnabled){ti.textureType=TextureImporterType.Sprite;ti.spriteImportMode=SpriteImportMode.Single;ti.alphaIsTransparency=true;ti.mipmapEnabled=false;ti.textureCompression=TextureImporterCompression.Uncompressed;ti.SaveAndReimport();}
  }
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
  var canvasObject=new GameObject("Eclipse HUD",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
  canvasObject.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
  var scaler=canvasObject.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1672,941);scaler.screenMatchMode=CanvasScaler.ScreenMatchMode.Expand;
  var root=R("HUD Layout",canvasObject.transform,0,0,1672,941);root.anchorMin=root.anchorMax=new Vector2(.5f,.5f);root.pivot=new Vector2(.5f,.5f);root.anchoredPosition=Vector2.zero;
  var hud=canvasObject.AddComponent<ReadyHUD>();
  var layout=JsonUtility.FromJson<Layout>(File.ReadAllText(Folder+"/Data/layout.json"));Font font=GetFont();
  var objects=new System.Collections.Generic.Dictionary<string,GameObject>();
  foreach(var e in layout.elements){var rt=R(e.name,root,e.x,e.y,e.w,e.h);objects[e.name]=rt.gameObject;
   if(e.kind=="text"){var t=rt.gameObject.AddComponent<Text>();t.font=font;t.fontSize=e.size;t.text=e.text;t.color=C(e.color);t.alignment=e.align=="center"?TextAnchor.MiddleCenter:TextAnchor.MiddleLeft;t.raycastTarget=false;}
   else {var i=rt.gameObject.AddComponent<Image>();i.color=C(e.color);i.raycastTarget=e.kind=="button"||e.kind=="joystick";
    if(!string.IsNullOrEmpty(e.asset))i.sprite=AssetDatabase.LoadAssetAtPath<Sprite>(Folder+"/Art/"+e.asset+".png");
    if(e.kind=="button"){
     var b=rt.gameObject.AddComponent<Button>();b.targetGraphic=i;var colors=b.colors;colors.highlightedColor=new Color(.65f,.86f,1,1);colors.pressedColor=new Color(.25f,.65f,1,1);b.colors=colors;
     // Persistent listener survives prefab and scene serialization.
     UnityEditor.Events.UnityEventTools.AddStringPersistentListener(b.onClick,new UnityAction<string>(hud.Action),e.action);
     if(e.action=="Fire")hud.fire=rt.gameObject.AddComponent<ReadyHoldButton>();
    }
   }
  }
  hud.ammoLabel=objects["Ammo"].GetComponent<Text>();hud.healthLabel=objects["Health"].GetComponent<Text>();hud.armorLabel=objects["Armor"].GetComponent<Text>();hud.timerLabel=objects["Timer"].GetComponent<Text>();hud.headingLabel=objects["Heading"].GetComponent<Text>();
  hud.healthFill=objects["Health Fill"].GetComponent<Image>();hud.armorFill=objects["Armor Fill"].GetComponent<Image>();
  foreach(var i in new[]{hud.healthFill,hud.armorFill}){i.sprite=AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");i.type=Image.Type.Filled;i.fillMethod=Image.FillMethod.Horizontal;i.fillAmount=1;}
  hud.joystick=objects["Joystick"].AddComponent<ReadyJoystick>();hud.joystick.handle=(RectTransform)objects["Joystick Handle"].transform;
  // Handle is a sibling so its absolute layout position is preserved.
  var st=R("Demo Action Status",root,650,710,400,30).gameObject.AddComponent<Text>();st.font=font;st.fontSize=20;st.alignment=TextAnchor.MiddleCenter;st.color=new Color(.5f,.8f,1);st.raycastTarget=false;hud.statusLabel=st;
  PrefabUtility.SaveAsPrefabAsset(canvasObject,Folder+"/Generated/EclipseHUD.prefab");
  var es=new GameObject("EventSystem",typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
  es.AddComponent<InputSystemUIInputModule>();
#else
  es.AddComponent<StandaloneInputModule>();
#endif
  CreateEnvironment(hud);
  EditorSceneManager.SaveScene(scene,Folder+"/Generated/HUDDemo.unity");EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(Folder+"/Generated/HUDDemo.unity",true)};AssetDatabase.SaveAssets();Selection.activeGameObject=canvasObject;
  Debug.Log("Eclipse Ready: HUDDemo scene and EclipseHUD prefab created. Press Play. This is an approximation of the reference, not an exact reproduction.");
 }
 static Material Mat(string name,Color color,bool emissive=false){
  string path=Folder+"/Generated/"+name+".mat";Material m=AssetDatabase.LoadAssetAtPath<Material>(path);
  if(!m){m=new Material(Shader.Find("Standard"));AssetDatabase.CreateAsset(m,path);}m.color=color;
  if(emissive){m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",color*2);}return m;
 }
 static GameObject Cube(string n,Vector3 p,Vector3 s,Material m){var g=GameObject.CreatePrimitive(PrimitiveType.Cube);g.name=n;g.transform.position=p;g.transform.localScale=s;g.GetComponent<Renderer>().sharedMaterial=m;return g;}
 static void CreateEnvironment(ReadyHUD hud){
  var wall=Mat("Facility",new Color(.25f,.31f,.40f));var dark=Mat("Tactical",new Color(.035f,.05f,.075f));var ground=Mat("Ground",new Color(.18f,.23f,.29f));var blue=Mat("BlueLight",new Color(.05f,.45f,1),true);var yellow=Mat("Hazard",new Color(.8f,.55f,.12f));
  RenderSettings.ambientLight=new Color(.45f,.55f,.7f);RenderSettings.fog=true;RenderSettings.fogColor=new Color(.38f,.56f,.75f);RenderSettings.fogDensity=.009f;
  var light=new GameObject("Sun",typeof(Light));light.transform.rotation=Quaternion.Euler(40,-30,0);light.GetComponent<Light>().type=LightType.Directional;light.GetComponent<Light>().intensity=1.4f;
  Cube("Courtyard",new Vector3(0,-.2f,15),new Vector3(80,.4f,100),ground);
  for(int side=-1;side<=1;side+=2){Cube("Research Wing",new Vector3(side*20,6,24),new Vector3(12,12,48),wall);for(int k=0;k<7;k++){Cube("Blue Facade Strip",new Vector3(side*13.92f,4+k*.5f,24),new Vector3(.06f,.06f,44),blue);}}
  Cube("Research Gate",new Vector3(0,6,43),new Vector3(30,12,3),wall);Cube("Gate Door",new Vector3(0,3.5f,41.4f),new Vector3(7,7,.1f),dark);Cube("Gate Header",new Vector3(0,7.5f,41.2f),new Vector3(12,.25f,.2f),blue);
  for(int k=0;k<9;k++){float x=(k%3-1)*8;float z=9+(k/3)*10;Cube("Cover Crate",new Vector3(x,1,z),new Vector3(4,2,2),wall);Cube("Crate LED",new Vector3(x,1.8f,z-1.02f),new Vector3(3.5f,.08f,.04f),blue);Cube("Crate Hazard",new Vector3(x-1.8f,1,z-1.04f),new Vector3(.15f,1.6f,.05f),yellow);}
  for(int k=0;k<10;k++){float x=(k-5)*5;Cube("Skyline",new Vector3(x,8+k%4*4,75),new Vector3(3,16+k%4*8,4),wall);Cube("Tower LED",new Vector3(x,8+k%4*4,72.9f),new Vector3(.12f,16+k%4*8,.1f),blue);}
  var player=GameObject.CreatePrimitive(PrimitiveType.Capsule);player.name="Demo Soldier Placeholder";player.transform.position=new Vector3(-1,1,0);player.GetComponent<Renderer>().sharedMaterial=dark;
  Cube("Backpack",new Vector3(-1,1.3f,-.45f),new Vector3(.65f,.9f,.3f),wall).transform.SetParent(player.transform,true);
  Cube("Rifle Placeholder",new Vector3(-.4f,1.4f,.5f),new Vector3(.16f,.18f,1.2f),dark).transform.SetParent(player.transform,true);
  var cameraObject=new GameObject("Main Camera",typeof(Camera),typeof(AudioListener));cameraObject.tag="MainCamera";var camera=cameraObject.GetComponent<Camera>();camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.35f,.55f,.78f);camera.transform.position=new Vector3(1,4,-6);camera.transform.LookAt(new Vector3(-1,2,10));camera.farClipPlane=200;
  var demo=new GameObject("Demo Controls").AddComponent<DemoMover>();demo.hud=hud;demo.player=player.transform;demo.viewCamera=camera;
 }
}
