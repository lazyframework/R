using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif
public class EclipseStyledLobbyBuilder:MonoBehaviour {
    [Header("Optional assets belonging to your project. All empty by default.")]
    public Font font;public Sprite background,portrait,agentBanner,mapArtwork;public RenderTexture characterPreview;
    [Header("Profile")]
    public string playerName="FamaLine";public int level=12,diamonds=1200,coins=15340;
    [Serializable]public class RouteEvent:UnityEvent<string>{}
    public RouteEvent onNavigate=new RouteEvent();public UnityEvent onDeploy=new UnityEvent();
    public Color cyan=new Color(.15f,.65f,1,1);
    RectTransform frame;
    const string Root="StyledLobbyCanvas";
    void Start(){var old=transform.Find(Root);if(!old)Build();else foreach(var b in old.GetComponentsInChildren<Button>(true)){string id=b.gameObject.name;b.onClick.RemoveAllListeners();b.onClick.AddListener(()=>Route(id));}}
    public void Route(string id){onNavigate.Invoke(id);if(id=="Deploy")onDeploy.Invoke();Debug.Log("Lobby: "+id,this);}
    RectTransform R(Transform p,string n,float x,float y,float w,float h){var r=new GameObject(n,typeof(RectTransform)).GetComponent<RectTransform>();r.SetParent(p,false);r.anchorMin=r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,1);r.anchoredPosition=new Vector2(x,-y);r.sizeDelta=new Vector2(w,h);return r;}
    Text T(Transform p,string n,string text,float x,float y,float w,float h,int size=20,bool bold=false,TextAnchor align=TextAnchor.MiddleLeft){var t=R(p,n,x,y,w,h).gameObject.AddComponent<Text>();t.font=font;t.text=text;t.fontSize=size;t.fontStyle=bold?FontStyle.Bold:FontStyle.Normal;t.color=new Color(.85f,.92f,1);t.alignment=align;t.raycastTarget=false;return t;}
    Image S(Transform p,string n,float x,float y,float w,float h,Color c){var i=R(p,n,x,y,w,h).gameObject.AddComponent<Image>();i.color=c;i.raycastTarget=false;return i;}
    void V(Transform p,EclipseStyledVector.Shape shape,float x,float y,float w,float h,Color c,float thickness=1.5f){var v=R(p,shape.ToString(),x,y,w,h).gameObject.AddComponent<EclipseStyledVector>();v.shape=shape;v.color=c;v.thickness=thickness;v.raycastTarget=false;}
    void A(Transform p,string n,Sprite asset,float x,float y,float w,float h){if(!asset)return;var i=R(p,n,x,y,w,h).gameObject.AddComponent<Image>();i.sprite=asset;i.raycastTarget=false;}
    EclipseStyledPanel P(Transform p,string n,float x,float y,float w,float h,bool bright=false,float cut=16){var r=R(p,n,x,y,w,h);var g=r.gameObject.AddComponent<EclipseStyledPanel>();g.cut=cut;g.color=bright?new Color(.025f,.22f,.61f,.98f):new Color(.025f,.072f,.15f,.97f);g.bottom=bright?new Color(.007f,.045f,.17f,.99f):new Color(.006f,.017f,.045f,.98f);g.edge=bright?cyan:new Color(.21f,.40f,.68f,.95f);g.border=bright?2.4f:1.2f;return g;}
    void Click(Graphic g){g.raycastTarget=true;var b=g.gameObject.AddComponent<Button>();b.targetGraphic=g;var c=b.colors;c.highlightedColor=new Color(.65f,.86f,1);c.pressedColor=new Color(.35f,.6f,.9f);c.selectedColor=Color.white;c.fadeDuration=.12f;b.colors=c;string id=g.name;b.onClick.AddListener(()=>Route(id));}
    void Detail(Transform p,float w,float h){S(p,"TopAccent",23,2,Mathf.Min(63,w*.24f),2,cyan);S(p,"LowerTrace",15,h-7,w-50,1,new Color(.10f,.35f,.61f,.6f));for(int i=0;i<3;i++){var t=S(p,"Slash"+i,w-31+i*7,h-12,3,8,new Color(.17f,.55f,.89f,.7f));t.rectTransform.localEulerAngles=new Vector3(0,0,-30);}}
    void Glow(Transform p,string n,float x,float y,float w,float h){for(int i=3;i>=1;i--){var g=P(p,n+"Halo"+i,x-i*2,y-i*2,w+i*4,h+i*4,true,22);g.color=g.bottom=Color.clear;g.edge=new Color(.05f,.4f,1,.055f*(4-i));g.border=2;g.raycastTarget=false;}}
    [ContextMenu("Build Styled Lobby")]
    public void Build(){var old=transform.Find(Root);if(old){old.gameObject.SetActive(false);if(Application.isPlaying)Destroy(old.gameObject);else DestroyImmediate(old.gameObject);}
        if(!font){
#if UNITY_2022_2_OR_NEWER
            font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font=Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }
        var go=new GameObject(Root,typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));go.transform.SetParent(transform,false);go.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
        var scale=go.GetComponent<CanvasScaler>();scale.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scale.referenceResolution=new Vector2(1672,941);scale.matchWidthOrHeight=.5f;
        frame=R(go.transform,"ReferenceFrame",0,0,1672,941);frame.anchorMin=frame.anchorMax=frame.pivot=new Vector2(.5f,.5f);frame.anchoredPosition=Vector2.zero;frame.gameObject.AddComponent<EclipseStyledFit>();
        Background();Header();Profile();Left();Right();Bottom();
        if(!UnityEngine.Object.FindObjectOfType<EventSystem>()){var es=new GameObject("EventSystem",typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }
    }
    void Background(){var bg=P(frame,"Backdrop_DisableForScene3D",0,0,1672,941,false,0);bg.border=0;bg.color=new Color(.015f,.048f,.105f);bg.bottom=new Color(.003f,.009f,.025f);bg.raycastTarget=false;
        if(background)A(bg.transform,"OwnBackground",background,0,0,1672,941);
        if(!background){V(bg.transform,EclipseStyledVector.Shape.Grid,0,105,1672,684,new Color(.08f,.32f,.62f,.42f));
            for(int i=0;i<7;i++){var rail=S(bg.transform,"CeilingLight",470+i*135,17,80,3,new Color(.14f,.5f,1,.3f));rail.rectTransform.localEulerAngles=new Vector3(0,0,-15);}
            V(bg.transform,EclipseStyledVector.Shape.Globe,650,100,640,600,new Color(.09f,.48f,1,.42f),1.3f);
            V(bg.transform,EclipseStyledVector.Shape.Rings,570,650,650,150,new Color(.12f,.54f,1,.65f),1.6f);
            for(int i=0;i<5;i++){var console=P(bg.transform,"Console"+i,454+i*162,535,145,86,false,4);console.raycastTarget=false;V(console.transform,EclipseStyledVector.Shape.Grid,8,8,129,70,new Color(.12f,.5f,1,.6f));}
        }
        var stage=R(frame,"CharacterStage_OwnRenderTexture",530,112,700,675);if(characterPreview){var raw=stage.gameObject.AddComponent<RawImage>();raw.texture=characterPreview;raw.raycastTarget=false;}
        else{var box=P(stage,"EmptyCharacterSlot",215,380,270,68,false,10);box.color=new Color(.015f,.05f,.12f,.6f);box.bottom=new Color(.005f,.02f,.06f,.6f);box.raycastTarget=false;T(box.transform,"SlotTitle","CHARACTER PREVIEW",12,7,246,25,18,true,TextAnchor.MiddleCenter);var tip=T(box.transform,"SlotHint","ASSIGN YOUR 3D RENDER",12,33,246,22,12,false,TextAnchor.MiddleCenter);tip.color=new Color(.35f,.6f,.85f);}
    }
    void Header(){S(frame,"HeaderRule",30,106,1610,1,new Color(.15f,.36f,.65f,.65f));V(frame,EclipseStyledVector.Shape.Diamond,33,17,116,81,cyan,2.5f);T(frame,"Project","PROJECT",174,22,260,29,23,true);T(frame,"Brand","ECLIPSE",169,42,270,53,42,true);
        Wallet("Diamonds",1045,163,diamonds.ToString("N0"),true);Wallet("Coins",1218,172,coins.ToString("N0"),false);
        Top("Notifications",1429,EclipseStyledVector.Shape.Bell);Top("Friends",1510,EclipseStyledVector.Shape.Friends);Top("SettingsTop",1591,EclipseStyledVector.Shape.Gear);Badge(frame,1457,20);
    }
    void Wallet(string id,float x,float w,string value,bool gem){var p=P(frame,id,x,27,w,44,false,0);p.bottom=new Color(.006f,.017f,.04f,.8f);V(p.transform,gem?EclipseStyledVector.Shape.Diamond:EclipseStyledVector.Shape.Target,11,7,29,30,gem?cyan:new Color(1,.72f,.3f),2);T(p.transform,"Balance",value,52,0,w-86,44,21,true);S(p.transform,"PlusPlate",w-36,1,35,42,new Color(.13f,.29f,.5f,.32f));T(p.transform,"Plus","+",w-36,0,35,44,29,false,TextAnchor.MiddleCenter);Click(p);}
    void Top(string id,float x,EclipseStyledVector.Shape shape){var g=S(frame,id,x-4,22,51,49,Color.clear);V(g.transform,shape,7,7,36,36,new Color(.8f,.89f,1),2.6f);Click(g);}
    void Badge(Transform p,float x,float y){var b=P(p,"AlertBadge",x,y,21,21,true,7);b.color=b.bottom=new Color(.85f,.06f,.12f);b.edge=new Color(1,.25f,.3f);b.border=1;T(b.transform,"Alert","!",0,0,21,21,16,true,TextAnchor.MiddleCenter);b.raycastTarget=false;}
    void Profile(){var r=R(frame,"ProfileGroup",32,125,406,158);var p=P(r,"Portrait",3,1,114,113,true,0);var inset=P(p.transform,"PortraitInset",5,5,104,103,false,0);inset.raycastTarget=false;
        if(portrait)A(inset.transform,"OwnPortrait",portrait,2,2,100,99);else{V(inset.transform,EclipseStyledVector.Shape.Grid,3,3,98,97,new Color(.13f,.48f,.9f,.4f));V(inset.transform,EclipseStyledVector.Shape.Agent,20,12,65,82,new Color(.6f,.8f,1),2);}
        Click(p);T(r,"PlayerName",playerName,138,11,255,37,25,true);T(r,"Level","Lv. "+level,138,52,88,34,24,true);S(r,"XPTrack",213,64,158,7,new Color(.08f,.15f,.29f));S(r,"XPFill",213,64,57,7,cyan);T(r,"Experience","EXP 720 / 2,000",267,77,135,23,14);
        var rank=P(r,"RankPlate",137,104,190,50,false,9);rank.border=.7f;V(rank.transform,EclipseStyledVector.Shape.Shield,2,1,43,46,new Color(.69f,.8f,.96f),2);T(rank.transform,"Rank","Silver III",58,7,125,34,21,true);T(r,"Info","i",279,116,24,25,18,false,TextAnchor.MiddleCenter);
    }
    void Left(){var p=P(frame,"AgentPromo",30,370,375,151,true,9);Detail(p.transform,375,151);A(p.transform,"OwnBanner",agentBanner,3,3,369,145);if(!agentBanner){V(p.transform,EclipseStyledVector.Shape.Grid,3,3,164,145,new Color(.18f,.5f,1,.45f));V(p.transform,EclipseStyledVector.Shape.Agent,36,13,110,132,new Color(.4f,.7f,1,.8f),2.5f);}
        T(p.transform,"Heading","NEW AGENT",181,28,190,32,25,true);T(p.transform,"AgentName","\"VYRA\"",180,59,190,36,29,true);var get=P(p.transform,"GetNow",224,110,139,30,true,9);get.color=get.bottom=new Color(.28f,.68f,1);get.edge=new Color(.55f,.83f,1);var gt=T(get.transform,"Label","GET NOW  >>",5,0,129,30,17,true,TextAnchor.MiddleCenter);gt.color=new Color(.012f,.07f,.18f);Click(p);
        var n=P(frame,"Notice",30,539,375,109);Detail(n.transform,375,109);V(n.transform,EclipseStyledVector.Shape.Bell,14,13,28,28,new Color(.65f,.81f,1),2);T(n.transform,"Title","NOTICE",56,9,255,29,21,true);S(n.transform,"Divider",15,40,343,1,new Color(.11f,.28f,.48f,.5f));T(n.transform,"Message","Maintenance will be on\nNov 10, 08:00 (UTC+7).",56,44,278,54,18);T(n.transform,"Arrow",">",340,35,23,40,32);Click(n);
    }
    void Right(){var d=P(frame,"DailyMission",1316,179,326,122);Detail(d.transform,326,122);V(d.transform,EclipseStyledVector.Shape.Bag,15,14,27,27,new Color(.72f,.85f,1),2);T(d.transform,"Title","DAILY MISSION",55,9,194,32,19,true);T(d.transform,"Count","0 / 3",250,9,60,32,18);S(d.transform,"Divider",14,46,296,1,new Color(.15f,.3f,.5f));T(d.transform,"Task","Play 3 matches",16,53,265,31,20);V(d.transform,EclipseStyledVector.Shape.Diamond,204,81,25,29,cyan,2);T(d.transform,"Reward","x100",237,79,60,31,18,true);T(d.transform,"Arrow",">",292,76,23,35,29);Click(d);
        var r=P(frame,"SeasonRank",1316,320,326,114);Detail(r.transform,326,114);V(r.transform,EclipseStyledVector.Shape.Shield,14,13,69,77,new Color(.95f,.68f,.30f),3);V(r.transform,EclipseStyledVector.Shape.Shield,25,24,47,53,new Color(1,.85f,.57f),1.3f);T(r.transform,"Heading","SEASON RANK",91,10,216,30,18,true);T(r.transform,"Rank","Bronze I",108,42,170,30,21,true);S(r.transform,"Track",108,73,154,5,new Color(.12f,.19f,.3f));S(r.transform,"Fill",108,73,12,5,new Color(.8f,.71f,.51f));T(r.transform,"Progress","0 / 1000",108,80,162,26,16);T(r.transform,"Arrow",">",288,40,23,35,29);Click(r);
        var m=P(frame,"MapPromo",1316,452,326,209,true,12);if(mapArtwork)A(m.transform,"OwnMap",mapArtwork,3,3,320,203);else{V(m.transform,EclipseStyledVector.Shape.Grid,3,3,320,146,new Color(.13f,.47f,.86f,.5f));V(m.transform,EclipseStyledVector.Shape.Map,12,11,300,139,new Color(.3f,.65f,1,.9f),1.6f);T(m.transform,"Sector","SECTOR 07 / PREVIEW",15,7,270,18,10);}
        var cap=P(m.transform,"Caption",3,150,320,56,false,0);cap.border=0;var tag=T(cap.transform,"Tag","NEW MAP",12,1,270,25,19,true);tag.color=new Color(1,.8f,.25f);T(cap.transform,"Name","RESEARCH FACILITY  >>",12,25,300,28,20,true);Detail(m.transform,326,209);Click(m);
    }
    void Bottom(){var bar=P(frame,"NavigationBacking",18,778,1213,133,false,25);bar.color=new Color(.015f,.045f,.09f,.65f);bar.bottom=new Color(.002f,.008f,.02f,.75f);bar.border=.6f;bar.raycastTarget=false;
        Nav("Operations","Play Missions",30,786,218,115,EclipseStyledVector.Shape.Target,true);Nav("Agents","Select Character",254,790,176,108,EclipseStyledVector.Shape.Agent);Nav("Armory","Upgrade Weapons",445,790,176,108,EclipseStyledVector.Shape.Gun);Nav("Inventory","Manage Items",635,790,184,108,EclipseStyledVector.Shape.Bag);Nav("Store","Buy Items",835,790,181,108,EclipseStyledVector.Shape.Cart);Nav("Settings","Game Settings",1032,790,179,108,EclipseStyledVector.Shape.Gear);
        Glow(frame,"Deploy",1261,760,386,142);var d=P(frame,"Deploy",1261,760,386,142,true,27);d.color=new Color(.035f,.35f,.98f);d.bottom=new Color(.008f,.07f,.29f);d.border=3;var inner=P(d.transform,"InnerFrame",7,7,372,128,true,23);inner.color=inner.bottom=Color.clear;inner.edge=new Color(.15f,.57f,1,.7f);inner.border=1;inner.raycastTarget=false;
        V(d.transform,EclipseStyledVector.Shape.Grid,11,11,364,120,new Color(.15f,.56f,1,.22f));S(d.transform,"TopSpecular",40,5,278,2,new Color(.5f,.85f,1));T(d.transform,"Title","DEPLOY",36,15,292,71,51,true,TextAnchor.MiddleCenter);var sub=T(d.transform,"Subtitle","ENTER THE BATTLEFIELD",36,83,300,31,19,true,TextAnchor.MiddleCenter);sub.color=new Color(.4f,.73f,1);T(d.transform,"Chevrons",">>",314,26,65,69,45,true);Detail(d.transform,386,142);Click(d);S(frame,"FooterTrace",30,908,1606,1,new Color(.15f,.43f,.78f));
    }
    void Nav(string title,string subtitle,float x,float y,float w,float h,EclipseStyledVector.Shape icon,bool active=false){if(active)Glow(frame,title,x,y,w,h);var p=P(frame,title,x,y,w,h,active,18);var inner=P(p.transform,"InsetFrame",6,6,w-12,h-12,false,13);inner.color=inner.bottom=Color.clear;inner.edge=new Color(.15f,.4f,.75f,active?.75f:.2f);inner.border=1;inner.raycastTarget=false;Detail(p.transform,w,h);V(p.transform,icon,(w-38)/2,12,38,38,new Color(.77f,.89f,1),2.4f);T(p.transform,"Title",title.ToUpperInvariant(),4,52,w-8,29,19,true,TextAnchor.MiddleCenter);var st=T(p.transform,"Subtitle",subtitle,4,79,w-8,23,14,false,TextAnchor.MiddleCenter);st.color=new Color(.61f,.72f,.88f);if(active)Badge(p.transform,w-20,-8);Click(p);}
}
