using UnityEngine;
using UnityEngine.UI;
// Texture-free procedural chamfered frame with gradient fill and layered borders.
public class EclipseStyledPanel:MaskableGraphic {
    public float cut=16, border=1.5f;
    public Color bottom=new Color(.006f,.018f,.045f,.97f);
    public Color edge=new Color(.16f,.42f,.75f,.9f);
    Vector2[] Path(float d){var r=rectTransform.rect;float l=r.xMin+d,b=r.yMin+d,t=r.yMax-d,rr=r.xMax-d,c=Mathf.Max(0,Mathf.Min(cut-d,Mathf.Min(rr-l,t-b)*.35f));return new[]{new Vector2(l,b),new Vector2(rr-c,b),new Vector2(rr,b+c),new Vector2(rr,t),new Vector2(l+c,t),new Vector2(l,t-c)};}
    void V(VertexHelper vh,Vector2 p,Color c){var v=UIVertex.simpleVert;v.position=p;v.color=c;vh.AddVert(v);}
    protected override void OnPopulateMesh(VertexHelper vh){vh.Clear();var o=Path(0);var a=Path(border);var r=rectTransform.rect;for(int i=0;i<6;i++)V(vh,a[i],Color.Lerp(bottom,color,Mathf.InverseLerp(r.yMin,r.yMax,a[i].y)));for(int i=1;i<5;i++)vh.AddTriangle(0,i,i+1);if(border<=0)return;for(int i=0;i<6;i++){int j=(i+1)%6,k=vh.currentVertCount;V(vh,o[i],edge);V(vh,o[j],edge);V(vh,a[j],edge);V(vh,a[i],edge);vh.AddTriangle(k,k+1,k+2);vh.AddTriangle(k,k+2,k+3);}}
}
