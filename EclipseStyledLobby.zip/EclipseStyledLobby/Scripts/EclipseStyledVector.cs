using UnityEngine;
using UnityEngine.UI;
public class EclipseStyledVector:MaskableGraphic {
    public enum Shape { Grid, Globe, Target, Agent, Gun, Bag, Cart, Gear, Diamond, Shield, Map, Rings, Bell, Friends }
    public Shape shape;public float thickness=1.5f;VertexHelper vh;
    void L(float x,float y,float a,float b,float opacity=1){Rect r=rectTransform.rect;Vector2 p=new Vector2(r.xMin+x*r.width,r.yMin+y*r.height),q=new Vector2(r.xMin+a*r.width,r.yMin+b*r.height),n=new Vector2(-(q-p).y,(q-p).x).normalized*thickness*.5f;int k=vh.currentVertCount;Color c=color;c.a*=opacity;foreach(var pos in new[]{p+n,q+n,q-n,p-n}){var v=UIVertex.simpleVert;v.position=pos;v.color=c;vh.AddVert(v);}vh.AddTriangle(k,k+1,k+2);vh.AddTriangle(k,k+2,k+3);}
    void Ell(float x,float y,float rx,float ry,float opacity=1){for(int i=0;i<64;i++){float a=i*Mathf.PI/32,b=(i+1)*Mathf.PI/32;L(x+Mathf.Cos(a)*rx,y+Mathf.Sin(a)*ry,x+Mathf.Cos(b)*rx,y+Mathf.Sin(b)*ry,opacity);}}
    void Box(float x,float y,float w,float h){L(x,y,x+w,y);L(x+w,y,x+w,y+h);L(x+w,y+h,x,y+h);L(x,y+h,x,y);}
    protected override void OnPopulateMesh(VertexHelper mesh){vh=mesh;vh.Clear();switch(shape){
    case Shape.Grid:for(int i=0;i<=24;i++)L(i/24f,0,i/24f,1,.24f);for(int i=0;i<=14;i++)L(0,i/14f,1,i/14f,.24f);break;
    case Shape.Globe:Ell(.5f,.5f,.43f,.43f);Ell(.5f,.5f,.45f,.45f,.3f);for(int i=1;i<5;i++)Ell(.5f,.5f,.43f*i/5,.43f,.4f);for(int i=-3;i<=3;i++){float y=i*.1f,rx=Mathf.Sqrt(.43f*.43f-y*y);Ell(.5f,.5f+y,rx,.035f,.5f);}L(.07f,.5f,.93f,.5f,.5f);L(.5f,.07f,.5f,.93f,.5f);break;
    case Shape.Rings:Ell(.5f,.5f,.48f,.35f,.3f);Ell(.5f,.5f,.43f,.28f);Ell(.5f,.5f,.35f,.2f,.4f);for(int i=0;i<32;i++){float a=i*Mathf.PI/16;L(.5f+Mathf.Cos(a)*.44f,.5f+Mathf.Sin(a)*.29f,.5f+Mathf.Cos(a)*.48f,.5f+Mathf.Sin(a)*.33f);}break;
    case Shape.Target:Ell(.5f,.5f,.29f,.29f);Ell(.5f,.5f,.15f,.15f);L(.5f,0,.5f,.34f);L(.5f,.66f,.5f,1);L(0,.5f,.34f,.5f);L(.66f,.5f,1,.5f);break;
    case Shape.Agent:Ell(.5f,.7f,.15f,.19f);L(.35f,.47f,.2f,.35f);L(.2f,.35f,.12f,.08f);L(.12f,.08f,.88f,.08f);L(.88f,.08f,.8f,.35f);L(.8f,.35f,.65f,.47f);L(.35f,.47f,.5f,.3f);L(.5f,.3f,.65f,.47f);break;
    case Shape.Gun:Box(.15f,.45f,.58f,.2f);L(.73f,.56f,1,.56f);L(.15f,.45f,0,.28f);L(.45f,.45f,.38f,.12f);L(.54f,.45f,.62f,.26f);L(.62f,.26f,.72f,.28f);break;
    case Shape.Bag:Box(.16f,.08f,.68f,.69f);Box(.35f,.77f,.3f,.17f);Box(.28f,.2f,.44f,.23f);break;
    case Shape.Cart:L(.03f,.88f,.18f,.88f);L(.18f,.88f,.34f,.3f);L(.34f,.3f,.84f,.3f);L(.25f,.73f,.95f,.73f);L(.95f,.73f,.84f,.43f);L(.84f,.43f,.3f,.43f);Ell(.4f,.12f,.06f,.06f);Ell(.8f,.12f,.06f,.06f);break;
    case Shape.Gear:Ell(.5f,.5f,.28f,.28f);Ell(.5f,.5f,.11f,.11f);for(int i=0;i<8;i++){float a=i*Mathf.PI/4;L(.5f+Mathf.Cos(a)*.29f,.5f+Mathf.Sin(a)*.29f,.5f+Mathf.Cos(a)*.44f,.5f+Mathf.Sin(a)*.44f);}break;
    case Shape.Diamond:L(.5f,.96f,.15f,.52f);L(.15f,.52f,.5f,.04f);L(.5f,.04f,.85f,.52f);L(.85f,.52f,.5f,.96f);L(.5f,.96f,.4f,.39f);L(.4f,.39f,.5f,.04f);L(.15f,.52f,.4f,.39f);L(.4f,.39f,.85f,.52f);break;
    case Shape.Shield:L(.1f,.86f,.5f,.97f);L(.5f,.97f,.9f,.86f);L(.9f,.86f,.8f,.3f);L(.8f,.3f,.5f,.04f);L(.5f,.04f,.2f,.3f);L(.2f,.3f,.1f,.86f);L(.2f,.69f,.5f,.38f);L(.5f,.38f,.8f,.69f);L(.5f,.38f,.5f,.04f);break;
    case Shape.Map:for(int i=0;i<6;i++){float h=.15f+(i%3)*.13f;Box(.05f+i*.15f,.16f,.12f,h);for(int j=0;j<3;j++)L(.07f+i*.15f,.2f+j*.07f,.14f+i*.15f,.2f+j*.07f,.5f);}L(0,.12f,1,.12f);L(.4f,.16f,.4f,.86f);L(.4f,.86f,.55f,.86f);L(.55f,.86f,.55f,.16f);break;
    case Shape.Bell:L(.18f,.23f,.28f,.4f);L(.28f,.4f,.28f,.72f);L(.28f,.72f,.5f,.9f);L(.5f,.9f,.72f,.72f);L(.72f,.72f,.72f,.4f);L(.72f,.4f,.82f,.23f);L(.82f,.23f,.18f,.23f);Ell(.5f,.1f,.05f,.05f);break;
    case Shape.Friends:Ell(.35f,.7f,.15f,.15f);Ell(.74f,.7f,.12f,.12f);L(.08f,.12f,.18f,.4f);L(.18f,.4f,.5f,.4f);L(.5f,.4f,.6f,.12f);L(.65f,.4f,.84f,.4f);L(.84f,.4f,.94f,.12f);break;
    }}
}
