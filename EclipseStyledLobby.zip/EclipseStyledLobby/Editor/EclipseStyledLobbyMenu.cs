#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
public static class EclipseStyledLobbyMenu {
    [MenuItem("Tools/Project Eclipse/Create Styled Lobby")]
    static void Create(){var go=new GameObject("Eclipse Styled Lobby");Undo.RegisterCreatedObjectUndo(go,"Create Styled Lobby");go.AddComponent<EclipseStyledLobbyBuilder>().Build();Selection.activeGameObject=go;EditorSceneManager.MarkSceneDirty(go.scene);}
}
[CustomEditor(typeof(EclipseStyledLobbyBuilder))]
public class EclipseStyledLobbyInspector:Editor {
    public override void OnInspectorGUI(){DrawDefaultInspector();EditorGUILayout.HelpBox("Native layered UI. No screenshot textures. Build replaces the generated hierarchy. Artwork and real 3D character are not included.",MessageType.Info);if(GUILayout.Button("BUILD STYLED LOBBY")){var b=(EclipseStyledLobbyBuilder)target;b.Build();if(!Application.isPlaying)EditorSceneManager.MarkSceneDirty(b.gameObject.scene);}}
}
#endif
