using UnityEngine;
using UnityEngine.UI;

namespace HUDBuilder
{
    public enum HUDWidgetType
    {
        Panel, Text, Button, Joystick, Minimap, ProgressBar, WeaponSlot, Crosshair
    }

    [DisallowMultipleComponent]
    public class HUDElement : MonoBehaviour
    {
        public string id;
        public HUDWidgetType widgetType;
        [TextArea] public string displayText;
        public Color tint = Color.white;
        [Range(0f, 1f)] public float opacity = 1f;

        public RectTransform RectTransform => transform as RectTransform;

        public void ApplyVisuals()
        {
            var image = GetComponent<Image>();
            if (image != null)
            {
                Color c = tint;
                c.a *= opacity;
                image.color = c;
            }

            var text = GetComponentInChildren<Text>(true);
            if (text != null && widgetType == HUDWidgetType.Text)
                text.text = displayText;
        }
    }
}
