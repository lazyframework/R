using UnityEngine;
using UnityEngine.UI;

namespace HUDBuilder
{
    /// <summary>
    /// Lightweight runtime hooks for the generated HUD.
    /// Connect these methods to your own player, weapon and mission systems.
    /// </summary>
    public class HUDRuntimeController : MonoBehaviour
    {
        [Header("Optional UI references")]
        public Text healthText;
        public Text armorText;
        public Text ammoText;
        public Text missionText;
        public Image healthFill;
        public Image armorFill;

        public void SetHealth(float current, float maximum)
        {
            float ratio = maximum <= 0 ? 0 : Mathf.Clamp01(current / maximum);
            if (healthText) healthText.text = $"HP {Mathf.CeilToInt(current)}";
            if (healthFill) healthFill.fillAmount = ratio;
        }

        public void SetArmor(float current, float maximum)
        {
            float ratio = maximum <= 0 ? 0 : Mathf.Clamp01(current / maximum);
            if (armorText) armorText.text = $"Armor {Mathf.CeilToInt(current)}";
            if (armorFill) armorFill.fillAmount = ratio;
        }

        public void SetAmmo(int magazine, int reserve)
        {
            if (ammoText) ammoText.text = $"{magazine} / {reserve}";
        }

        public void SetMission(string value)
        {
            if (missionText) missionText.text = value;
        }
    }
}
