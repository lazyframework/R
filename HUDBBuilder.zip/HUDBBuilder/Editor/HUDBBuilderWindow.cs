using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace HUDBuilder.Editor
{
    public class HUDBBuilderWindow : EditorWindow
    {
        [Serializable]
        private class WidgetData
        {
            public string id, title, text;
            public HUDWidgetType type;
            public Vector2 normalizedPosition;
            public Vector2 size;
            public Color color;
            public float opacity = 1f;
            public bool visible = true;
        }

        [Serializable]
        private class LayoutData
        {
            public int referenceWidth = 1648;
            public int referenceHeight = 928;
            public List<WidgetData> widgets = new List<WidgetData>();
        }

        private const string RootName = "HUD_Builder";
        private const int RefW = 1648;
        private const int RefH = 928;
        private LayoutData layout = new LayoutData();
        private Vector2 hierarchyScroll, previewScroll;
        private string selectedId;
        private bool showPreview = true;
        private bool showMobileSafeArea = true;
        private bool dirty;
        private Vector2 dragStart;
        private Vector2 widgetStart;
        private bool dragging;

        [MenuItem("Tools/HUD Builder/Full HUD Builder")]
        public static void Open()
        {
            var w = GetWindow<HUDBBuilderWindow>();
            w.titleContent = new GUIContent("HUD Builder");
            w.minSize = new Vector2(880, 560);
            w.Show();
        }

        private void OnEnable()
        {
            if (layout.widgets.Count == 0) BuildDefaultLayout();
        }

        private void OnGUI()
        {
            DrawToolbar();
            EditorGUILayout.BeginHorizontal();
            DrawHierarchy();
            EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true));
            DrawPreview();
            DrawInspector();
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();
            if (dirty) Repaint();
        }

        private void DrawToolbar()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            GUILayout.Label("LEAKOS  /  TACTICAL HUD BUILDER", EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Generate / Update HUD", EditorStyles.toolbarButton, GUILayout.Width(150)))
                GenerateHUD();
            if (GUILayout.Button("Save Layout", EditorStyles.toolbarButton, GUILayout.Width(85)))
                SaveLayout();
            if (GUILayout.Button("Load Layout", EditorStyles.toolbarButton, GUILayout.Width(85)))
                LoadLayout();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawHierarchy()
        {
            EditorGUILayout.BeginVertical(GUILayout.Width(205));
            GUILayout.Label("HIERARCHY", EditorStyles.boldLabel);
            hierarchyScroll = EditorGUILayout.BeginScrollView(hierarchyScroll, GUI.skin.box);
            foreach (var item in layout.widgets)
            {
                EditorGUILayout.BeginHorizontal();
                bool selected = selectedId == item.id;
                if (GUILayout.Toggle(selected, GUIContent.none, GUILayout.Width(18)) && !selected)
                    selectedId = item.id;
                if (GUILayout.Button(item.title, EditorStyles.label))
                    selectedId = item.id;
                if (GUILayout.Button(item.visible ? "●" : "○", GUILayout.Width(24)))
                {
                    item.visible = !item.visible;
                    dirty = true;
                    UpdateExistingWidget(item);
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();

            GUILayout.Space(6);
            GUILayout.Label("ADD WIDGET", EditorStyles.boldLabel);
            if (GUILayout.Button("+ Text")) AddWidget(HUDWidgetType.Text);
            if (GUILayout.Button("+ Panel")) AddWidget(HUDWidgetType.Panel);
            if (GUILayout.Button("+ Button")) AddWidget(HUDWidgetType.Button);
            if (GUILayout.Button("+ Progress Bar")) AddWidget(HUDWidgetType.ProgressBar);
            if (GUILayout.Button("+ Weapon Slot")) AddWidget(HUDWidgetType.WeaponSlot);
            if (GUILayout.Button("+ Minimap")) AddWidget(HUDWidgetType.Minimap);
            if (GUILayout.Button("+ Joystick")) AddWidget(HUDWidgetType.Joystick);
            if (GUILayout.Button("+ Crosshair")) AddWidget(HUDWidgetType.Crosshair);
            GUILayout.Space(8);
            if (GUILayout.Button("Reset to Reference Layout"))
            {
                if (EditorUtility.DisplayDialog("Reset HUD", "Replace the current layout with the reference layout?", "Reset", "Cancel"))
                {
                    BuildDefaultLayout();
                    dirty = true;
                }
            }
            EditorGUILayout.EndVertical();
        }

        private void DrawPreview()
        {
            EditorGUILayout.BeginVertical();
            EditorGUILayout.BeginHorizontal();
            showPreview = GUILayout.Toggle(showPreview, "Preview", "Button", GUILayout.Width(85));
            showMobileSafeArea = GUILayout.Toggle(showMobileSafeArea, "Safe Area", "Button", GUILayout.Width(85));
            GUILayout.FlexibleSpace();
            GUILayout.Label("Reference: 1648 × 928  |  Android landscape", EditorStyles.miniLabel);
            EditorGUILayout.EndHorizontal();

            if (!showPreview) { EditorGUILayout.EndVertical(); return; }

            Rect area = GUILayoutUtility.GetRect(400, 300, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            EditorGUI.DrawRect(area, new Color(0.035f, 0.05f, 0.085f));
            float scale = Mathf.Min(area.width / RefW, area.height / RefH);
            Vector2 size = new Vector2(RefW * scale, RefH * scale);
            Rect canvas = new Rect(area.x + (area.width - size.x) / 2, area.y + (area.height - size.y) / 2, size.x, size.y);
            EditorGUI.DrawRect(canvas, new Color(0.10f, 0.16f, 0.25f));
            DrawGrid(canvas, scale);

            if (showMobileSafeArea)
            {
                Rect safe = new Rect(canvas.x + canvas.width * .04f, canvas.y + canvas.height * .04f,
                    canvas.width * .92f, canvas.height * .92f);
                Handles.color = new Color(0.25f, 0.85f, 1f, .55f);
                Handles.DrawAAPolyLine(2, new Vector3(safe.x, safe.y), new Vector3(safe.xMax, safe.y),
                    new Vector3(safe.xMax, safe.yMax), new Vector3(safe.x, safe.yMax), new Vector3(safe.x, safe.y));
            }

            Event e = Event.current;
            foreach (var item in layout.widgets)
            {
                Rect r = WidgetRect(canvas, item);
                Color c = item.color; c.a = Mathf.Clamp01(item.opacity);
                EditorGUI.DrawRect(r, c);
                Handles.color = selectedId == item.id ? Color.cyan : new Color(.55f, .75f, 1f, .9f);
                Handles.DrawAAPolyLine(selectedId == item.id ? 2.5f : 1f,
                    new Vector3(r.x, r.y), new Vector3(r.xMax, r.y),
                    new Vector3(r.xMax, r.yMax), new Vector3(r.x, r.yMax), new Vector3(r.x, r.y));
                GUIStyle label = new GUIStyle(EditorStyles.miniLabel)
                {
                    alignment = TextAnchor.MiddleCenter,
                    normal = { textColor = Color.white },
                    wordWrap = true,
                    fontSize = Mathf.Clamp(Mathf.RoundToInt(9 * scale / .5f), 6, 11)
                };
                GUI.Label(r, item.text, label);

                if (e.type == EventType.MouseDown && r.Contains(e.mousePosition) && e.button == 0)
                {
                    selectedId = item.id;
                    dragging = true;
                    dragStart = e.mousePosition;
                    widgetStart = item.normalizedPosition;
                    GUI.FocusControl(null);
                    e.Use();
                }
                if (dragging && selectedId == item.id && e.type == EventType.MouseDrag)
                {
                    Vector2 delta = e.mousePosition - dragStart;
                    item.normalizedPosition = new Vector2(
                        Mathf.Clamp01(widgetStart.x + delta.x / canvas.width),
                        Mathf.Clamp01(widgetStart.y + delta.y / canvas.height));
                    dirty = true;
                    e.Use();
                    Repaint();
                }
                if (e.type == EventType.MouseUp && dragging)
                {
                    dragging = false;
                    e.Use();
                }
            }
            EditorGUILayout.EndVertical();
        }

        private void DrawGrid(Rect r, float scale)
        {
            Handles.color = new Color(1, 1, 1, .045f);
            for (int x = 1; x < 10; x++)
                Handles.DrawLine(new Vector3(r.x + r.width * x / 10f, r.y), new Vector3(r.x + r.width * x / 10f, r.yMax));
            for (int y = 1; y < 6; y++)
                Handles.DrawLine(new Vector3(r.x, r.y + r.height * y / 6f), new Vector3(r.xMax, r.y + r.height * y / 6f));
        }

        private Rect WidgetRect(Rect canvas, WidgetData item)
        {
            float w = item.size.x / RefW * canvas.width;
            float h = item.size.y / RefH * canvas.height;
            float x = canvas.x + item.normalizedPosition.x * canvas.width - w / 2;
            float y = canvas.y + item.normalizedPosition.y * canvas.height - h / 2;
            return new Rect(x, y, Mathf.Max(8, w), Mathf.Max(8, h));
        }

        private void DrawInspector()
        {
            GUILayout.Space(5);
            GUILayout.Label("INSPECTOR", EditorStyles.boldLabel);
            var item = layout.widgets.FirstOrDefault(x => x.id == selectedId);
            if (item == null) { EditorGUILayout.HelpBox("Pilih widget dari Hierarchy atau Preview.", MessageType.Info); return; }

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            item.title = EditorGUILayout.TextField("Name", item.title);
            item.text = EditorGUILayout.TextField("Displayed Text", item.text);
            item.type = (HUDWidgetType)EditorGUILayout.EnumPopup("Widget Type", item.type);
            item.normalizedPosition = EditorGUILayout.Vector2Field("Position (0–1)", item.normalizedPosition);
            item.size = EditorGUILayout.Vector2Field("Size (px)", item.size);
            item.color = EditorGUILayout.ColorField("Color", item.color);
            item.opacity = EditorGUILayout.Slider("Opacity", item.opacity, 0, 1);
            item.visible = EditorGUILayout.Toggle("Visible", item.visible);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Apply to Scene")) UpdateExistingWidget(item);
            GUI.backgroundColor = new Color(1f, .55f, .5f);
            if (GUILayout.Button("Delete Widget", GUILayout.Width(110)))
            {
                layout.widgets.Remove(item);
                DeleteExistingWidget(item.id);
                selectedId = null;
                dirty = true;
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();
            if (GUI.changed) dirty = true;
        }

        private void BuildDefaultLayout()
        {
            layout.widgets.Clear();
            Add("profile", "Player Profile", HUDWidgetType.Panel, "FamaLine  |  Lv. 12\\n720 / 2,000\\nSilver III", 0.108f, 0.16f, 310, 125, new Color(.025f,.055f,.11f,.88f));
            Add("mission", "Main Mission", HUDWidgetType.Panel, "◆  MAIN MISSION\\nInfiltrate the Research Facility\\n◇ Reach the Control Room (0/1)", .118f, .30f, 330, 120, new Color(.025f,.055f,.11f,.88f));
            Add("compass", "Compass", HUDWidgetType.Panel, "W     285     300     NW     330     N     15     30     NE", .50f, .052f, 560, 48, new Color(.025f,.055f,.11f,.62f));
            Add("currency", "Currency", HUDWidgetType.Panel, "◆  1,200   +       ◉  15,340   +", .80f, .048f, 310, 45, new Color(.025f,.055f,.11f,.72f));
            Add("minimap", "Minimap", HUDWidgetType.Minimap, "N\\n      ◆\\n  ▲", .922f, .188f, 210, 190, new Color(.12f,.20f,.31f,.88f));
            Add("timer", "Match Timer", HUDWidgetType.Text, "◷  14:32", .895f, .315f, 155, 38, new Color(.02f,.04f,.08f,.78f));
            Add("skill", "Skill Button", HUDWidgetType.Button, "⚡\\nQ", .967f, .435f, 78, 78, new Color(.04f,.20f,.48f,.92f));
            Add("heal", "Heal Button", HUDWidgetType.Button, "✚\\nE", .967f, .535f, 78, 78, new Color(.07f,.16f,.28f,.92f));
            Add("sprint", "Sprint Button", HUDWidgetType.Button, "↯\\nR", .967f, .635f, 78, 78, new Color(.07f,.16f,.28f,.92f));
            Add("fire", "Fire Button", HUDWidgetType.Button, "➤", .835f, .755f, 145, 145, new Color(.05f,.10f,.20f,.88f));
            Add("aim", "Aim Button", HUDWidgetType.Button, "◎", .905f, .625f, 82, 82, new Color(.05f,.10f,.20f,.86f));
            Add("crouch", "Crouch Button", HUDWidgetType.Button, "▣", .865f, .905f, 72, 72, new Color(.05f,.10f,.20f,.86f));
            Add("prone", "Prone Button", HUDWidgetType.Button, "━", .948f, .905f, 72, 72, new Color(.05f,.10f,.20f,.86f));
            Add("joystick", "Movement Joystick", HUDWidgetType.Joystick, "▲\\n◯", .135f, .742f, 220, 220, new Color(.08f,.16f,.27f,.58f));
            Add("quickrun", "Quick Run", HUDWidgetType.Button, "➤", .148f, .565f, 78, 78, new Color(.05f,.10f,.20f,.75f));
            Add("grenade", "Grenade", HUDWidgetType.WeaponSlot, "◉  2", .647f, .865f, 90, 66, new Color(.035f,.07f,.13f,.92f));
            Add("medkit", "Medkit", HUDWidgetType.WeaponSlot, "✚  1", .718f, .865f, 90, 66, new Color(.035f,.07f,.13f,.92f));
            Add("weapon1", "Primary Weapon", HUDWidgetType.WeaponSlot, "▰  ASSAULT RIFLE\\n30 / 120", .424f, .865f, 245, 75, new Color(.035f,.07f,.13f,.95f));
            Add("weapon2", "Secondary Weapon", HUDWidgetType.WeaponSlot, "PISTOL\\n15 / 45", .552f, .865f, 165, 75, new Color(.035f,.07f,.13f,.92f));
            Add("health", "Health Bar", HUDWidgetType.ProgressBar, "✚  HP 100", .426f, .932f, 420, 28, new Color(.08f,.58f,.95f,.95f));
            Add("armor", "Armor Bar", HUDWidgetType.ProgressBar, "⬟  Armor 100", .426f, .968f, 420, 28, new Color(.08f,.58f,.95f,.95f));
            Add("crosshair", "Crosshair", HUDWidgetType.Crosshair, "+", .50f, .50f, 42, 42, new Color(.95f,.35f,.25f,.95f));
        }

        private void Add(string id, string title, HUDWidgetType type, string text, float x, float y, float w, float h, Color color)
        {
            layout.widgets.Add(new WidgetData { id=id, title=title, type=type, text=text,
                normalizedPosition=new Vector2(x,y), size=new Vector2(w,h), color=color, opacity=color.a, visible=true });
        }

        private void AddWidget(HUDWidgetType type)
        {
            string id = Guid.NewGuid().ToString("N").Substring(0, 8);
            Add(id, type.ToString(), type, type.ToString(), .5f, .5f, 150, 60, new Color(.04f,.12f,.22f,.9f));
            selectedId = id; dirty = true;
        }

        private void GenerateHUD()
        {
            Canvas canvas = FindObjectOfType<Canvas>();
            if (canvas == null)
            {
                var go = new GameObject(RootName, typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
                canvas = go.GetComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.pixelPerfect = false;
                var scaler = go.GetComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(RefW, RefH);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
                scaler.matchWidthOrHeight = .5f;
                Undo.RegisterCreatedObjectUndo(go, "Create HUD Canvas");
            }
            canvas.name = RootName;
            Transform root = canvas.transform;
            foreach (Transform child in root.Cast<Transform>().ToArray())
                if (child.GetComponent<HUDElement>() != null) Undo.DestroyObjectImmediate(child.gameObject);

            foreach (var data in layout.widgets)
                CreateWidget(root, data);

            if (FindObjectOfType<EventSystem>() == null)
            {
                var es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
                Undo.RegisterCreatedObjectUndo(es, "Create EventSystem");
            }

            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            Selection.activeGameObject = canvas.gameObject;
            EditorGUIUtility.PingObject(canvas.gameObject);
            EditorUtility.DisplayDialog("HUD Builder", "HUD berhasil dibuat / diperbarui di Scene. Sesuaikan koneksi gameplay pada HUDRuntimeController.", "OK");
        }

        private void CreateWidget(Transform root, WidgetData data)
        {
            GameObject go = new GameObject(data.title, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(HUDElement));
            Undo.RegisterCreatedObjectUndo(go, "Create HUD Widget");
            go.transform.SetParent(root, false);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = data.normalizedPosition;
            rt.pivot = new Vector2(.5f, .5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = data.size;
            go.SetActive(data.visible);

            Image image = go.GetComponent<Image>();
            image.color = data.color;
            image.raycastTarget = data.type == HUDWidgetType.Button || data.type == HUDWidgetType.Joystick;
            image.type = Image.Type.Sliced;

            HUDElement meta = go.GetComponent<HUDElement>();
            meta.id = data.id; meta.widgetType = data.type; meta.displayText = data.text;
            meta.tint = data.color; meta.opacity = data.opacity;

            if (data.type == HUDWidgetType.ProgressBar)
            {
                image.color = new Color(.015f,.045f,.09f,.85f);
                var fillObject = new GameObject("Fill", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
                fillObject.transform.SetParent(go.transform, false);
                var fillRect = fillObject.GetComponent<RectTransform>();
                fillRect.anchorMin = new Vector2(0, .5f);
                fillRect.anchorMax = new Vector2(0, .5f);
                fillRect.pivot = new Vector2(0, .5f);
                fillRect.anchoredPosition = new Vector2(6, 0);
                fillRect.sizeDelta = new Vector2(data.size.x - 12, 7);
                fillObject.GetComponent<Image>().color = data.color;
                CreateChildText(go.transform, "Label", data.text, 0, 0, data.size.x - 10, data.size.y, Color.white, 15, TextAnchor.MiddleLeft);
            }
            else
            {
                int font = data.type == HUDWidgetType.Text ? 18 : 15;
                CreateChildText(go.transform, "Label", data.text, 0, 0, data.size.x - 8, data.size.y - 4, Color.white, font, TextAnchor.MiddleCenter);
            }
        }

        private Text CreateChildText(Transform parent, string name, string value, float x, float y, float w, float h, Color color, int fontSize, TextAnchor anchor)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(5, 3);
            rt.offsetMax = new Vector2(-5, -3);
            var text = go.GetComponent<Text>();
            text.text = value;
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = fontSize;
            text.color = color;
            text.alignment = anchor;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            text.raycastTarget = false;
            return text;
        }

        private void UpdateExistingWidget(WidgetData data)
        {
            var element = FindObjectsOfType<HUDElement>(true).FirstOrDefault(x => x.id == data.id);
            if (element == null) return;
            var rt = element.RectTransform;
            rt.anchorMin = rt.anchorMax = data.normalizedPosition;
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = data.size;
            element.gameObject.name = data.title;
            element.gameObject.SetActive(data.visible);
            element.widgetType = data.type; element.displayText = data.text;
            element.tint = data.color; element.opacity = data.opacity;
            element.ApplyVisuals();
            var label = element.GetComponentInChildren<Text>(true);
            if (label) label.text = data.text;
            EditorUtility.SetDirty(element);
            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        }

        private void DeleteExistingWidget(string id)
        {
            var element = FindObjectsOfType<HUDElement>(true).FirstOrDefault(x => x.id == id);
            if (element) Undo.DestroyObjectImmediate(element.gameObject);
        }

        private void SaveLayout()
        {
            string path = EditorUtility.SaveFilePanel("Save HUD Layout", Application.dataPath, "HUDLayout", "json");
            if (string.IsNullOrEmpty(path)) return;
            File.WriteAllText(path, JsonUtility.ToJson(layout, true));
            AssetDatabase.Refresh();
        }

        private void LoadLayout()
        {
            string path = EditorUtility.OpenFilePanel("Load HUD Layout", Application.dataPath, "json");
            if (string.IsNullOrEmpty(path)) return;
            try { layout = JsonUtility.FromJson<LayoutData>(File.ReadAllText(path)); dirty = true; Repaint(); }
            catch (Exception ex) { EditorUtility.DisplayDialog("HUD Builder", "Gagal membaca layout: " + ex.Message, "OK"); }
        }
    }
}
