using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

namespace LeakOSHUD.Editor
{
    public class TacticalHUDBuilderWindow : EditorWindow
    {
        const string RootName = "LEAKOS_TACTICAL_HUD";
        static readonly Color Navy = new Color(0.018f, 0.045f, 0.095f, 0.82f);
        static readonly Color Blue = new Color(0.05f, 0.48f, 1f, 0.96f);
        static readonly Color Cyan = new Color(0.12f, 0.72f, 1f, 1f);
        static readonly Color White = new Color(0.91f, 0.96f, 1f, 1f);
        static readonly Color Muted = new Color(0.60f, 0.73f, 0.88f, 1f);

        [MenuItem("Tools/LeakOS/Tactical HUD Builder V2")]
        public static void Open()
        {
            var w = GetWindow<TacticalHUDBuilderWindow>("Tactical HUD");
            w.minSize = new Vector2(360, 250);
        }

        void OnGUI()
        {
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("LEAKOS  /  TACTICAL HUD BUILDER", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Generate a complete mobile shooter HUD in the active scene. The HUD is built from real Unity UI objects, not preview placeholders.",
                MessageType.Info);

            EditorGUILayout.LabelField("Target", "Unity 6  •  Android  •  Landscape");
            EditorGUILayout.LabelField("Reference canvas", "1648 × 928");
            EditorGUILayout.Space(8);

            if (GUILayout.Button("GENERATE COMPLETE HUD", GUILayout.Height(38)))
                Generate();

            if (GUILayout.Button("Remove Generated HUD"))
                RemoveHUD();

            EditorGUILayout.Space(5);
            EditorGUILayout.HelpBox(
                "The generated HUD includes profile/mission panels, compass, currency, minimap frame, timer, action buttons, movement joystick, weapon slots, HP and armor bars. Replace the avatar/minimap placeholders with your own sprites or RenderTexture when ready.",
                MessageType.None);
        }

        static void Generate()
        {
            RemoveHUD();

            var root = new GameObject(RootName, typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(TacticalHUDRuntime));
            Undo.RegisterCreatedObjectUndo(root, "Generate Tactical HUD");

            var canvas = root.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.pixelPerfect = false;

            var scaler = root.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1648, 928);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;

            if (FindObjectOfType<EventSystem>() == null)
            {
                var es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
                Undo.RegisterCreatedObjectUndo(es, "Create EventSystem");
            }

            // Top-left player profile
            var profile = Panel(root.transform, "Player Profile", 28, 24, 306, 112, Navy);
            Panel(profile, "Avatar Frame", 0, 0, 96, 96, new Color(.04f,.14f,.29f,.98f));
            Text(profile, "Avatar Initial", "FL", 0, 0, 86, 86, 31, Cyan, TextAnchor.MiddleCenter);
            Text(profile, "Player Name", "FamaLine", 108, 8, 185, 30, 24, White, TextAnchor.MiddleLeft);
            Text(profile, "Player Level", "Lv. 12", 108, 42, 65, 25, 19, White, TextAnchor.MiddleLeft);
            Bar(profile, "XP Bar", 180, 51, 112, 9, Blue, .36f);
            Text(profile, "XP Text", "720 / 2,000", 180, 28, 112, 18, 12, Muted, TextAnchor.MiddleRight);
            Text(profile, "Rank", "◇  Silver III  ⓘ", 108, 72, 180, 25, 17, White, TextAnchor.MiddleLeft);

            // Mission panel
            var mission = Panel(root.transform, "Main Mission", 28, 154, 342, 122, Navy);
            Text(mission, "Mission Header", "◆  MAIN MISSION", 14, 8, 310, 27, 20, Cyan, TextAnchor.MiddleLeft);
            Text(mission, "Mission Title", "Infiltrate the Research Facility", 17, 43, 310, 27, 18, White, TextAnchor.MiddleLeft);
            Text(mission, "Mission Objective", "◇  Reach the Control Room (0/1)", 17, 77, 310, 27, 17, White, TextAnchor.MiddleLeft);

            // Compass strip
            var compass = Panel(root.transform, "Compass", 550, 22, 548, 44, new Color(.015f,.04f,.085f,.62f));
            Text(compass, "Compass Labels", "W     285     300     NW     330     N     15     30     NE", 8, 0, 532, 42, 17, White, TextAnchor.MiddleCenter);

            // Currencies and system buttons
            var currency = Panel(root.transform, "Currency", 1160, 24, 320, 44, new Color(.015f,.04f,.085f,.72f));
            Text(currency, "Currency Values", "◆  1,200   +       ◉  15,340   +", 8, 0, 304, 42, 17, White, TextAnchor.MiddleCenter);
            CircleButton(root.transform, "Notifications", "!", 1510, 22, 48, 48);
            CircleButton(root.transform, "Settings", "⚙", 1574, 22, 48, 48);

            // Minimap and timer
            var map = Panel(root.transform, "Minimap", 1412, 82, 210, 192, new Color(.06f,.12f,.21f,.92f));
            Text(map, "Map North", "N", 0, 5, 210, 24, 16, White, TextAnchor.MiddleCenter);
            // Map grid lines
            for (int i = 1; i <= 4; i++)
            {
                Image lineV = Box(map, "Map Grid V" + i, i * 38, 30, 1, 148, new Color(.55f,.72f,.9f,.18f));
                Image lineH = Box(map, "Map Grid H" + i, 8, 30 + i * 29, 194, 1, new Color(.55f,.72f,.9f,.18f));
            }
            Text(map, "Map Marker", "◆", 124, 28, 40, 40, 28, new Color(1f,.75f,.08f), TextAnchor.MiddleCenter);
            Text(map, "Player Marker", "▲", 82, 94, 40, 40, 26, Cyan, TextAnchor.MiddleCenter);
            var timer = Panel(root.transform, "Match Timer", 1412, 278, 210, 38, new Color(.015f,.04f,.085f,.82f));
            Text(timer, "Timer Text", "◷   14:32", 0, 0, 210, 36, 20, White, TextAnchor.MiddleCenter);

            // Left movement controls
            CircleButton(root.transform, "Quick Run", "↗", 200, 472, 82, 82);
            var joystick = CircleButton(root.transform, "Movement Joystick", "", 110, 580, 220, 220);
            joystick.GetComponent<Image>().color = new Color(.18f,.36f,.58f,.20f);
            var knob = CircleButton(joystick.transform, "Joystick Knob", "", 0, 0, 88, 88);
            knob.GetComponent<RectTransform>().anchorMin = knob.GetComponent<RectTransform>().anchorMax = new Vector2(.5f,.5f);
            knob.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
            knob.GetComponent<Image>().color = new Color(.75f,.88f,1f,.58f);
            var joyInput = joystick.AddComponent<TacticalHUDRuntime>();
            // Remove accidental runtime duplicate component; joystick input is added below.
            UnityEngine.Object.DestroyImmediate(joyInput);
            var pointer = joystick.AddComponent<LeakOSHUD.HUDJoystickInput>();
            pointer.area = joystick.GetComponent<RectTransform>();
            pointer.knob = knob.GetComponent<RectTransform>();
            Outline(joystick, new Color(.45f,.72f,1f,.75f), 2);

            // Right-side action controls
            CircleButton(root.transform, "Skill Q", "⚡\nQ", 1544, 340, 76, 76);
            CircleButton(root.transform, "Heal E", "✚\nE", 1544, 424, 76, 76);
            CircleButton(root.transform, "Sprint R", "↯\nR", 1544, 508, 76, 76);
            CircleButton(root.transform, "Aim", "◎", 1445, 575, 82, 82);
            CircleButton(root.transform, "Fire", "➤", 1305, 620, 150, 150);
            CircleButton(root.transform, "Crouch", "▣", 1360, 790, 72, 72);
            CircleButton(root.transform, "Prone", "━", 1500, 790, 72, 72);

            // Weapon and consumable slots
            var weapons = Panel(root.transform, "Weapon Inventory", 576, 758, 620, 82, new Color(.015f,.04f,.085f,.80f));
            var primary = Panel(weapons, "Primary Weapon", 0, 0, 245, 76, new Color(.03f,.12f,.25f,.96f));
            Text(primary, "Primary Icon", "▰  ASSAULT RIFLE", 8, 7, 225, 28, 16, White, TextAnchor.MiddleCenter);
            Text(primary, "Primary Ammo", "30 / 120", 8, 39, 225, 27, 19, Cyan, TextAnchor.MiddleCenter);
            var secondary = Panel(weapons, "Secondary Weapon", 252, 0, 155, 76, new Color(.03f,.09f,.18f,.96f));
            Text(secondary, "Secondary Icon", "▰  PISTOL", 4, 7, 147, 28, 14, White, TextAnchor.MiddleCenter);
            Text(secondary, "Secondary Ammo", "15 / 45", 4, 39, 147, 27, 17, Muted, TextAnchor.MiddleCenter);
            var grenade = Panel(weapons, "Grenade", 414, 0, 88, 76, new Color(.03f,.09f,.18f,.96f));
            Text(grenade, "Grenade Count", "◉  2", 0, 0, 88, 76, 18, White, TextAnchor.MiddleCenter);
            var medkit = Panel(weapons, "Medkit", 510, 0, 88, 76, new Color(.03f,.09f,.18f,.96f));
            Text(medkit, "Medkit Count", "✚  1", 0, 0, 88, 76, 18, White, TextAnchor.MiddleCenter);

            // Health / armor bars
            var status = Panel(root.transform, "Player Status", 480, 842, 680, 68, new Color(.015f,.04f,.085f,.52f));
            Text(status, "Health Label", "✚  HP  100", 10, 0, 112, 27, 17, White, TextAnchor.MiddleLeft);
            var hp = Bar(status, "Health Fill", 130, 8, 420, 12, new Color(.10f,.70f,1f), 1);
            Text(status, "Armor Label", "⬟  Armor  100", 10, 32, 112, 27, 16, White, TextAnchor.MiddleLeft);
            var armor = Bar(status, "Armor Fill", 130, 40, 420, 12, new Color(.10f,.48f,.95f), 1);

            // Runtime data bindings
            var runtime = root.GetComponent<TacticalHUDRuntime>();
            runtime.healthFill = hp;
            runtime.armorFill = armor;
            runtime.healthLabel = FindText(status.transform, "Health Label");
            runtime.armorLabel = FindText(status.transform, "Armor Label");
            runtime.ammoLabel = FindText(primary.transform, "Primary Ammo");
            runtime.grenadeLabel = FindText(grenade.transform, "Grenade Count");
            runtime.medkitLabel = FindText(medkit.transform, "Medkit Count");
            runtime.timerLabel = FindText(timer.transform, "Timer Text");
            runtime.missionLabel = FindText(mission.transform, "Mission Objective");

            EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
            Selection.activeGameObject = root;
            EditorGUIUtility.PingObject(root);
            EditorUtility.DisplayDialog("LeakOS HUD Builder", "Complete HUD generated in the active scene.", "OK");
        }

        static void RemoveHUD()
        {
            var old = GameObject.Find(RootName);
            if (old) Undo.DestroyObjectImmediate(old);
        }

        static GameObject Panel(Transform parent, string name, float x, float y, float w, float h, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            rt.anchoredPosition = new Vector2(x, -y);
            rt.sizeDelta = new Vector2(w, h);
            var img = go.GetComponent<Image>();
            img.color = color;
            img.raycastTarget = false;
            Outline(go, new Color(.16f,.53f,1f,.72f), 1.2f);
            return go;
        }

        static Image Box(Transform parent, string name, float x, float y, float w, float h, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0,1);
            rt.pivot = new Vector2(0,1);
            rt.anchoredPosition = new Vector2(x,-y);
            rt.sizeDelta = new Vector2(w,h);
            var image = go.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            return image;
        }

        static Text Text(Transform parent, string name, string value, float x, float y, float w, float h,
            int size, Color color, TextAnchor align)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0,1);
            rt.pivot = new Vector2(0,1);
            rt.anchoredPosition = new Vector2(x,-y);
            rt.sizeDelta = new Vector2(w,h);
            var t = go.GetComponent<Text>();
            t.text = value;
            t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            t.fontSize = size;
            t.color = color;
            t.alignment = align;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return t;
        }

        static GameObject CircleButton(Transform parent, string name, string label, float x, float y, float size, float height)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0,1);
            rt.pivot = new Vector2(.5f,.5f);
            rt.anchoredPosition = new Vector2(x,-y);
            rt.sizeDelta = new Vector2(size,height);
            var img = go.GetComponent<Image>();
            img.color = new Color(.025f,.075f,.15f,.58f);
            img.raycastTarget = true;
            Outline(go, new Color(.42f,.70f,1f,.85f), 2);
            if (!string.IsNullOrEmpty(label))
                Text(go.transform, "Label", label, 4, 3, size-8, height-6, 22, White, TextAnchor.MiddleCenter);
            return go;
        }

        static Image Bar(Transform parent, string name, float x, float y, float w, float h, Color color, float fill)
        {
            var bg = Box(parent, name + " Background", x, y, w, h, new Color(.02f,.06f,.12f,.95f));
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(bg.transform, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0,0);
            rt.anchorMax = new Vector2(fill,1);
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            var image = go.GetComponent<Image>();
            image.color = color;
            image.type = Image.Type.Filled;
            image.fillMethod = Image.FillMethod.Horizontal;
            image.fillAmount = fill;
            return image;
        }

        static void Outline(GameObject go, Color color, float width)
        {
            var outline = go.GetComponent<Outline>();
            if (!outline) outline = go.AddComponent<Outline>();
            outline.effectColor = color;
            outline.effectDistance = new Vector2(width, -width);
            outline.useGraphicAlpha = true;
        }

        static Text FindText(Transform root, string objectName)
        {
            foreach (var t in root.GetComponentsInChildren<Text>(true))
                if (t.name == objectName) return t;
            return null;
        }
    }
}
