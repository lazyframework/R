using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace LeakOSHUD
{
    public class TacticalHUDRuntime : MonoBehaviour
    {
        [Header("Player values")]
        [Range(0, 100)] public float health = 100;
        [Range(0, 100)] public float armor = 100;
        public int magazine = 30;
        public int reserveAmmo = 120;
        public int grenades = 2;
        public int medkits = 1;

        [Header("HUD references")]
        public Image healthFill;
        public Image armorFill;
        public Text healthLabel;
        public Text armorLabel;
        public Text ammoLabel;
        public Text grenadeLabel;
        public Text medkitLabel;
        public Text timerLabel;
        public Text missionLabel;

        void Start() { Refresh(); }

        public void SetHealth(float value)
        {
            health = Mathf.Clamp(value, 0, 100);
            Refresh();
        }

        public void SetArmor(float value)
        {
            armor = Mathf.Clamp(value, 0, 100);
            Refresh();
        }

        public void SetAmmo(int inMagazine, int inReserve)
        {
            magazine = Mathf.Max(0, inMagazine);
            reserveAmmo = Mathf.Max(0, inReserve);
            Refresh();
        }

        public void SetConsumables(int grenadeCount, int medkitCount)
        {
            grenades = Mathf.Max(0, grenadeCount);
            medkits = Mathf.Max(0, medkitCount);
            Refresh();
        }

        public void SetMission(string value)
        {
            if (missionLabel) missionLabel.text = value;
        }

        public void Refresh()
        {
            if (healthFill) healthFill.fillAmount = health / 100f;
            if (armorFill) armorFill.fillAmount = armor / 100f;
            if (healthLabel) healthLabel.text = "✚  HP  " + Mathf.CeilToInt(health);
            if (armorLabel) armorLabel.text = "⬟  Armor  " + Mathf.CeilToInt(armor);
            if (ammoLabel) ammoLabel.text = magazine + " / " + reserveAmmo;
            if (grenadeLabel) grenadeLabel.text = "◉  " + grenades;
            if (medkitLabel) medkitLabel.text = "✚  " + medkits;
        }
    }

    // Attach this to a player controller if you want to receive the mobile joystick vector.
    public class HUDJoystickInput : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform area;
        public RectTransform knob;
        public float radius = 65f;
        public Vector2 Value { get; private set; }
        public System.Action<Vector2> OnValueChanged;

        public void OnPointerDown(PointerEventData eventData) { OnDrag(eventData); }

        public void OnDrag(PointerEventData eventData)
        {
            if (!area) area = transform as RectTransform;
            Vector2 local;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                area, eventData.position, eventData.pressEventCamera, out local)) return;

            Value = Vector2.ClampMagnitude(local / Mathf.Max(1f, radius), 1f);
            if (knob) knob.anchoredPosition = Value * radius;
            OnValueChanged?.Invoke(Value);
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            Value = Vector2.zero;
            if (knob) knob.anchoredPosition = Vector2.zero;
            OnValueChanged?.Invoke(Value);
        }
    }
}
